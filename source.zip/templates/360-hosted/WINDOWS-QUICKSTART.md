# Igloo quizzes — Windows launch

1. Copy and **extract the entire ZIP** onto the venue PC (for example `C:\IglooQuizzes`). Do not run it inside the ZIP.
2. Double-click **Start-Igloo.cmd**. Keep its console window open. No npm installation or internet connection is required for bundled play. Only run a package from a source you trust.
3. Open **http://127.0.0.1:8787/sessions.html** in an ordinary browser to choose/edit/test an activity.
4. In ICE WebView, use one of these **play** URLs:
   - Region quiz: **http://127.0.0.1:8787/region.html**
   - Spot the Hazard: **http://127.0.0.1:8787/viewer.html**
5. Set the ICE WebView source to a **2:1 frame** (e.g. 4096 × 2048). Keep the existing equirectangular / True Perspective room mapping applied. Do **not** apply a cubemap conversion, use the 8640 × 3240 flat atlas from the old quiz, or use `desktop=1` in ICE.

`127.0.0.1` now means the venue PC. Your preparation computer does not need to be running. This launcher listens only on that PC, not the public internet. An online Windows PC can run it locally without opening a firewall port. The same host cannot be started twice on port 8787; close the previous host first. On failure, read the console; do not close or kill an unrelated service using that port.

## Before teaching — room check required

- Start the region quiz's **Check room alignment** screen. Wall 1–4 panels should land on wall centres. The coloured sectors continue onto **one combined floor**, not separate floor/ceiling faces. ICE's installed mapping/blending owns the six projector outputs; webpage pixel tiles do not replace that calibration.
- If all four regions are rotated, append `?roomYaw=90` (or a measured angle in degrees) to **region.html**. Use the same calibrated URL every time. `roomYaw` rotates both walls and floor sectors together. It is not per-projector warping.
- Check that panels fit below the unprojected ceiling and predominantly on walls. Both quizzes support `uiTop=25&uiBottom=-10&uiScale=0.85` for bounded wall-band calibration. These are starting values, not a measured guarantee for the venue.
- Test a click/touch on a projected button. ICE must forward source-coordinate input correctly. An ordinary mouse/keyboard can operate the play view; Tab exposes the same projected controls. Closing the editor must not stop play.
- Test one timer expiry and one manual **Answer locked in**. The correct region lights immediately; the original's 2.3-second drum-roll delay is not used. Pausing freezes the timer. There is no automatic learner detection or individual scoring. Group confidence is a tutor reflection, not a score.
- Check hazard-image seams, target alignment and text readability. The supplied construction scene is AI-generated, not a verified seamless photograph. Review safety content with a competent tutor; it is not certification.
- Desktop previews are ordinary-browser perspective tests: drag or use left/right arrows. They are not the ICE source.

## Editing, saving and moving content

- Use **Editor** from the sessions menu, then **Publish changes**. Editors are not runtime controllers. Region questions, explanations, names and timer are editable; original eight sample questions are included.
- Published updates do not change an active quiz's answer key. Pause the region quiz and select **Restart with published update**, or reload the page to start fresh. Hazard Hunt uses its existing load-update flow.
- This package contains a snapshot of **published activities and uploaded images** from `.local-data/`. Do not delete that directory. Unpublished drafts and in-progress lessons live in each browser and do **not** transfer automatically. Export/import activity JSON to carry drafts; publish and repackage to include uploaded image bytes as well.
- Back up the whole extracted folder, especially `.local-data/`, before updating. Extract new deliveries to a **new folder**, not over the venue's saved work. Transfer wanted activities intentionally. Region runs start fresh after a reload; download the discussion record before closing if needed.
- The package is self-contained; it includes a portable Windows Node runtime. It is not an installer or a public authenticated hosting service.

## Source credit / scope

Region quiz adapted from https://github.com/duncanig/QuickFloorSessions/blob/main/region-quiz-floor.html . Retains its eight example questions, landscape region names, opposite-wall two-answer mapping and timer/manual-lock reveal model. Rendering and authoring are rebuilt for this equirectangular lesson host. Original landscape animations, embedded recorded voices, music, HTML-share links and HTML downloads are not included; activity JSON replaces content transfer. Large readable wall panels and matching colour sectors replace the flat output atlas.
