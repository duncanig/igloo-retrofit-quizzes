import { defineConfig } from "vite";
import { fileURLToPath } from "node:url";
import { createSyncHub } from "./scripts/sync-server.mjs";
import { fileLessonStore } from "./scripts/lesson-store.mjs";

const hubs = new Set();
function install(server) {
  const hub = createSyncHub({store:fileLessonStore(fileURLToPath(new URL("./.local-data/",import.meta.url)))});
  hubs.add(hub);
  server.middlewares.use((req,res,next)=>{hub.handle(req,res,next).catch(()=>{if(!res.headersSent){res.statusCode=500;res.end("Connection error");}});});
  server.httpServer?.once("close",()=>hub.close());
}
export default defineConfig({
  plugins: [{ name: "site-survey-local-link", configureServer: install, configurePreviewServer: install,
    closeBundle(){for(const hub of hubs)hub.close();hubs.clear();} }],
  build: { rollupOptions: { input: {
    control: fileURLToPath(new URL("./index.html",import.meta.url)),
    viewer: fileURLToPath(new URL("./viewer.html",import.meta.url)),
    region: fileURLToPath(new URL("./region.html",import.meta.url)),
    regionEditor: fileURLToPath(new URL("./region-editor.html",import.meta.url)),
    sessions: fileURLToPath(new URL("./sessions.html",import.meta.url)),
  } } },
});
