# Hazard Hunt agent guide

- `VITE_STATIC_HOST=1` enables GitHub Pages: `web-activity.js` validates compressed
  immutable activity links, with no HTTP API/SSE dependencies. Do not claim
  browser-local drafts are cloud publications. Static play ignores local editor
  state unless the explicit activity fragment is provided. Invalid links must
  not silently play a different default activity. Custom image uploads need a
  storage host; this static edition uses the bundled scene only.
- After a Pages-mode build, `scripts/package-pages.mjs` emits standalone HTML
  for upload. Root index is the session menu; hazard-editor.html is the authoring
  page. Never upload .local-data, browser drafts, runtime binaries or credentials.

- `sessions.html` selects the two activities. `region-editor.html` prepares the
  region quiz; `region.html` plays it independently, using `region-quiz` by
  default. Region room names must start `region-`. Existing hazard rooms/data
  are unchanged. `activity-config.js` validates the server-side schema union.
- `region-renderer.js` projects four wall textures and continuous floor sectors
  into the same 2:1 source. `roomYaw` rotates the wall/floor regions together.
  Never map the old flat wall/floor atlas directly into True Perspective.
- Region runtime locks once on timer expiry/manual click; pause freezes time.
  Publication changes queue until an explicit restart. No tracked scoring.
- `scripts/package-windows.mjs <new-folder>` snapshots built pages, server,
  published `.local-data` and the running Windows Node executable. Never
  overwrite a venue delivery; browser drafts do not transfer with this snapshot.

- `index.html` / `src/main.js` is the **editor**, not a tutor controller.
  `viewer.html` / `src/output.js` is the complete playable lesson: Start,
  choices, feedback, pause, scores and debrief must work with the editor closed.
  Never gate play on the old `/api/state` tutor connection.
- ICE captures full-frame **2:1** output, with equirectangular/True Perspective
  mapping left on. `?desktop=1` is a separate perspective testing mode, never
  the ICE source. No 6:1/Cubemap → Equirectangular conversion in this activity.
- Visible lesson panels are deliberately allowed, but must be **spherically
  projected into the source**, not flat DOM overlays. `lesson-renderer.js`
  and `projection.js` must agree with panel action bounds in `lesson-ui.js`.
- `room-layout.js` fits every panel into the wall-centred band (default +25°
  to −10°, with uniform scaling). Preserve this for intro, questions, feedback
  and debrief alike; don't restore the old horizon-centred oversized popups.
  `uiTop`/`uiBottom`/`uiScale` URL values are bounded room calibration overrides.
- Preserve the larger, bolder room text and opaque contrast. Long feedback is
  paginated by `lesson-typography.js`, not reduced to tiny fonts. Keep wrapping,
  button bounds and feedback-page input/accessibility in sync when editing UI.
- The supplied image is AI-generated, not verified seamless/equirectangular.
  Preserve provenance, tutor-review and non-certification notices; actual room
  geometry/input must be checked in ICE. Keep the cursor and ordinary-click fallback.
- `lesson-config.js` owns the validated published schema. `lesson-runtime.js`
  owns independent play/scoring. Marker/hit regions are normalised source coords.
  Don't reuse the old 3D positions or plain editor screen coordinates for picking.
- `npm install`, `npm run dev`, `npm test`, `npm run build`, `npm run preview`
  run in this folder. `npm run serve` hosts `dist/` + API at 8787 after a build.
- `vite.config.js` builds both pages and uses the same API as `scripts/serve.mjs`.
  Published lessons/images persist in **`.local-data/`**, outside `dist/` and
  ignored by Git. Never clear that directory as a build/cleanup step.
- Editor drafts and play progress are separate browser-local keys; play progress
  is keyed by room/revision. Publications notify live clients but must not swap
  an active answer key without an explicit restart. Use expected revisions to
  reject stale publications. Validate imports/uploads; no arbitrary remote URLs.
- Publishing is local HTTP/SSE, not BroadcastChannel; ICE may be another browser.
  Plain HTTP can lack `randomUUID`; reconnect after terminal EventSource errors.
  `HOST`/`PORT` opt into trusted LAN use, not public authentication. Static-only
  hosting can play defaults, but cannot provide the publication/upload API.
- Legacy tutor endpoints and earlier scene/photo helpers remain unused by current
  play. Shared kit changes still go in `../../packages/igloo-kit/`, then root
  `npm run sync` / `npm run check-kit`; keep kit code scene-independent.
