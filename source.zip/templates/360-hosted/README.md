# Site Survey — editable construction Hazard Hunt

**The lesson is the primary experience.** Learners start it, select hazards,
answer questions and see feedback/scores inside the room. The editor is for
preparation and publishing; it does not have to remain open during a lesson.

## Run

Install a current Node.js LTS release. In this folder:

```sh
npm install
npm run dev
```

For the built local application:

```sh
npm test
npm run build
npm run serve
```

Default links on the host PC:

| Link | Purpose |
| --- | --- |
| `http://127.0.0.1:8787/` | Activity editor, not captured in ICE |
| `http://127.0.0.1:8787/viewer.html` | Playable, full-frame equirectangular lesson for ICE |
| `http://127.0.0.1:8787/viewer.html?desktop=1` | Same lesson in a normal perspective browser preview |

`npm run preview` also hosts the built pages and publishing API. Open the printed
address and use the editor's **Test lesson** / **Open ICE lesson** links. Don't
open source HTML from disk.

## Use in ICE

- Capture **`viewer.html`**, not the editor or `?desktop=1` preview.
- Use a fixed **2:1 source resolution**, e.g. 4000×2000, Dynamic Resolution off.
- Leave the room's equirectangular/True Perspective mapping configured. Do **not**
  add Cubemap → Equirectangular: the source is already equirectangular, not 6:1.
- Start, questions, buttons, feedback and debrief are **world-facing panel
  textures projected into the 2:1 source**. They are not ordinary flat DOM
  overlays. They look curved/distorted in a raw browser panorama and should
  become perspective-correct through the room mapping. Use `?desktop=1` to test
  comfortably on a normal monitor without altering the ICE configuration.
- The play page needs JavaScript/WebGL and browser input forwarded by ICE.
  Cursor is visible. Ordinary mouse clicks and pointer/touch events are supported,
  with shared deduplication. Actual touch mapping and readability need room testing.

### Rooms without ceiling projection

The default panel layout is wall-centred: full popups are fitted between
**+25° and −10° elevation**. Most of the panel is above the horizon, with only
a small allowance below it instead of extending deeply onto the floor. The introduction,
questions, feedback, pause and debrief all use the same limits, with uniform
scaling (text is not squashed). The inspection bar is also smaller and raised
away from the floor. Panels still follow the selected hazard horizontally.

For a different room's measured visible band, calibrate the **play URL** once:
`viewer.html?uiTop=25&uiBottom=-10&uiScale=0.85`. Values are degrees relative to
the panorama horizon; `uiScale` requests an overall size multiplier, but the
vertical safety limits always take priority. The defaults are top `25`, bottom
`-10`, scale `0.85`; the inspection bar sits above the horizon. All controls
use the same projection for drawing and picking. Actual hazard targets remain
aligned with photographed objects, including genuine ground-level hazards.
These parameters adjust lesson UI only, not the background or ICE effects.

The supplied background is an **AI-generated illustration**, 1774×887, not a
verified seamless 360 capture. A 2:1 aspect ratio alone does not prove correct
panorama geometry. Check seams, orientation and perspective in ICE, and replace
the image with a verified capture if necessary. Larger output resolution does
not invent missing image detail.

## Run a lesson

1. Open the play page directly. Click **Start inspection** in the room panel.
   No editor/tutor connection is required. A saved run offers **Resume inspection**.
2. Look for unsafe situations. Hover highlights the clickable hazard; **Hints**
   adds location rings. Use a mouse, compatible pointer or room touch.
3. Select a hazard. Its question appears in the room near that direction. Choose
   a risk level, **Choose response**, select an answer and **Commit decision**.
4. Read the feedback/discussion prompt, then **Continue inspection**. Use **Pause**
   for teaching discussion. Basic controls remain on the front wall during inspection.
   Long feedback uses **More feedback** pages rather than shrinking the text;
   continue after the last page. Text is larger/bolder on an opaque panel to
   preserve contrast without enlarging or lowering the wall-centred popups.
5. Review all hazards in the debrief, including missed ones. A text report can
   download to the browser/ICE host device if that host permits downloads.

In desktop preview, drag or use Left/Right arrows to look. Clicking a hazard
turns that preview toward its question panel. Enter starts the introduction;
Escape pauses/resumes. Tab provides clipped screen-reader/keyboard equivalents
of the same lesson controls, including an alternative to spatial hazard picking.

One group or two alternating teams is configurable. Each hazard records one
first decision: 20 points for the risk guide, 80 for the response. These are
simplified teaching judgements, not a full likelihood/severity risk matrix.
No speed bonus, phone multiplayer, body tracking or formal assessment validation
is included. The clock continues in background tabs; pause explicitly.

Progress is saved in the **play browser**, keyed by room and published revision,
where localStorage is available. Old tutor-v2 saves are left untouched. Missing
storage does not prevent play. Closing the editor or losing the publishing
connection does not lock questions or stop a loaded lesson.

## Prepare and publish

- Edit the lesson title, instructions, teams, clock and default hint setting.
- Select a hazard to edit its question, risk guide, three options, correct answer,
  consequence, safer approach and discussion prompt. On narrower screens the
  question form is below the image; **Edit this hazard's question** jumps to it.
- Drag the selected image region to reposition it, or set its Left/Top/Width/Height
  percentages. Its marker follows the region centre. Only published positions
  affect learners; hover regions in the editor are not the actual lesson UI.
- Replace the background with PNG/JPEG/WebP up to 12 MB. The editor requires a
  2:1 image. Reposition/check every hazard and confirm scene review before publishing.
  Maintain accurate provenance/usage-rights text; uploading a real photograph
  should not be labelled AI-generated.
- **Publish changes** saves the activity on the local host and notifies play pages.
  Intro screens can adopt it immediately. Active lessons retain their current
  questions and scoring, and offer a deliberate restart/load-update control.
  Publishing never silently swaps the answer key mid-question.
- Drafts save locally in the editor browser. Export/import JSON for backup.
  Exported JSON references the image; it does **not** bundle uploaded image bytes.
  Reupload/copy custom assets when moving activities to another host.
- Existing eight hazards can be edited/repositioned. Import supports validated
  configurations with 1–12 hazards; there is not yet an add/remove-hazard UI.

## Local hosting and data

- The host binds to `127.0.0.1`; another PC/device needs a reachable host address.
  Explicitly set `HOST=0.0.0.0` for a trusted venue LAN, and use that PC's IP in
  both links. `PORT` changes 8787. Windows firewall permissions may need setup.
- Use matching `?room=construction-a` parameters to isolate activities. Room
  names use letters, numbers, `_` and `-`, up to 40 characters. They are not passwords.
- Publishing uses same-origin HTTP/SSE, not shared browser storage. ICE and the
  editor may be separate browser processes. Optimistic revision checks prevent
  another editor silently overwriting a newer published version on the same host.
- Avoid leaving many duplicate editor/lesson tabs open: browsers limit long-lived
  HTTP connections. The play page loads its image before subscribing to updates;
  if loading/publishing stalls, close obsolete test tabs and reload once.
- Published configuration and uploaded images persist under **`.local-data/`**
  beside this template, outside `dist/` and ignored by Git. Back this folder up.
  Rebuilding `dist/` does not delete published activities. Do not delete unfamiliar
  files there as a cleanup step. Run a single host against a data directory.
- The service is trusted-network-only, **not an authenticated public platform**.
  Don't expose it to the internet. No learner names are requested; lesson results
  remain in the play browser/report. You are responsible for rights/privacy in uploads.
- A static-only deployment can play the bundled default activity, but cannot
  publish or serve locally uploaded assets without the provided host/API.
  A loaded scene does not need an editor or external AI/asset service to run.

## Code and verification

- `src/main.js`, `src/editor.css`: authoring only.
- `src/lesson-config.js`: defaults and strict publication/import schema.
- `src/lesson-runtime.js`: independent lesson state, scoring, restore.
- `src/output.js`: game input, persistence, updates, report and render orchestration.
- `src/lesson-ui.js`: painted room panels and matching action bounds.
- `src/lesson-renderer.js`: shader-based panorama/perspective output with projected
  panel textures and markers. **No cubemap conversion** is used here.
- `src/projection.js`: shared forward/inverse spherical panel math. Renderer and
  picking must agree; don't replace it with plain screen-coordinate button boxes.
- `scripts/sync-server.mjs`, `scripts/lesson-store.mjs`: publication, uploads and
  persistence. Older tutor-control endpoints remain for compatibility/tests but
  **are not used to gate the current lesson**.
- `vite.config.js`: both HTML entrypoints and dev/preview publishing API.
- `src/scene.js`, `src/photo-viewer.js`, `src/picking.js`, `src/igloo-kit/` and
  `src/style.css`: retained earlier helpers, not the new game/editor entrypoints.

Tests cover schema validation, persistence, standalone progression, team turns,
restored score recalculation, projection/picking round trips, publication conflicts
and transport validation, plus legacy helpers. Also test the built app in a
browser and the actual ICE room. Have a competent construction tutor review the
safety content; this is introductory teaching material, not certification.

Bundled font terms: `public/font-licenses.txt`.
# Two activities / venue delivery

Open **`http://127.0.0.1:8787/sessions.html`** after starting the host.

- **Region quiz:** `region-editor.html` prepares/publishes; `region.html` plays
  independently. Default room `region-quiz`; custom region room names must start
  `region-`. Includes the eight sample questions from QuickFloorSessions. The
  timer or projected **Answer locked in** reveals the answer immediately. Pause
  freezes time; group confidence is a discussion record, not tracked scoring.
- **Spot the Hazard:** existing `index.html` editor / `viewer.html` play links
  and saved publications are unchanged.
- Both ICE play pages are **2:1 equirectangular**, with True Perspective left on.
  Region questions/answers/controls use four wall-centred projected panels;
  matching coloured sectors extend onto the **single merged floor**. Existing
  ICE calibration/blending controls the projector outputs, not webpage tiles.
- Region **Check room alignment** and `roomYaw` calibrate orientation. Example:
  `region.html?roomYaw=90&uiTop=25&uiBottom=-10&uiScale=.85`. Measure in the venue;
  the retrofit diagram is not enough to guarantee source-to-wall orientation.
- For a self-contained Windows copy, build first, then run
  `npm run package:windows -- C:\Delivery\IglooQuizzes` with a **new** destination
  folder. Includes the Windows Node executable, built assets and published data;
  no npm install required on the venue PC. Zip the resulting folder. Read
  **[WINDOWS-QUICKSTART.md](WINDOWS-QUICKSTART.md)** for launch, backup and room checks.
