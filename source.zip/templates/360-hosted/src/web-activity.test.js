import test from "node:test";
import assert from "node:assert/strict";
import { defaultLesson } from "./lesson-config.js";
import { defaultRegionQuiz } from "./region-config.js";
import { encodeActivity,decodeActivity } from "./web-activity.js";

test("both quiz snapshots round-trip across machines via a URL fragment",async()=>{
  for(const config of [defaultLesson(),defaultRegionQuiz()]){
    config.title="Shared lesson · café & <test>";const fragment=await encodeActivity(config);
    assert.ok(fragment.length<24000);assert.deepEqual(await decodeActivity(fragment),config);
  }
});
test("hosted links reject malformed, oversized and local-only scenes",async()=>{
  for(const hash of ["#activity=z!!!","#activity=p"+"a".repeat(25000),"#wrong=hello"]){await assert.rejects(()=>decodeActivity(hash));}
  const c=defaultLesson();c.image="/api/images/aaaaaaaa-aaaa.png";await assert.rejects(()=>encodeActivity(c));
});
