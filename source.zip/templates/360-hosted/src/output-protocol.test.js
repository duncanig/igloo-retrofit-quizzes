import test from "node:test";
import assert from "node:assert/strict";
import { lesson } from "./hazards.js";
import { photoDetails } from "./photo-data.js";
import { HAZARD_IDS, initialOutputState, normaliseOutputState, findPhotoHazard, createClientId } from "./output-protocol.js";

test("output starts non-interactive without a tutor session",()=>{
  assert.deepEqual(initialOutputState(),{interactive:false,reviewed:[],selected:null,paused:false});
});
test("connection IDs work without secure-context randomUUID",()=>{
  assert.match(createClientId({getRandomValues(bytes){bytes.fill(7);return bytes;}}),/^client-[a-f0-9]{32}$/);
  assert.match(createClientId(null),/^[a-zA-Z0-9_-]{1,80}$/);
  assert.match(createClientId({randomUUID(){throw new Error("Insecure context");},getRandomValues(bytes){bytes.fill(1);return bytes;}}),/^client-[a-f0-9]{32}$/);
});
test("protocol identifiers agree with the lesson and image targets",()=>{
  assert.deepEqual([...HAZARD_IDS].sort(),lesson.hazards.map(h=>h.id).sort());
});
test("pausing or opening a question disables room selection",()=>{
  assert.equal(normaliseOutputState({...initialOutputState(),interactive:true,paused:true}).interactive,false);
  assert.equal(normaliseOutputState({...initialOutputState(),interactive:true,selected:"edge"}).interactive,false);
  assert.equal(normaliseOutputState({...initialOutputState(),interactive:true}).interactive,true);
});
test("untrusted state is validated and extra fields are not forwarded",()=>{
  assert.equal(normaliseOutputState({...initialOutputState(),reviewed:["unknown"]}),null);
  assert.equal(normaliseOutputState({...initialOutputState(),selected:"unknown"}),null);
  assert.equal(normaliseOutputState({...initialOutputState(),interactive:"yes"}),null);
  assert.equal(normaliseOutputState({...initialOutputState(),learnerName:"Not transmitted"}).learnerName,undefined);
});
test("image coordinates resolve all eight invisible output hotspots",()=>{
  for(const [id,d] of Object.entries(photoDetails)){
    assert.equal(findPhotoHazard(...d.point,photoDetails),id);
    assert.equal(findPhotoHazard(...d.point,photoDetails,[id]),null);
  }
  assert.equal(findPhotoHazard(.5,.05,photoDetails),null);
  for(const point of [[-1,.5],[1.1,.5],[.5,NaN]])assert.equal(findPhotoHazard(...point,photoDetails),null);
});
