// Adapted from duncanig/QuickFloorSessions region-quiz-floor.html (sample quiz).
export function defaultRegionQuiz() {
  return {schema:1,kind:"region-quiz",revision:"region-1",title:"Move to the Right Region",seconds:30,
    intro:"Read the question on any wall. Walk to your answer region. When the timer ends or the tutor locks the answers, the correct region lights up.",
    regions:["Glacier","Forest","Desert","Reef"],questions:[
      {q:"Which of these numbers is a prime number?",options:["15","21","29","33"],correct:2,why:"29 can only be divided by 1 and itself. The other numbers can all be divided by 3."},
      {q:"What is 15% of 80?",options:["8","10","12","15"],correct:2,why:"10% of 80 is 8, and 5% is 4. Add them together to get 12."},
      {q:"Which gas do plants take in from the air to make their food?",options:["Oxygen","Nitrogen","Carbon dioxide","Hydrogen"],correct:2,why:"Plants use carbon dioxide, water and light to make food, and give out oxygen."},
      {q:"True or false: lightning is hotter than the surface of the Sun.",options:["True","False"],correct:0,why:"Lightning heats the air to about 30,000°C. The surface of the Sun is about 5,500°C."},
      {q:"Which of these is a renewable source of energy?",options:["Coal","Natural gas","Wind","Oil"],correct:2,why:"Wind is renewable. Coal, gas and oil formed over millions of years and are not replaced on human timescales."},
      {q:"In which year did the first person walk on the Moon?",options:["1959","1969","1979","1989"],correct:1,why:"Neil Armstrong stepped onto the Moon on 20 July 1969 during Apollo 11."},
      {q:"A triangle has angles of 90° and 35°. What is the third angle?",options:["45°","55°","65°","125°"],correct:1,why:"Angles in a triangle total 180°. Subtract 90 and 35 to get 55°."},
      {q:"Which of these is NOT a mammal?",options:["Dolphin","Bat","Shark","Whale"],correct:2,why:"A shark is a fish. Dolphins, bats and whales are mammals."},
    ]};
}
const text=(v,max)=>typeof v==="string"&&v.trim().length>0&&v.length<=max;
export function validateRegionQuiz(v) {
  if(!v||v.schema!==1||v.kind!=="region-quiz"||!text(v.revision,80)||!text(v.title,90)||!text(v.intro,450)||
    !Number.isInteger(v.seconds)||v.seconds<5||v.seconds>300||!Array.isArray(v.regions)||v.regions.length!==4||!v.regions.every(r=>text(r,30))||
    !Array.isArray(v.questions)||v.questions.length<1||v.questions.length>40)return null;
  for(const q of v.questions)if(!q||!text(q.q,240)||!text(q.why,1000)||!Array.isArray(q.options)||q.options.length<2||q.options.length>4||
    !q.options.every(o=>text(o,100))||!Number.isInteger(q.correct)||q.correct<0||q.correct>=q.options.length)return null;
  return {schema:1,kind:v.kind,revision:v.revision,title:v.title,intro:v.intro,seconds:v.seconds,regions:[...v.regions],
    questions:v.questions.map(q=>({q:q.q,options:[...q.options],correct:q.correct,why:q.why}))};
}
export const REGION_COLOURS=["#6ec8ff","#5fd38d","#ffb547","#ff7a9a"];
// Preserve the original: two choices occupy opposite walls, three the first three.
export const answerWalls=count=>count===2?[0,2]:Array.from({length:count},(_,i)=>i);
export function wallHeading(wall,rotation=0){return (wall*Math.PI/2)+rotation;}
export function regionAtLongitude(lon,rotation=0){return ((Math.floor((lon-rotation+Math.PI/4)/(Math.PI/2))%4)+4)%4;}
