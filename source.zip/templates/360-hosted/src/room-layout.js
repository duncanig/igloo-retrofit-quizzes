// Wall-centred installation preset. These angles are relative to the panorama's
// horizon, not page pixels. Leave ceiling headroom and minimise floor spill.
export const DEFAULT_ROOM_LAYOUT = Object.freeze({ top: 25, bottom: -10, scale: .85 });
const rad = degrees => degrees * Math.PI / 180;
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

export function roomLayoutFromParams(params) {
  const read = (key, fallback, min, max) => {
    const text = params.get(key);
    if (text === null || text.trim() === "") return fallback;
    const value = Number(text);
    return Number.isFinite(value) ? clamp(value, min, max) : fallback;
  };
  const layout = {
    top: read("uiTop", DEFAULT_ROOM_LAYOUT.top, 0, 35),
    bottom: read("uiBottom", DEFAULT_ROOM_LAYOUT.bottom, -60, 0),
    scale: read("uiScale", DEFAULT_ROOM_LAYOUT.scale, .5, 1.2),
  };
  if(layout.top-layout.bottom<10){layout.top=DEFAULT_ROOM_LAYOUT.top;layout.bottom=DEFAULT_ROOM_LAYOUT.bottom;}
  return layout;
}

export function roomPanel(width, height, { compact = false, lon = 0, layout = DEFAULT_ROOM_LAYOUT } = {}) {
  const top = Math.tan(rad(layout.top)), bottom = Math.tan(rad(layout.bottom));
  const desiredWidth = (compact ? 1.14 : 1.17) * layout.scale;
  const desiredHeight = desiredWidth * height / width;
  // Uniformly scale both axes: never squash text or let a tall panel cross
  // the ceiling/floor limits. This same geometry is used by render and picking.
  const halfHeight = Math.min(desiredHeight, (top - bottom) / 2);
  const halfWidth = halfHeight * width / height;
  const preferredCentre = compact ? Math.tan(rad(12)) : (top + bottom) / 2;
  const offsetY = clamp(preferredCentre, bottom + halfHeight, top - halfHeight);
  return { lon, lat: 0, halfWidth, halfHeight, offsetY };
}
