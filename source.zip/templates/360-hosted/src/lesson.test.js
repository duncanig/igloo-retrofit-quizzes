import test from "node:test";
import assert from "node:assert/strict";
import { defaultLesson, validateLesson, hazardAt } from "./lesson-config.js";
import { newRun,inspect,commit,continueRun,restoreRun } from "./lesson-runtime.js";
import { panelToSource,sourceToPanel,desktopToSource } from "./projection.js";
import { roomPanel,roomLayoutFromParams,DEFAULT_ROOM_LAYOUT } from "./room-layout.js";

test("the bundled lesson is a valid, independently playable configuration",()=>{
  const config=defaultLesson();assert.deepEqual(validateLesson(config),config);assert.equal(newRun(config).phase,"intro");
  for(const h of config.hazards)assert.equal(hazardAt(config,...h.point)?.id,h.id);
});
test("publisher validation rejects unsafe URLs, invalid answer keys and out-of-bounds regions",()=>{
  for(const image of ["https://example.com/track.png","javascript:alert(1)","../private.png","/api/images/file.svg"]){assert.equal(validateLesson({...defaultLesson(),image}),null);}
  const bad=defaultLesson();bad.hazards[0].correct=9;assert.equal(validateLesson(bad),null);
  bad.hazards[0].correct=1;bad.hazards[0].region=[.99,.1,.2,.2];assert.equal(validateLesson(bad),null);
});
test("room decisions work without any editor or server state",()=>{
  const config=defaultLesson(),run=newRun(config);run.phase="hunt";
  for(const h of config.hazards){
    assert.equal(inspect(run,config,h.id),true);assert.equal(commit(run,config),false);
    run.risk=h.risk;run.option=h.correct;assert.equal(commit(run,config),true);assert.equal(commit(run,config),false);
    continueRun(run,config);
  }
  assert.equal(run.phase,"results");assert.equal(run.answers.reduce((s,a)=>s+a.points,0),800);
});
test("two teams alternate in the room and restored scores are recomputed",()=>{
  const config=defaultLesson();config.teams=2;const run=newRun(config);run.phase="hunt";
  for(const h of config.hazards.slice(0,2)){inspect(run,config,h.id);run.risk=h.risk;run.option=h.correct;commit(run,config);continueRun(run,config);}
  assert.deepEqual(run.answers.map(a=>a.team),[0,1]);run.answers[0].points=9999;
  assert.equal(restoreRun(run,config).answers[0].points,100);
  assert.equal(restoreRun({...run,revision:"different"},config),null);
});
test("projection-aware panel hit testing round-trips at the front, sides, floor and seam",()=>{
  for(const lon of [0,Math.PI/2,-Math.PI/2,Math.PI-.01])for(const lat of [0,-.6]){
    const panel={lon,lat,halfWidth:1.17,halfHeight:1.1,offsetY:lat===0?-.9:0};
    for(const [u,v] of [[.1,.1],[.5,.5],[.9,.85]]){
      const source=panelToSource(u,v,panel),local=sourceToPanel(...source,panel);
      assert.ok(local);assert.ok(Math.abs(local[0]-u)<1e-8);assert.ok(Math.abs(local[1]-v)<1e-8);
    }
  }
});
test("the opposite hemisphere cannot click through a projected lesson panel",()=>{
  assert.equal(sourceToPanel(0,.5,{lon:0,lat:0,halfWidth:1,halfHeight:1}),null);
});
test("desktop preview centre follows its camera heading",()=>{
  const [x,y]=desktopToSource(.5,.5,Math.PI/2,1.5);assert.ok(Math.abs(x-.75)<1e-8);assert.equal(y,.5);
});
test("every room panel stays within the wall-centred ceiling and floor safety limits",()=>{
  for(const lon of [0,Math.PI/2,-Math.PI/2,Math.PI-.01])for(const height of [190,220,640,1050]){
    const p=roomPanel(1100,height,{lon,compact:height<=220});
    for(const u of [0,.25,.5,.75,1])for(const v of [0,.25,.5,.75,1]){
      const source=panelToSource(u,v,p),elevation=(.5-source[1])*180;
      assert.ok(elevation<=DEFAULT_ROOM_LAYOUT.top+1e-8);
      assert.ok(elevation>=DEFAULT_ROOM_LAYOUT.bottom-1e-8);
      const local=sourceToPanel(...source,p);
      // Corners can differ by a floating-point epsilon; exercise picking at
      // the same interior positions that actual buttons use.
      if(u>0&&u<1&&v>0&&v<1){assert.ok(local);assert.ok(Math.abs(local[0]-u)<1e-8);assert.ok(Math.abs(local[1]-v)<1e-8);}
    }
    assert.ok(Math.abs(p.halfWidth/p.halfHeight-1100/height)<1e-8);
  }
});
test("room panels are smaller, and the compact inspection bar is raised from floor level",()=>{
  const popup=roomPanel(1100,1050),bar=roomPanel(1100,190,{compact:true});
  assert.ok(popup.halfWidth<1.17);assert.ok(bar.halfWidth<1.14);assert.ok(bar.offsetY>-.9);
  assert.ok(popup.offsetY>0);assert.ok(bar.offsetY-bar.halfHeight>0);
});
test("room URL calibration is bounded and invalid values use the wall-centred defaults",()=>{
  assert.deepEqual(roomLayoutFromParams(new URLSearchParams()),DEFAULT_ROOM_LAYOUT);
  assert.deepEqual(roomLayoutFromParams(new URLSearchParams("uiTop=bad&uiBottom=&uiScale=NaN")),DEFAULT_ROOM_LAYOUT);
  assert.deepEqual(roomLayoutFromParams(new URLSearchParams("uiTop=99&uiBottom=-99&uiScale=10")),{top:35,bottom:-60,scale:1.2});
  assert.deepEqual(roomLayoutFromParams(new URLSearchParams("uiTop=0&uiBottom=0")),DEFAULT_ROOM_LAYOUT);
  const p=roomPanel(1100,1050,{layout:roomLayoutFromParams(new URLSearchParams("uiBottom=-30&uiScale=.7"))});
  assert.ok((.5-panelToSource(.5,1,p)[1])*180>=-30-1e-8);
});
