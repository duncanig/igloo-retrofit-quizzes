import test from "node:test";
import assert from "node:assert/strict";
import { lessonRenderSize } from "./render-size.js";
import { sourceEventPoint } from "./lesson-input.js";
import { panelToSource,sourceToPanel } from "./projection.js";
import { roomPanel } from "./room-layout.js";

test("a 10032×4066 ICE source retains its aspect but does not allocate a 15048×6099 DPR buffer",()=>{
  const s=lessonRenderSize(10032,4066,{dpr:1.5,maxViewport:[8192,8192],maxRenderbuffer:8192,maxTexture:8192});
  assert.equal(s.width,4096);assert.equal(s.height,1660);
  assert.ok(Math.abs(s.width/s.height-10032/4066)<.002);
});
test("room rendering ignores Windows DPI scaling; desktop preview can still supersample",()=>{
  assert.equal(lessonRenderSize(1920,1080,{dpr:1.5}).width,1920);
  assert.equal(lessonRenderSize(1920,1080,{desktop:true,dpr:1.5}).width,2880);
});
test("renderer sizing honours asymmetric GPU viewport limits, renderbuffer and texture limits",()=>{
  for(const limits of [{maxViewport:[2048,4096]},{maxRenderbuffer:1024},{maxTexture:512}]){
    const s=lessonRenderSize(10032,4066,limits),bound=limits.maxViewport?.[0]||limits.maxRenderbuffer||limits.maxTexture;
    assert.ok(s.width<=bound);assert.ok(s.height<=bound);assert.ok(s.width>0&&s.height>0);
    assert.ok(Math.abs(s.width/s.height-10032/4066)<.025);
  }
});
test("2:1, native atlas-shaped and portrait CSS viewports resolve the same projected button",()=>{
  const panel=roomPanel(1100,1050),source=panelToSource(.5,.8,panel);
  for(const [width,height] of [[4096,2048],[10032,4066],[15124,6134],[1080,1920]]){
    const client={clientX:source[0]*width,clientY:source[1]*height};
    const mapped=sourceEventPoint(client,{left:0,top:0,width,height});
    const local=sourceToPanel(...mapped,panel);
    assert.ok(Math.abs(local[0]-.5)<1e-8);assert.ok(Math.abs(local[1]-.8)<1e-8);
  }
});
test("invalid or minimised view dimensions do not produce zero/NaN allocations",()=>{
  for(const [w,h] of [[0,0],[NaN,Infinity],[-1,500]]){
    const s=lessonRenderSize(w,h);assert.ok(Number.isInteger(s.width)&&s.width>0);assert.ok(Number.isInteger(s.height)&&s.height>0);
  }
});
