// Pointer jitter must not turn source-coordinate room taps into desktop drags.
// Compatibility mouse/touch events are deduplicated only after a handled hit;
// a miss must not swallow a later correctly positioned click from the host.
export function createLessonGesture({desktop=false,clock=()=>performance.now(),windowMs=650}={}){
  let pointer=null,lastHandled=null,dragUntil=0;
  const primary=e=>e.isPrimary!==false&&(e.button===undefined||e.button===0);
  return {
    down(e){
      if(!primary(e)||pointer)return false;
      if(e.type==="mousedown"&&lastHandled?.touch&&clock()-lastHandled.time<windowMs)return false;
      pointer={x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY,moved:false};
      lastHandled=null;dragUntil=0;return true;
    },
    move(e){
      if(!pointer)return {drag:false,dx:0};
      if(desktop&&Math.hypot(e.clientX-pointer.startX,e.clientY-pointer.startY)>6)pointer.moved=true;
      const result={drag:desktop&&pointer.moved,dx:e.clientX-pointer.x};
      pointer.x=e.clientX;pointer.y=e.clientY;return result;
    },
    release(){const moved=desktop&&pointer?.moved;pointer=null;if(moved)dragUntil=clock()+350;return !moved;},
    cancel(){pointer=null;if(desktop)dragUntil=clock()+350;},
    blocked(e){return !primary(e)||clock()<dragUntil;},
    duplicate(){return !!lastHandled&&clock()-lastHandled.time<windowMs;},
    handled(e){lastHandled={x:e.clientX,y:e.clientY,time:clock(),touch:e.pointerType==="touch"||e.type==="touchend"};},
  };
}

export function sourceEventPoint(event,rect){
  if(!(rect.width>0&&rect.height>0)||!Number.isFinite(event.clientX)||!Number.isFinite(event.clientY))return null;
  const x=(event.clientX-rect.left)/rect.width,y=(event.clientY-rect.top)/rect.height;
  return x>=0&&x<=1&&y>=0&&y<=1?[x,y]:null;
}

// Diagnostics are appended to the SAME projected panel texture. They are not a
// flat overlay captured in the wrong coordinate space by True Perspective.
export function inputDiagnosticCanvas(original){
  const canvas=document.createElement("canvas");canvas.width=original.width;canvas.height=original.height+280;
  canvas.getContext("2d").drawImage(original,0,0);return canvas;
}
export function paintInputDiagnostic(canvas,lines){
  const c=canvas.getContext("2d"),top=canvas.height-280;
  c.fillStyle="#061b31";c.fillRect(0,top,canvas.width,280);c.fillStyle="#faffef";c.font="700 25px Arial,sans-serif";
  lines.forEach((line,i)=>c.fillText(line,25,top+35+i*34));
}
