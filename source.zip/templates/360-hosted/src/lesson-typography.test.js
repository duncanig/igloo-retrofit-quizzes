import test from "node:test";
import assert from "node:assert/strict";
import { wrapMeasuredText,paginateFeedback } from "./lesson-typography.js";
import { paintLessonUI } from "./lesson-ui.js";
import { defaultLesson } from "./lesson-config.js";
import { newRun } from "./lesson-runtime.js";

test("measured wrapping preserves words and breaks oversized unspaced text",()=>{
  const rows=wrapMeasuredText("A longwordwithoutspaces and more text",10,value=>value.length);
  assert.ok(rows.every(row=>row.length<=10));
  assert.equal(rows.join("").replaceAll(" ",""),"Alongwordwithoutspacesandmoretext");
});
test("long feedback is paged, not discarded or shrunk",()=>{
  const body=Array.from({length:60},(_,i)=>`line ${i}`);
  const pages=paginateFeedback([{label:"SAFER APPROACH",text:"body"}],()=>body,300);
  assert.ok(pages.length>1);
  assert.deepEqual(pages.flat().filter(row=>row.kind==="body").map(row=>row.text),body);
  assert.ok(pages.flat().every(row=>row.y+row.height<=300));
  assert.ok(pages.every(page=>page.some(row=>row.kind==="body")));
});

function fakeDocument(){return {createElement(){
  const draws=[],ctx={font:"",fillStyle:"",strokeStyle:"",lineWidth:1,
    beginPath(){},roundRect(){},fill(){},stroke(){},fillRect(){},drawImage(){},
    measureText(value){const size=Number(/([\d.]+)px/.exec(this.font)?.[1]||29);return {width:[...String(value)].reduce((s,c)=>s+(c===" "?.28:.56)*size,0)};},
    fillText(value,x,y){draws.push({value,x,y,size:Number(/([\d.]+)px/.exec(this.font)?.[1]||29),width:this.measureText(value).width});}};
  return {width:0,height:0,getContext(){return ctx;},draws};
}};}
function checkActions(ui){
  for(const a of ui.actions){assert.ok(a.x>=0&&a.y>=0&&a.x+a.w<=ui.canvas.width&&a.y+a.h<=ui.canvas.height,`out of bounds: ${a.key}`);}
  for(let i=0;i<ui.actions.length;i++)for(const b of ui.actions.slice(i+1)){
    const a=ui.actions[i],overlap=a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
    assert.equal(overlap,false,`overlapping controls: ${a.key}, ${b.key}`);
  }
}
test("larger type retains non-overlapping controls for every bundled question and response",t=>{
  const old=globalThis.document;globalThis.document=fakeDocument();t.after(()=>{globalThis.document=old;});
  const config=defaultLesson(),run=newRun(config);run.phase="question";
  for(const h of config.hazards){run.selected=h.id;run.risk=h.risk;run.option=0;
    for(const step of [0,1])checkActions(paintLessonUI({config,run,step}));
  }
  assert.ok(paintLessonUI({config,run,step:0}).canvas.draws.some(d=>d.size===31));
});
test("long authored answers and feedback remain readable without clipped controls",t=>{
  const old=globalThis.document;globalThis.document=fakeDocument();t.after(()=>{globalThis.document=old;});
  const config=defaultLesson(),h=config.hazards[0];h.title="A carefully described construction hazard requiring a safe and effective workplace response";
  h.prompt=("Inspect this situation before choosing a safe response. ".repeat(12)).slice(0,500);
  h.options=h.options.map(()=>"Arrange suitable source controls and competent supervision before restarting the work. ".repeat(5).slice(0,300));
  h.consequence="Potential serious harm to workers and nearby people. ".repeat(20).slice(0,600);
  h.explanation="Keep people clear and arrange a competent assessment of effective collective protection. ".repeat(20).slice(0,1000);
  h.discussion="Which control protects everyone, and who needs to be informed before work resumes? ".repeat(8).slice(0,400);
  const run=newRun(config);run.phase="question";run.selected=h.id;run.risk=h.risk;run.option=0;
  for(const step of [0,1])checkActions(paintLessonUI({config,run,step}));
  run.phase="feedback";const first=paintLessonUI({config,run});assert.ok(first.feedbackPageCount>1);
  for(let textPage=0;textPage<first.feedbackPageCount;textPage++){
    const ui=paintLessonUI({config,run,textPage});checkActions(ui);
    assert.ok(ui.canvas.draws.filter(d=>d.size===28).length>0);
    assert.ok(ui.canvas.draws.every(d=>d.y<=ui.canvas.height));
  }
});
