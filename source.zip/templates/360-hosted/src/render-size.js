// Equirectangular longitude/latitude are encoded in normalised UVs, not in a
// required DOM aspect ratio. Keep the full viewport visible while bounding the
// internal GPU allocation independently of ICE's locked source dimensions.
export function lessonRenderSize(width,height,{desktop=false,dpr=1,maxDimension=4096,maxViewport=[4096,4096],maxRenderbuffer=4096,maxTexture=4096}={}){
  width=Number.isFinite(width)&&width>0?width:1;height=Number.isFinite(height)&&height>0?height:1;
  const ratio=desktop?Math.min(Math.max(Number.isFinite(dpr)?dpr:1,1),1.5):1;
  const safe=n=>Number.isFinite(n)&&n>=1?n:1;
  const limitX=Math.min(safe(maxDimension),safe(maxViewport[0]),safe(maxRenderbuffer),safe(maxTexture));
  const limitY=Math.min(safe(maxDimension),safe(maxViewport[1]),safe(maxRenderbuffer),safe(maxTexture));
  const scale=Math.min(ratio,limitX/width,limitY/height);
  return {width:Math.max(1,Math.floor(width*scale)),height:Math.max(1,Math.floor(height*scale)),scale,
    cssWidth:width,cssHeight:height,browserDpr:dpr};
}
