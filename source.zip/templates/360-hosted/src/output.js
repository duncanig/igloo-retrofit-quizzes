import { defaultLesson, validateLesson, hazardAt } from "./lesson-config.js";
import { newRun, inspect, commit, continueRun, restoreRun } from "./lesson-runtime.js";
import { direction, sourcePoint, panelToSource, sourceToPanel, desktopToSource } from "./projection.js";
import { paintLessonUI } from "./lesson-ui.js";
import { createLessonRenderer } from "./lesson-renderer.js";
import { createOutputLink,STATIC_HOST } from "./output-link.js";
import { formatTime } from "./hazards.js";
import { roomPanel, roomLayoutFromParams } from "./room-layout.js";
import { createLessonGesture,sourceEventPoint,inputDiagnosticCanvas,paintInputDiagnostic } from "./lesson-input.js";

// The lesson owns its state and input. Publishing/editor connections are optional
// once loaded; closing the editor must never lock an active room lesson.
const params=new URLSearchParams(location.search), desktop=params.get("desktop")==="1";
const roomLayout=roomLayoutFromParams(params);
const inputDebug=params.get("inputDebug")==="1",gesture=createLessonGesture({desktop});
const inputLog={down:0,up:0,click:0,touch:0,key:0,last:"none",raw:null,source:null,result:"Waiting for input"};
const room=params.get("room")||"construction", canvas=document.getElementById("lesson"), accessible=document.getElementById("accessible");
const renderer=createLessonRenderer(canvas,{desktop});
let config=defaultLesson(),run=newRun(config),saved=null,pending=null,earlyLesson=null;
let image=null,ready=false,bootstrapped=false,step=0,review=null,page=0,textPage=0,yaw=0,panelLon=0;
let hover=null,hoverHazard=null,notice="",noticeUntil=0,ui=null,panel=null,dirty=true,storageWarning=false,imageRequest=0;
let lastAccessible="",lastSecond=-1,saveAfter=0,drawScheduled=false;
const marks=document.createElement("canvas");marks.width=2048;marks.height=1024;
const key=()=>`igloo-play-v1:${room}:${config.revision}`;
// Event-driven rendering also works in offscreen CEF views where compositor
// requestAnimationFrame callbacks may be suspended despite a visible document.
function requestDraw(){
  dirty=true;if(drawScheduled)return;drawScheduled=true;
  setTimeout(()=>{drawScheduled=false;if(dirty){dirty=false;draw();}},0);
}
const link=createOutputLink({role:"viewer",defer:true,onLesson(value){
  const valid=validateLesson(value);if(!valid)return;
  if(!bootstrapped){earlyLesson=valid;return;}
  if(valid.revision===config.revision)return;
  if(run.phase==="intro")load(valid);else{pending=valid;requestDraw();}
}});
function persist(){
  if(run.phase==="intro")return;
  try{localStorage.setItem(key(),JSON.stringify(run));}catch{storageWarning=true;}
}
function tell(text){notice=text;noticeUntil=performance.now()+5000;requestDraw();}
function showSelected(){const h=config.hazards.find(h=>h.id===(review||run.selected));panelLon=h?(h.point[0]-.5)*Math.PI*2:0;if(desktop)yaw=panelLon;}
function load(value){
  config=value;run=newRun(config);saved=null;pending=null;review=null;page=0;textPage=0;step=0;panelLon=0;yaw=0;ready=false;
  try{const restored=restoreRun(JSON.parse(localStorage.getItem(key())),config);if(restored&&restored.phase!=="intro")saved=restored;}catch{storageWarning=true;}
  const request=++imageRequest,next=new Image();
  next.onload=()=>{if(request!==imageRequest)return;image=next;ready=true;renderer.image(image);link.ready({ready:true,aspect:innerWidth/innerHeight});link.connect();requestDraw();};
  next.onerror=()=>{if(request!==imageRequest)return;ready=false;link.connect();tell("The scene could not load. Check the local host and published image, then reload the lesson.");};
  next.src=new URL(config.image,document.baseURI).href;
  requestDraw();
}
async function start(){
  try{
    const value=await Promise.race([link.lesson(),new Promise((_,reject)=>setTimeout(()=>reject(new Error("offline")),3000))]);
    load(validateLesson(value)||defaultLesson());
  }catch{
    if(STATIC_HOST&&location.hash){const error=document.createElement("p");error.textContent="This activity link is invalid or too large. Ask the tutor for a new play link.";document.body.replaceChildren(error);return;}
    load(earlyLesson||defaultLesson());tell("Publishing host unavailable. Using the bundled activity; check this is the intended lesson.");
  }
  bootstrapped=true;
}
start();

function download(){
  const text=[config.title,`Revision: ${config.revision}`,`Reviewed: ${run.answers.length}/${config.hazards.length}`,`Time: ${formatTime(run.elapsed)}`,
    `Points: ${run.answers.reduce((s,a)=>s+a.points,0)}/${config.hazards.length*100}`,"AI-generated or institution-supplied training scene. Learning record, not certification.","",
    ...config.hazards.flatMap(h=>{const a=run.answers.find(a=>a.id===h.id);return [h.title,a?`Team ${a.team+1}: ${a.points}/100. Response: ${h.options[a.option]}`:"Not reviewed",`Safer approach: ${h.explanation}`,`Discuss: ${h.discussion}`,""];})].join("\r\n");
  const url=URL.createObjectURL(new Blob([text],{type:"text/plain;charset=utf-8"})),a=document.createElement("a");a.href=url;a.download="hazard-hunt-learning-report.txt";a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
}
function act(action){
  if(!ready){tell("Please wait for the scene image to load.");return;}
  if(action==="start"){
    run=saved||newRun(config);saved=null;
    if(run.phase==="intro")run.phase="hunt";
    if(run.phase==="question"||run.phase==="feedback")showSelected();
  }
  else if(action==="new"){run=newRun(config);run.phase="hunt";saved=null;review=null;page=0;textPage=0;panelLon=0;yaw=0;}
  else if(action==="hints")run.hints=!run.hints;
  else if(action==="pause"){run.pausedFrom=run.phase;run.phase="pause";}
  else if(action==="resume")run.phase=run.pausedFrom;
  else if(action==="finish"){
    if(run.phase==="pause"){run.phase="results";run.selected=null;panelLon=0;if(desktop)yaw=0;}
    else {run.pausedFrom=run.phase;run.phase="pause";}
  }
  else if(action.startsWith("risk:"))run.risk=action.slice(5);
  else if(action==="response"){step=1;}
  else if(action.startsWith("option:"))run.option=Number(action.slice(7));
  else if(action==="risk-step")step=0;
  else if(action==="back-site"){run.selected=null;run.phase="hunt";panelLon=0;step=0;}
  else if(action==="commit"){if(commit(run,config))textPage=0;}
  else if(action==="continue"){continueRun(run,config);panelLon=0;step=0;textPage=0;}
  else if(action.startsWith("review:")){review=action.slice(7);textPage=0;showSelected();}
  else if(action==="back-results"){review=null;panelLon=0;if(desktop)yaw=0;}
  else if(action==="next-page")page++;
  else if(action==="prev-page")page=Math.max(0,page-1);
  else if(action==="feedback-next")textPage++;
  else if(action==="feedback-prev")textPage=Math.max(0,textPage-1);
  else if(action==="report")download();
  else if(action==="update"&&pending){
    if(["intro","pause","results"].includes(run.phase))load(pending);
    else{run.pausedFrom=run.phase;run.phase="pause";}
  }
  hover=null;hoverHazard=null;persist();requestDraw();
}
function inputSource(event){
  const r=canvas.getBoundingClientRect(),point=sourceEventPoint(event,r);if(!point)return null;
  return desktop?desktopToSource(...point,yaw,r.width/r.height):point;
}
function hit(point){
  if(!point||!panel||!ui)return null;
  const local=sourceToPanel(...point,panel);if(!local)return null;
  const x=local[0]*ui.canvas.width,y=local[1]*ui.canvas.height;
  return ui.actions.find(a=>x>=a.x&&x<=a.x+a.w&&y>=a.y&&y<=a.y+a.h)?.key||null;
}
function logInput(type,event,result){
  if(!inputDebug)return;
  inputLog.last=type;inputLog.raw=[event.clientX,event.clientY];inputLog.source=inputSource(event);inputLog.result=result;
  requestDraw();
}
function click(event){
  if(gesture.blocked(event)){logInput(event.type,event,"Non-primary input / desktop drag ignored");return;}
  if(gesture.duplicate(event)){logInput(event.type,event,"Compatibility event · already handled");return;}
  const source=inputSource(event);if(!source){logInput(event.type,event,"Coordinates outside the WebView CSS bounds");return;}
  const action=hit(source);
  if(action){logInput(event.type,event,`${action} · ${ready?"handled":"image not ready"}`);gesture.handled(event);act(action);return;}
  logInput(event.type,event,"Miss · no button or hazard at this source point");
  if(panel&&sourceToPanel(...source,panel))return;
  if(run.phase!=="hunt"){tell("Use the lesson panel to continue. It appears near the selected hazard, or on the front wall.");return;}
  const h=hazardAt(config,...source);
  if(!h){tell("Look for an unsafe situation. Turn Hints on using the lesson controls on the front wall.");return;}
  if(run.answers.some(a=>a.id===h.id)){tell("You have already reviewed that hazard. Find another one, or open the debrief.");return;}
  if(inspect(run,config,h.id)){gesture.handled(event);logInput(event.type,event,`Hazard ${h.id} · handled`);step=0;showSelected();persist();requestDraw();}
}
// Native CEF events normally target the canvas. Some forwarding integrations
// dispatch to the document/root instead; handle those at the same coordinates,
// but never intercept real DOM buttons (keyboard accessibility controls).
function listenInput(type,handler,options={}){
  window.addEventListener(type,e=>{
    if([canvas,document,window,document.body,document.documentElement].includes(e.target))handler(e);
  },{capture:true,...options});
}
listenInput("pointerdown",e=>{gesture.down(e);inputLog.down++;logInput(e.type,e,"Press received");});
listenInput("mousedown",e=>{if(gesture.down(e)){inputLog.down++;logInput(e.type,e,"Mouse press received");}});
listenInput("pointermove",e=>{
  const movement=gesture.move(e);if(movement.drag){yaw-=movement.dx*.004;requestDraw();}
  const source=inputSource(e),next=hit(source),onPanel=source&&panel&&sourceToPanel(...source,panel),h=source&&run.phase==="hunt"&&!onPanel?hazardAt(config,...source):null;
  const nextHazard=h&&!run.answers.some(a=>a.id===h.id)?h.id:null;
  if(next!==hover||nextHazard!==hoverHazard){hover=next;hoverHazard=nextHazard;requestDraw();}
  canvas.style.cursor=next||nextHazard?"pointer":desktop?"grab":"crosshair";
});
listenInput("pointerup",e=>{inputLog.up++;if(gesture.release())click(e);else logInput(e.type,e,"Desktop drag · no activation");});
listenInput("mouseup",e=>{inputLog.up++;gesture.release();click(e);});
listenInput("pointercancel",e=>{gesture.cancel();logInput(e.type,e,"Pointer cancelled by host");});
listenInput("touchend",e=>{inputLog.touch++;const point=e.changedTouches?.[0];if(point){gesture.release();click({type:"touchend",clientX:point.clientX,clientY:point.clientY,button:0});}},{passive:true});
listenInput("click",e=>{inputLog.click++;click(e);});
window.addEventListener("keydown",e=>{
  if(inputDebug){inputLog.key++;inputLog.last=`key ${e.key}`;requestDraw();}
  if(e.target.closest("button"))return;
  if(e.key==="Escape"){if(run.phase==="pause")act("resume");else if(["hunt","question","feedback"].includes(run.phase))act("pause");}
  if(desktop&&(e.key==="ArrowLeft"||e.key==="ArrowRight")){e.preventDefault();yaw+=e.key==="ArrowLeft"?.22:-.22;requestDraw();}
  if(e.key==="Enter"&&run.phase==="intro")act("start");
});
window.addEventListener("resize",()=>{renderer.resize();link.ready({ready,aspect:innerWidth/innerHeight});requestDraw();});
window.addEventListener("pagehide",()=>{persist();link.close();});
let last=performance.now();
setInterval(()=>{
  const now=performance.now(),dt=(now-last)/1000;last=now;
  if(["hunt","question","feedback"].includes(run.phase)){
    run.elapsed+=dt;saveAfter+=dt;
    if(config.duration&&run.elapsed>=config.duration){run.elapsed=config.duration;run.phase="results";run.selected=null;panelLon=0;if(desktop)yaw=0;persist();requestDraw();}
    if(Math.floor(run.elapsed)!==lastSecond){lastSecond=Math.floor(run.elapsed);requestDraw();}
    if(saveAfter>5){saveAfter=0;persist();}
  }
  if(notice&&now>noticeUntil){notice="";requestDraw();}
},250);

function drawMarker(x,y,color,index){
  const c=marks.getContext("2d"),n=direction(x,y),lon=(x-.5)*Math.PI*2,right=[Math.cos(lon),0,-Math.sin(lon)];
  const up=[n[1]*right[2]-n[2]*right[1],n[2]*right[0]-n[0]*right[2],n[0]*right[1]-n[1]*right[0]];
  const radius=(hoverHazard===index?4.3:3.1)*Math.PI/180;
  c.strokeStyle=color;c.lineWidth=3;c.beginPath();let previous=null;
  for(let i=0;i<=64;i++){
    const a=i/64*Math.PI*2,p=n.map((v,j)=>v*Math.cos(radius)+(right[j]*Math.cos(a)+up[j]*Math.sin(a))*Math.sin(radius));
    const [sx,sy]=sourcePoint(p),px=sx*marks.width,py=sy*marks.height;
    if(!previous||Math.abs(sx-previous)>.5)c.moveTo(px,py);else c.lineTo(px,py);previous=sx;
  }
  c.stroke();
}
function draw(){
  ui=paintLessonUI({config,run,image,step,review,page,textPage,hover,notice:notice||(!ready?"Loading scene…":""),pending:!!pending,saved:!!saved,storageWarning,ready});
  if(inputDebug)ui.canvas=inputDiagnosticCanvas(ui.canvas);
  panel=roomPanel(ui.canvas.width,ui.canvas.height,{compact:run.phase==="hunt",lon:run.phase==="hunt"?0:panelLon,layout:roomLayout});
  if(inputDebug){
    const render=renderer.diagnostics();
    const startAction=ui.actions.find(a=>a.key==="start"),target=startAction?panelToSource((startAction.x+startAction.w/2)/ui.canvas.width,(startAction.y+startAction.h/2)/ui.canvas.height,panel):null;
    const fmt=p=>p?p.map(n=>Number.isFinite(n)?n.toFixed(3):"invalid").join(", "):"none";
    paintInputDiagnostic(ui.canvas,[
      `INPUT CHECK · ${run.phase} · image ${ready?"READY":"NOT READY"} · ${innerWidth}×${innerHeight} CSS`,
      `Render ${render.width}×${render.height} · actual ${render.actualWidth}×${render.actualHeight} · DPR ${render.browserDpr}`,
      `GPU: viewport ${render.maxViewport.join("×")} · renderbuffer ${render.maxRenderbuffer} · texture ${render.maxTexture}`,
      `Down ${inputLog.down} · Up ${inputLog.up} · Click ${inputLog.click} · Touch ${inputLog.touch} · Keys ${inputLog.key}`,
      `Last ${inputLog.last} · raw ${fmt(inputLog.raw)} · source ${fmt(inputLog.source)}`,
      inputLog.result,
      target?`Start centre: source ${fmt(target)} · Enter also starts/resumes`:`Pink ring = received source point · keep True Perspective on`,
    ]);
    canvas.dataset.input=JSON.stringify(inputLog);
    canvas.dataset.render=JSON.stringify(render);canvas.dataset.uiSize=JSON.stringify([ui.canvas.width,ui.canvas.height]);
  }
  renderer.panel(ui.canvas,panel);
  const c=marks.getContext("2d");c.clearRect(0,0,marks.width,marks.height);
  for(const h of config.hazards){const done=run.answers.some(a=>a.id===h.id);if(done||run.phase==="hunt"&&(run.hints||hoverHazard===h.id))drawMarker(...h.point,done?"#9ce0bb":"#ffe090",h.id);}
  if(inputDebug&&inputLog.source)drawMarker(...inputLog.source,"#ff62db","input-debug");
  renderer.marks(marks);renderer.draw(yaw);
  // A keyboard/screen-reader equivalent of the same projected controls. It is
  // visually clipped, so no unprojected menu is captured by ICE.
  const signature=run.phase+run.selected+review+step+textPage+ui.actions.map(a=>a.key+a.label).join();
  if(signature!==lastAccessible){
    const old=document.activeElement?.dataset?.actionKey;accessible.replaceChildren();
    const summary=document.createElement("p");summary.textContent=ui.description;accessible.append(summary);
    for(const a of ui.actions){const button=document.createElement("button");button.textContent=a.label;button.dataset.actionKey=a.key;button.addEventListener("click",()=>act(a.key));button.addEventListener("focus",()=>{hover=a.key;requestDraw();});accessible.append(button);}
    if(run.phase==="hunt")for(const h of config.hazards){if(run.answers.some(a=>a.id===h.id))continue;const b=document.createElement("button");b.textContent=`Inspect ${h.zone} detail ${config.hazards.indexOf(h)+1}`;b.addEventListener("click",()=>{if(inspect(run,config,h.id)){step=0;showSelected();persist();requestDraw();}});accessible.append(b);}
    accessible.querySelector(`[data-action-key="${old||"none"}"]`)?.focus();lastAccessible=signature;
  }
  canvas.dataset.phase=run.phase;canvas.dataset.panel=JSON.stringify(panel);
}
requestDraw();
