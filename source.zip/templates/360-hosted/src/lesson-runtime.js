import { assess } from "./hazards.js";

export function newRun(config) {
  return { version: 1, revision: config.revision, phase: "intro", elapsed: 0, answers: [],
    selected: null, risk: null, option: null, hints: config.hints, pausedFrom: "hunt" };
}
export function inspect(run, config, id) {
  if (run.phase !== "hunt" || run.answers.some(a => a.id === id) || !config.hazards.some(h => h.id === id)) return false;
  run.selected = id;run.risk = null;run.option = null;run.phase = "question";return true;
}
export function commit(run, config) {
  const h = config.hazards.find(h => h.id === run.selected);
  if (run.phase !== "question" || !h || !["critical", "high", "low"].includes(run.risk) ||
      !Number.isInteger(run.option) || run.option < 0 || run.option > 2 || run.answers.some(a => a.id === h.id)) return false;
  run.answers.push({ id: h.id, risk: run.risk, option: run.option, team: run.answers.length % config.teams, ...assess(h, run.risk, run.option) });
  run.phase = "feedback";return true;
}
export function continueRun(run, config) {
  run.selected = null;run.risk = null;run.option = null;
  run.phase = run.answers.length === config.hazards.length ? "results" : "hunt";
}
export function restoreRun(value, config) {
  if (!value || value.version !== 1 || value.revision !== config.revision || !["intro", "hunt", "question", "feedback", "pause", "results"].includes(value.phase) ||
      !Number.isFinite(value.elapsed) || value.elapsed < 0 || !Array.isArray(value.answers) || value.answers.length > config.hazards.length) return null;
  const ids = new Set(), clean = newRun(config);
  for (const answer of value.answers) {
    const h = config.hazards.find(h => h.id === answer.id);
    if (!h || ids.has(h.id) || !["critical", "high", "low"].includes(answer.risk) || !Number.isInteger(answer.option) || answer.option < 0 || answer.option > 2) return null;
    ids.add(h.id);clean.answers.push({ id: h.id, risk: answer.risk, option: answer.option, team: clean.answers.length % config.teams, ...assess(h, answer.risk, answer.option) });
  }
  clean.elapsed = value.elapsed;clean.phase = value.phase;clean.hints = !!value.hints;
  if (config.hazards.some(h => h.id === value.selected)) clean.selected = value.selected;
  clean.risk = ["critical", "high", "low"].includes(value.risk) ? value.risk : null;
  clean.option = Number.isInteger(value.option) && value.option >= 0 && value.option < 3 ? value.option : null;
  if (["question", "feedback"].includes(clean.phase) && !clean.selected) clean.phase = "hunt";
  if (clean.phase === "feedback" && !clean.answers.some(a => a.id === clean.selected)) clean.phase = "hunt";
  clean.pausedFrom = ["hunt", "question", "feedback"].includes(value.pausedFrom) ? value.pausedFrom : "hunt";
  return clean;
}
