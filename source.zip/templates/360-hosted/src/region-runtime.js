export function newRegionRun(){return {phase:"intro",index:0,deadline:null,remaining:0,ratings:[]};}
export function startQuestion(run,config,now){run.phase="ask";run.remaining=config.seconds*1000;run.deadline=now+run.remaining;}
export function lockRegionAnswer(run,now){
  if(run.phase!=="ask")return false;
  run.remaining=Math.max(0,run.deadline-now);run.deadline=null;run.phase="reveal";return true;
}
export function tickRegion(run,now){return run.phase==="ask"&&now>=run.deadline?lockRegionAnswer(run,now):false;}
export function pauseRegion(run,now){if(run.phase!=="ask")return false;run.remaining=Math.max(0,run.deadline-now);run.deadline=null;run.phase="pause";return true;}
export function resumeRegion(run,now){if(run.phase!=="pause")return false;run.deadline=now+run.remaining;run.phase="ask";return true;}
export function nextRegion(run,config,rating,now){
  if(run.phase!=="reveal"||!["confident","revisit"].includes(rating))return false;
  run.ratings.push(rating);run.index++;
  if(run.index>=config.questions.length){run.phase="end";run.deadline=null;}else startQuestion(run,config,now);
  return true;
}
