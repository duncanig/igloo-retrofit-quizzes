import test from "node:test";
import assert from "node:assert/strict";
import * as THREE from "three";
import { pointerRay, pickHazard } from "./picking.js";

const camera=new THREE.PerspectiveCamera(65,1,.1,150);
camera.position.set(0,2.2,0);camera.updateMatrixWorld();
const rect={left:30,top:250,width:1200,height:200};
test("letterbox and outer edges do not select a face",()=>{
  for(const [x,y] of [[40,249],[29,300],[1230,300],[40,450]]) assert.equal(pointerRay(x,y,rect,true,camera),null);
});
test("the six strip centres point left, front, right, back, down and up",()=>{
  const expected=[[-1,0,0],[0,0,-1],[1,0,0],[0,0,1],[0,-1,0],[0,1,0]];
  for(let i=0;i<6;i++) {
    const ray=pointerRay(30+i*200+100,350,rect,true,camera).ray;
    assert.ok(ray.direction.dot(new THREE.Vector3(...expected[i]))>.9999);
    assert.ok(ray.origin.distanceTo(camera.position)<.00001);
  }
});
test("flat preview uses the perspective camera",()=>{
  const ray=pointerRay(400,300,{left:0,top:0,width:800,height:600},false,camera).ray;
  assert.ok(ray.direction.dot(new THREE.Vector3(0,0,-1))>.9999);
});
test("invisible interaction volumes are picked, reviewed hazards are skipped",()=>{
  const target=new THREE.Mesh(new THREE.SphereGeometry(1,12,8),new THREE.MeshBasicMaterial({visible:false}));
  target.position.set(0,2.2,-10);target.userData.hazardId="example";target.updateMatrixWorld();
  const r={left:0,top:0,width:800,height:600};
  assert.equal(pickHazard(400,300,r,false,camera,[target],[]),"example");
  assert.equal(pickHazard(400,300,r,false,camera,[target],[{id:"example"}]),undefined);
  target.geometry.dispose();target.material.dispose();
});
