const TAU = Math.PI * 2;
export function direction(x, y) {
  const lon = (x - .5) * TAU, lat = (.5 - y) * Math.PI;
  return [Math.sin(lon) * Math.cos(lat), Math.sin(lat), Math.cos(lon) * Math.cos(lat)];
}
export function sourcePoint(vector) {
  const length = Math.hypot(...vector);
  return [((Math.atan2(vector[0], vector[2]) / TAU + .5) % 1 + 1) % 1,
    .5 - Math.asin(Math.max(-1, Math.min(1, vector[1] / length))) / Math.PI];
}
export function panelBasis(lon = 0, lat = 0) {
  return { forward: [Math.sin(lon)*Math.cos(lat), Math.sin(lat), Math.cos(lon)*Math.cos(lat)],
    right: [Math.cos(lon), 0, -Math.sin(lon)], up: [-Math.sin(lon)*Math.sin(lat), Math.cos(lat), -Math.cos(lon)*Math.sin(lat)] };
}
const dot = (a,b) => a.reduce((s,v,i)=>s+v*b[i],0);
export function panelToSource(u, v, panel) {
  const b = panelBasis(panel.lon, panel.lat), sx = (u-.5)*2*panel.halfWidth, sy = (panel.offsetY||0)+(.5-v)*2*panel.halfHeight;
  return sourcePoint(b.forward.map((n,i)=>n+b.right[i]*sx+b.up[i]*sy));
}
export function sourceToPanel(x, y, panel) {
  const d = direction(x,y), b = panelBasis(panel.lon,panel.lat), z = dot(d,b.forward);
  if(z <= 0) return null;
  const u = .5+dot(d,b.right)/(z*panel.halfWidth*2), v = .5-(dot(d,b.up)/z-(panel.offsetY||0))/(panel.halfHeight*2);
  return u>=0&&u<=1&&v>=0&&v<=1 ? [u,v] : null;
}
export function desktopToSource(x,y,yaw,aspect) {
  const b=panelBasis(yaw,0), sx=(x-.5)*2*1.428148006*aspect, sy=(.5-y)*2*1.428148006;
  return sourcePoint(b.forward.map((n,i)=>n+b.right[i]*sx+b.up[i]*sy));
}
