import { lesson } from "./hazards.js";
import { photoDetails } from "./photo-data.js";

export function defaultLesson() {
  return { schema: 1, revision: "construction-1", title: "Construction Hazard Hunt",
    description: "Inspect the site. Find unsafe situations, assess the risk and choose a safer response.",
    image: "images/construction-panorama.png", imageCredit: "AI-generated training scene", teams: 1, duration: 0, hints: false,
    hazards: lesson.hazards.map(h => ({ id: h.id, title: h.title, zone: h.zone, risk: h.risk,
      prompt: h.prompt, options: [...h.options], correct: h.correct, consequence: h.consequence,
      explanation: h.explanation, discussion: h.discussion,
      region: [...photoDetails[h.id].region], point: [...photoDetails[h.id].point] })) };
}

const text = (value, max) => typeof value === "string" && value.trim().length > 0 && value.length <= max;
export function validateLesson(value) {
  if (!value || value.schema !== 1 || !text(value.title, 90) || !text(value.description, 450) ||
      !text(value.revision, 80) || ![1, 2].includes(value.teams) || ![0, 480, 720].includes(value.duration) ||
      typeof value.hints !== "boolean" || !Array.isArray(value.hazards) || value.hazards.length < 1 || value.hazards.length > 12 ||
      !/^(images\/[a-zA-Z0-9_.-]+\.(?:png|jpe?g|webp)|\/api\/images\/[a-f0-9-]+\.(?:png|jpg|webp))$/.test(value.image)) return null;
  const imageCredit=value.imageCredit??(value.image.startsWith("images/")?"AI-generated training scene":"Institution-supplied scene");
  if(!text(imageCredit,90))return null;
  const ids = new Set();
  for (const h of value.hazards) {
    if (!h || !/^[a-zA-Z0-9_-]{1,40}$/.test(h.id) || ids.has(h.id) || !text(h.title, 100) || !text(h.zone, 50) ||
        !["critical", "high", "low"].includes(h.risk) || !text(h.prompt, 500) || !text(h.consequence, 600) ||
        !text(h.explanation, 1000) || !text(h.discussion, 400) || !Array.isArray(h.options) || h.options.length !== 3 ||
        !h.options.every(o => text(o, 300)) || !Number.isInteger(h.correct) || h.correct < 0 || h.correct > 2 ||
        !Array.isArray(h.region) || h.region.length !== 4 || !h.region.every(Number.isFinite) ||
        !Array.isArray(h.point) || h.point.length !== 2 || !h.point.every(Number.isFinite)) return null;
    const [x, y, w, height] = h.region;
    if (x < 0 || y < 0 || w < .006 || height < .006 || x + w > 1.00001 || y + height > 1.00001 ||
        h.point[0] < x || h.point[0] > x + w || h.point[1] < y || h.point[1] > y + height) return null;
    ids.add(h.id);
  }
  // Explicit fields only: no arbitrary user properties or HTML are forwarded.
  return { schema: 1, revision: value.revision, title: value.title, description: value.description,
    image: value.image, imageCredit, teams: value.teams, duration: value.duration, hints: value.hints,
    hazards: value.hazards.map(h => ({ id: h.id, title: h.title, zone: h.zone, risk: h.risk,
      prompt: h.prompt, options: [...h.options], correct: h.correct, consequence: h.consequence,
      explanation: h.explanation, discussion: h.discussion, region: [...h.region], point: [...h.point] })) };
}

export function hazardAt(config, x, y) {
  return config.hazards.find(h => {
    const [left, top, width, height] = h.region;
    return x >= left && x <= left + width && y >= top && y <= top + height;
  }) || null;
}
