import "./editor.css";
import { defaultLesson, validateLesson } from "./lesson-config.js";
import { createOutputLink,STATIC_HOST } from "./output-link.js";

// Editor only. Nothing here starts, pauses, locks or answers a room lesson.
const room=new URLSearchParams(location.search).get("room")||"construction";
const root=document.getElementById("editor"),draftKey=`igloo-editor-draft-v1:${room}`;
let draft=defaultLesson(),expectedRevision=draft.revision,selected=draft.hazards[0].id,dirty=false,connected=false;
let message="Loading published activity…",busy=false,drag=null,sceneReviewed=true;
const escape=v=>String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const playUrl=new URL("viewer.html",location.href);playUrl.searchParams.set("room",room);
const desktopUrl=new URL(playUrl);desktopUrl.searchParams.set("desktop","1");
playUrl.hash=location.hash;desktopUrl.hash=location.hash;
const link=createOutputLink({role:"control",onStatus(status){connected=status.connected;const e=document.getElementById("connection");if(e)e.textContent=connected?"Local publishing host connected":"Offline · local draft safe · publishing unavailable";},onLesson(value){
  if(value.revision!==expectedRevision&&dirty){message="A newer version is published. Export your draft or reload the published version before publishing.";status();}
}});
function status(){const e=document.getElementById("message");if(e)e.textContent=message;const s=document.getElementById("draft-state");if(s)s.textContent=dirty?"UNSAVED DRAFT":STATIC_HOST?"WEB ACTIVITY":"PUBLISHED";}
function store(){dirty=true;try{localStorage.setItem(draftKey,JSON.stringify({draft,expectedRevision,sceneReviewed}));message="Draft saved in this browser. Publish when ready.";}catch{message="Browser storage is unavailable. Export this draft before closing.";}status();}
function loadDraft(value){
  draft=value;expectedRevision=value.revision;dirty=false;sceneReviewed=true;
  try{const local=JSON.parse(localStorage.getItem(draftKey));const valid=validateLesson(local?.draft);if(valid){draft=valid;expectedRevision=local.expectedRevision;sceneReviewed=local.sceneReviewed!==false;dirty=true;}}catch{}
  selected=draft.hazards[0].id;
}
async function initialise(){try{const value=validateLesson(await link.lesson());loadDraft(value||defaultLesson());message=dirty?"Restored your unpublished local draft.":"Ready. Edit here; learners use the Play link independently.";}catch{loadDraft(defaultLesson());message="Default activity loaded. Start the local host to publish edits.";}render();}
function field(key,label,value,{area=false,max=300}={}){return `<label>${label}${area?`<textarea data-field="${key}" maxlength="${max}" rows="3">${escape(value)}</textarea>`:`<input data-field="${key}" maxlength="${max}" value="${escape(value)}">`}</label>`;}
function render(){
  const h=draft.hazards.find(h=>h.id===selected)||draft.hazards[0];selected=h.id;
   root.innerHTML=`<header><a class="brand" href="sessions.html">SITE SURVEY <small>ACTIVITY EDITOR · ALL SESSIONS ↗</small></a><div class="header-links"><a href="${escape(desktopUrl.href)}" target="_blank" rel="noopener">Test lesson ↗</a><a href="${escape(playUrl.href)}" target="_blank" rel="noopener">Open ICE lesson ↗</a><button id="publish" class="primary" ${busy?"disabled":""}>${busy?"Publishing…":"Publish changes"}</button></div></header>
  <div class="editor-status"><span id="connection">${connected?"Local publishing host connected":"Connecting publishing host…"}</span><span id="draft-state">${dirty?"UNPUBLISHED DRAFT":"PUBLISHED"}</span><p id="message" role="status">${escape(message)}</p></div>
  <main><aside><h2>The activity</h2>${field("title","Lesson title",draft.title,{max:90})}${field("description","Opening instructions",draft.description,{area:true,max:450})}
    <label>Teams<select data-setting="teams"><option value="1" ${draft.teams===1?"selected":""}>One collaborative group</option><option value="2" ${draft.teams===2?"selected":""}>Two alternating teams</option></select></label>
    <label>Inspection clock<select data-setting="duration">${[[0,"Untimed"],[720,"12 minutes"],[480,"8 minutes"]].map(([v,l])=>`<option value="${v}" ${draft.duration===v?"selected":""}>${l}</option>`).join("")}</select></label>
    <label class="check"><input id="default-hints" type="checkbox" ${draft.hints?"checked":""}>Start with hazard hints visible</label>
    <h3>Hazards <span>${draft.hazards.length}</span></h3><div class="hazard-list">${draft.hazards.map((item,i)=>`<button data-select="${item.id}" class="${item.id===h.id?"active":""}"><b>${String(i+1).padStart(2,"0")}</b><span>${escape(item.title)}<small>${escape(item.zone)}</small></span></button>`).join("")}</div>
    <div class="file-actions"><button id="export">Export activity JSON</button><label class="file-button">Import activity JSON<input id="import" type="file" accept="application/json,.json"></label><button id="reload">Reload published version</button></div>
    <p class="fine">The play page runs the full lesson without this editor open. Publishing never interrupts an active inspection: learners can load the update from the lesson controls.</p></aside>
    <section class="scene-editor"><div class="section-top"><div><span class="eyebrow">SCENE & HIT AREAS</span><h1>Make the evidence clear.</h1></div><span class="badge">2:1 SOURCE</span></div><p>Select a region to edit its question. Drag the selected region to reposition it; use the values below to resize precisely.</p>
      <div class="image-editor"><img id="scene-image" src="${escape(new URL(draft.image,document.baseURI).href)}" alt="Editable construction training scene" draggable="false">${draft.hazards.map((item,i)=>{const [x,y,w,ht]=item.region;return `<button class="region ${item.id===h.id?"selected":""}" data-region="${item.id}" aria-label="Edit hazard ${i+1}: ${escape(item.title)}" style="left:${x*100}%;top:${y*100}%;width:${w*100}%;height:${ht*100}%"><span>${i+1}</span></button>`;}).join("")}</div>
      <div class="coordinates">${["Left","Top","Width","Height"].map((l,i)=>`<label>${l} %<input type="number" data-coordinate="${i}" min="${i>1?.6:0}" max="100" step=".1" value="${(h.region[i]*100).toFixed(1)}"></label>`).join("")}</div>
      <button id="edit-question" class="question-jump">Edit this hazard's question ↓</button><div class="image-actions"><label class="file-button">Replace 360° scene<input id="upload" type="file" accept="image/png,image/jpeg,image/webp"></label><span>PNG, JPEG or WebP · 2:1 · up to 12 MB</span></div>
      ${field("imageCredit","Scene provenance / credit",draft.imageCredit,{max:90})}<label class="check"><input id="scene-reviewed" type="checkbox" ${sceneReviewed?"checked":""}>I have checked all hazard positions against this scene.</label>
      <div class="teaching-note"><strong>Room lesson, not a remote-control panel.</strong><p>Start, hazard choices, feedback, scores, pause and debrief are all inside the play view. The editor is only for preparation and publishing. Use <b>Test lesson</b> for a normal perspective browser preview, or <b>Open ICE lesson</b> for full-frame equirectangular output.</p></div>
      <p class="fine">The supplied scene is AI-generated, not a real-site photograph or verified seamless 360 capture. Check projection and seams in the actual room. Review safety content with a competent construction tutor.</p>
    </section>
    <section class="question-editor"><span class="eyebrow">SELECTED HAZARD</span><h2>${escape(h.title)}</h2>${field("hazard.title","Hazard title",h.title,{max:100})}${field("hazard.zone","Work zone",h.zone,{max:50})}${field("hazard.prompt","Question",h.prompt,{area:true,max:500})}
      <label>Risk guide<select data-hazard-risk>${[["critical","Critical · immediate danger"],["high","High · serious harm"],["low","Low · minor harm"]].map(([v,l])=>`<option value="${v}" ${h.risk===v?"selected":""}>${l}</option>`).join("")}</select></label>
      <fieldset><legend>Response options · select the safest answer</legend>${h.options.map((o,i)=>`<label class="option-edit"><span><input type="radio" name="correct" value="${i}" ${h.correct===i?"checked":""}>${String.fromCharCode(65+i)} · correct response</span><textarea data-option="${i}" maxlength="300" rows="3">${escape(o)}</textarea></label>`).join("")}</fieldset>
      ${field("hazard.consequence","Why it matters",h.consequence,{area:true,max:600})}${field("hazard.explanation","Safer approach / feedback",h.explanation,{area:true,max:1000})}${field("hazard.discussion","Discussion prompt",h.discussion,{area:true,max:400})}
    </section></main>`;
  wire();
  if(STATIC_HOST){
    root.querySelector("#publish").textContent="Create shareable play link";
    root.querySelector("#connection").textContent="Hosted website · no local server required";
    root.querySelector("#draft-state").textContent=dirty?"UNSAVED DRAFT":"WEB ACTIVITY";
    const note=document.createElement("p");note.className="fine";note.textContent="Web edition: edits are saved in this browser. Create a play link, then copy it to the venue PC. Links contain the questions and answer key; they are not private exams. No server-side publishing or scene uploads.";root.querySelector("aside").prepend(note);
    root.querySelector("#upload").disabled=true;root.querySelector(".image-actions span").textContent="Hosted edition: bundled AI-generated scene. Custom scene uploads require storage hosting.";
    if(playUrl.hash){const box=document.createElement("label");box.textContent="Copy this play URL to ICE on the other computer";const input=document.createElement("input");input.readOnly=true;input.value=playUrl.href;input.onclick=()=>input.select();box.append(input);root.querySelector(".editor-status").append(box);}
  }
}
function selectedHazard(){return draft.hazards.find(h=>h.id===selected);}
function updateRegion(values){
  const h=selectedHazard(),r=values.map(Number);if(r.some(v=>!Number.isFinite(v)))return;
  r[2]=Math.max(.006,Math.min(1,r[2]));r[3]=Math.max(.006,Math.min(1,r[3]));r[0]=Math.max(0,Math.min(1-r[2],r[0]));r[1]=Math.max(0,Math.min(1-r[3],r[1]));
  h.region=r;h.point=[r[0]+r[2]/2,r[1]+r[3]/2];store();
  const b=root.querySelector(`[data-region="${selected}"]`);if(b)b.style.cssText=`left:${r[0]*100}%;top:${r[1]*100}%;width:${r[2]*100}%;height:${r[3]*100}%`;
  root.querySelectorAll("[data-coordinate]").forEach(e=>e.value=(r[Number(e.dataset.coordinate)]*100).toFixed(1));
}
function wire(){
  root.querySelectorAll("[data-select]").forEach(b=>b.onclick=()=>{selected=b.dataset.select;render();});
  root.querySelectorAll("[data-region]").forEach(b=>{
    b.addEventListener("pointerdown",e=>{e.preventDefault();if(selected!==b.dataset.region){selected=b.dataset.region;render();return;}drag={id:e.pointerId,x:e.clientX,y:e.clientY,region:[...selectedHazard().region],rect:root.querySelector(".image-editor").getBoundingClientRect()};b.setPointerCapture(e.pointerId);});
    b.addEventListener("pointermove",e=>{if(!drag||drag.id!==e.pointerId)return;const r=[...drag.region];r[0]+=(e.clientX-drag.x)/drag.rect.width;r[1]+=(e.clientY-drag.y)/drag.rect.height;updateRegion(r);});
    b.addEventListener("pointerup",()=>drag=null);b.addEventListener("pointercancel",()=>drag=null);
    b.addEventListener("click",()=>{if(selected!==b.dataset.region){selected=b.dataset.region;render();}});
  });
  root.querySelectorAll("[data-field]").forEach(e=>e.addEventListener("input",()=>{const k=e.dataset.field;if(k.startsWith("hazard."))selectedHazard()[k.slice(7)]=e.value;else draft[k]=e.value;store();}));
  root.querySelectorAll("[data-setting]").forEach(e=>e.onchange=()=>{draft[e.dataset.setting]=Number(e.value);store();});
  root.querySelector("#default-hints").onchange=e=>{draft.hints=e.target.checked;store();};
  root.querySelector("#scene-reviewed").onchange=e=>{sceneReviewed=e.target.checked;store();};
  root.querySelector("[data-hazard-risk]").onchange=e=>{selectedHazard().risk=e.target.value;store();};
  root.querySelectorAll("[data-option]").forEach(e=>e.oninput=()=>{selectedHazard().options[Number(e.dataset.option)]=e.value;store();});
  root.querySelectorAll('[name="correct"]').forEach(e=>e.onchange=()=>{selectedHazard().correct=Number(e.value);store();});
  root.querySelectorAll("[data-coordinate]").forEach(e=>e.onchange=()=>{const r=[...selectedHazard().region];r[Number(e.dataset.coordinate)]=Number(e.value)/100;updateRegion(r);});
  root.querySelector("#publish").onclick=publish;
  root.querySelector("#edit-question").onclick=()=>root.querySelector(".question-editor").scrollIntoView({behavior:matchMedia("(prefers-reduced-motion: reduce)").matches?"instant":"smooth",block:"start"});
  root.querySelector("#export").onclick=()=>{const url=URL.createObjectURL(new Blob([JSON.stringify(draft,null,2)],{type:"application/json"})),a=document.createElement("a");a.href=url;a.download="hazard-hunt-activity.json";a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);};
  root.querySelector("#reload").onclick=async()=>{if(dirty&&!confirm("Discard the local draft and reload the published activity? Export first if you want to keep it."))return;try{const value=validateLesson(await link.lesson());if(!value)throw new Error();draft=value;expectedRevision=value.revision;dirty=false;sceneReviewed=true;selected=draft.hazards[0].id;localStorage.removeItem(draftKey);message="Published activity loaded.";render();}catch{message="Unable to load the published activity.";status();}};
  root.querySelector("#import").onchange=async e=>{try{const file=e.target.files[0];if(!file||file.size>128*1024)throw new Error();const value=validateLesson(JSON.parse(await file.text()));if(!value)throw new Error();draft=value;draft.revision=expectedRevision;selected=draft.hazards[0].id;sceneReviewed=false;store();message="Activity imported as a draft. Check scene positions before publishing.";render();}catch{message="Invalid activity file. Use an exported lesson JSON up to 128 KB.";status();}};
  root.querySelector("#upload").onchange=upload;
}
async function publish(){
  if(!sceneReviewed){message="Check the scene-position confirmation before publishing.";status();return;}
  const value=validateLesson(draft);if(!value){message="Check required text, correct answers and valid hotspot positions before publishing.";status();return;}
  busy=true;render();const result=await link.request("lesson",{lesson:value,expectedRevision});busy=false;
  if(result.lesson){draft=result.lesson;expectedRevision=draft.revision;dirty=false;try{localStorage.removeItem(draftKey);}catch{}if(result.fragment){playUrl.hash=result.fragment;desktopUrl.hash=result.fragment;message="Play link created. Copy the URL below to the venue PC. Existing links keep their previous content.";}else message="Published. New lessons use this version; active inspections can load it when ready.";}
  else message=result.error||"Publish failed. Your local draft is unchanged.";
  render();
}
async function upload(e){
  const file=e.target.files[0];if(!file)return;
  if(!["image/png","image/jpeg","image/webp"].includes(file.type)||file.size>12*1024*1024){message="Choose a PNG, JPEG or WebP up to 12 MB.";status();return;}
  const reader=new FileReader();reader.readAsDataURL(file);
  reader.onload=async()=>{
    const data=String(reader.result),probe=new Image();probe.src=data;
    try{await probe.decode();if(Math.abs(probe.naturalWidth/probe.naturalHeight-2)>.02)throw new Error();}catch{message="Use a valid 2:1 image for the equirectangular source.";status();return;}
    message="Uploading scene to the local host…";status();const result=await link.request("upload",{base64:data.split(",")[1]});
    if(result.image){draft.image=result.image;draft.imageCredit="Institution-supplied scene — verify usage rights";sceneReviewed=false;store();message="Scene uploaded. Reposition and check every hazard before publishing.";render();}else{message=result.error||"Upload failed.";status();}
  };
}
window.addEventListener("beforeunload",e=>{if(dirty){e.preventDefault();e.returnValue="";}});
window.addEventListener("pagehide",()=>link.close());
render();initialise();
