// audio.js — gesture-unlocked looping ambient bed(s).
//
// Two browser facts shape this:
//   1. Autoplay policy: an AudioContext started before a user gesture stays
//      suspended and silent. We create the context + load files on the first
//      pointerdown anywhere. (In a fixed Igloo install you can instead launch
//      CEF with --autoplay-policy=no-user-gesture-required and call unlock()
//      yourself — see docs/gotchas.md.)
//   2. Looping beds want their gain eased, not snapped, so changing scenes
//      cross-fades instead of clicking.
//
// Usage:
//   const audio = createAudio({ ambient: `${import.meta.env.BASE_URL}audio/wind.ogg` });
//   // ...each frame, drive the mix (0..1 per bed):
//   audio.set({ ambient: cfg.audio ? 0.7 : 0 });
//   audio.update(dt);
//
// `set` records targets; `update(dt)` eases current gains toward them. Missing
// files are skipped with a warning, never a throw.

export function createAudio(beds = {}) {
  let ctx = null;
  let master = null;
  let unlocked = false;
  const nodes = {}; // name -> { gain }
  const targets = {}; // name -> 0..1
  for (const name of Object.keys(beds)) targets[name] = 0;

  async function loadBuffer(url) {
    const r = await fetch(url);
    if (!r.ok) throw new Error(`${url}: ${r.status}`);
    return ctx.decodeAudioData(await r.arrayBuffer());
  }

  // Create the graph and start every bed looping (silent until set()+update()
  // raise its gain). Safe to call more than once. Must run from a gesture.
  async function unlock() {
    if (unlocked) return;
    unlocked = true;
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    master = ctx.createGain();
    master.gain.value = 1;
    master.connect(ctx.destination);
    if (ctx.state === "suspended") ctx.resume();

    await Promise.all(
      Object.entries(beds).map(async ([name, url]) => {
        try {
          const buf = await loadBuffer(url);
          const src = ctx.createBufferSource();
          src.buffer = buf;
          src.loop = true;
          const gain = ctx.createGain();
          gain.gain.value = 0;
          src.connect(gain).connect(master);
          src.start(0, Math.random() * buf.duration); // random phase
          nodes[name] = { gain };
        } catch (err) {
          console.warn("[igloo-kit/audio] skipping", url, err);
        }
      })
    );
  }
  window.addEventListener("pointerdown", unlock, { once: true });

  // Record per-bed target levels (0..1). Cheap; call every frame.
  function set(mix) {
    Object.assign(targets, mix);
  }

  // Ease current gains toward targets. dt in seconds; frame-rate independent.
  function update(dt) {
    if (!ctx) return;
    const k = 1 - Math.pow(0.05, dt);
    for (const [name, node] of Object.entries(nodes)) {
      const t = targets[name] ?? 0;
      node.gain.gain.value += (t - node.gain.gain.value) * k;
    }
  }

  return { unlock, set, update };
}
