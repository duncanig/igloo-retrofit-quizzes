// IglooRenderer.js — Igloo Vision's three.js integration module.
// Source: http://threejs.igloovisiondesign.com/igloo/IglooRenderer.js
//
// Renders the scene as a 6:1 cubemap strip (Left, Front, Right, Back, Bottom,
// Top) which Igloo Core Engine turns into the dome's equirectangular output.
//
// This is the ONE file in the kit you should treat as a black box: it is
// vendored third-party code, not something you need to read line-by-line to use
// the starter. Construct it, call .follow() and .render() each frame, and flip
// it on/off with .setEnabled(). See packages/igloo-kit/README.md for the API.
//
// LOCAL MODIFICATIONS (kept minimal, marked with `// [mod]`):
//   1. Import three from the bare "three" specifier so Vite/npm resolves it.
//   2. Added a runtime-settable enable flag (`setEnabled`) so a UI toggle can
//      switch 360 mode on/off, while the ?igloo=1 URL param still sets the
//      initial state. The original only read the URL param once at construction.
//   3. Added a per-face render mask (`setFaceMask` + ?faces=) so cylindrical
//      rooms can skip the floor/ceiling faces to save per-frame cost.

import * as THREE from "three"; // [mod] was "../../../build/three.module.js"

var IglooRenderer = function (camera, renderer, scene) {
  // 6 perspective cameras for cubemap faces
  var cameraLeft;
  var cameraFront;
  var cameraRight;
  var cameraBack;
  var cameraBottom;
  var cameraTop;

  // look for igloo parameter in URL
  const urlString = window.location.search;
  const urlParams = new URLSearchParams(urlString);
  const igloomode = urlParams.get("igloo");

  // [mod] effective enable flag — initialised from the URL param, overridable
  var enabledFlag = igloomode == 1;

  // [mod] per-face render mask from ?faces= (e.g. ?faces=lfrb). Letters map to
  // the strip order L F R B D(own/Bottom) U(p/Top); any face NOT listed is left
  // black so the full 6:1 strip shape is preserved (Igloo Core Engine still reads it).
  // Omitting the param renders all six faces. Skipping Bottom+Top (?faces=lfrb)
  // saves a third of the per-frame face cost in cylindrical rooms that show
  // little floor/ceiling. Order of the boolean array: [L, F, R, B, Bottom, Top].
  function parseFaceMask(s) {
    if (!s) return [true, true, true, true, true, true];
    s = s.toLowerCase();
    return [
      s.indexOf("l") !== -1, // Left
      s.indexOf("f") !== -1, // Front
      s.indexOf("r") !== -1, // Right
      s.indexOf("b") !== -1, // Back
      s.indexOf("d") !== -1, // Down  = Bottom
      s.indexOf("u") !== -1, // Up    = Top
    ];
  }
  var faceMask = parseFaceMask(urlParams.get("faces"));

  // objects from main scene
  this.camera = camera;
  this.renderer = renderer;
  this.scene = scene;

  // object for igloo camera to follow, default is camera object
  var follow_object = null;

  // pixel ratio
  var pixel_ratio = renderer.getPixelRatio();

  // calculate size of cubemap faces
  var view_width = this.renderer.domElement.width / 6 / pixel_ratio;
  var view_height = this.renderer.domElement.height / pixel_ratio;

  var fov = 90;
  var aspect = 1;
  var near = this.camera.near;
  var far = this.camera.far;

  var pointerX = 0;
  var pointerY = 0;
  var activeCamera = null;

  cameraLeft = new THREE.PerspectiveCamera(fov, aspect, near, far);
  cameraLeft.lookAt(-1, 0, 0);

  cameraFront = new THREE.PerspectiveCamera(fov, aspect, near, far);
  cameraFront.lookAt(0, 0, -1);

  cameraRight = new THREE.PerspectiveCamera(fov, aspect, near, far);
  cameraRight.lookAt(1, 0, 0);

  cameraBack = new THREE.PerspectiveCamera(fov, aspect, near, far);
  cameraBack.lookAt(0, 0, 1);

  cameraBottom = new THREE.PerspectiveCamera(fov, aspect, near, far);
  cameraBottom.lookAt(0, -1, 0);

  cameraTop = new THREE.PerspectiveCamera(fov, aspect, near, far);
  cameraTop.lookAt(0, 1, 0);

  cameraLeft.position.copy(camera.position);
  cameraFront.position.copy(camera.position);
  cameraRight.position.copy(camera.position);
  cameraBack.position.copy(camera.position);
  cameraBottom.position.copy(camera.position);
  cameraTop.position.copy(camera.position);

  window.addEventListener("pointerdown", function (event) {
    var clientx = event.clientX % view_width;
    pointerX = (clientx / view_width) * 2 - 1;
    pointerY = -(event.clientY / view_height) * 2 + 1;

    var view_number = Math.floor(event.clientX / view_width);
    switch (view_number) {
      case 0:
        activeCamera = cameraLeft;
        break;
      case 1:
        activeCamera = cameraFront;
        break;
      case 2:
        activeCamera = cameraRight;
        break;
      case 3:
        activeCamera = cameraBack;
        break;
      case 4:
        activeCamera = cameraBottom;
        break;
      case 5:
        activeCamera = cameraTop;
    }
  });

  this.update = function () {
    pixel_ratio = renderer.getPixelRatio();
    view_width = this.renderer.domElement.width / 6 / pixel_ratio;
    view_height = this.renderer.domElement.height / pixel_ratio;
    near = this.camera.near;
    far = this.camera.far;
  };

  // [mod] runtime toggle; URL param still sets the initial value above
  this.setEnabled = function (v) {
    enabledFlag = !!v;
  };

  // [mod] runtime face-mask setter (URL ?faces= sets the initial value). Accepts
  // a "lfrbdu" string or a 6-element boolean array [L,F,R,B,Bottom,Top].
  this.setFaceMask = function (m) {
    if (typeof m === "string") faceMask = parseFaceMask(m);
    else if (Array.isArray(m) && m.length === 6) faceMask = m.map(Boolean);
  };

  this.enabled = function () {
    return enabledFlag;
  };

  this.follow = function (object) {
    follow_object = object;
  };

  this.pointerDownCoords = function () {
    return [pointerX, pointerY];
  };

  this.activeCamera = function () {
    return activeCamera;
  };

  // reused so the per-face loop allocates nothing each frame
  var faceCameras = [
    cameraLeft,
    cameraFront,
    cameraRight,
    cameraBack,
    cameraBottom,
    cameraTop,
  ];
  var savedClearColor = new THREE.Color();

  this.render = function () {
    if (enabledFlag) {
      // [mod] was `igloomode == 1`
      // draw the cubemap faces using Scissor and Viewport methods
      if (follow_object != null) {
        for (var c = 0; c < faceCameras.length; c++) {
          faceCameras[c].position.copy(follow_object.position);
        }
      }
      this.renderer.setScissorTest(true);

      // [mod] disabled faces are cleared to black (full 6:1 strip preserved).
      // Save/restore the clear colour since we flip it for the black fills.
      this.renderer.getClearColor(savedClearColor);
      var savedClearAlpha = this.renderer.getClearAlpha();

      for (var i = 0; i < 6; i++) {
        var x = view_width * i;
        this.renderer.setScissor(x, 0, view_width, view_height);
        this.renderer.setViewport(x, 0, view_width, view_height);
        if (faceMask[i]) {
          this.renderer.render(this.scene, faceCameras[i]);
        } else {
          // scissor test confines the clear to this face's rectangle
          this.renderer.setClearColor(0x000000, 1);
          this.renderer.clear();
        }
      }

      this.renderer.setClearColor(savedClearColor, savedClearAlpha);
      this.renderer.setScissorTest(false);

      return true;
    } else {
      return false;
    }
  };
};

export { IglooRenderer };
