// layout.js — geometry for the 6:1 cubemap strip.
//
// The IglooRenderer draws the scene as six square faces side by side, in the
// order: Left, Front, Right, Back, Bottom(Down), Top(Up). The canvas is sized
// to that 6:1 strip and centred in the window. These helpers answer two
// questions the rest of an app keeps asking:
//
//   1. How big should the strip canvas be?  -> stripLayout()
//   2. Where on the page is a given face?    -> faceRect()  (for placing DOM UI)
//
// Pure functions, no three.js, no DOM. Page pixels throughout.

// Strip order. Index into this for the per-face math.
export const FACE_ORDER = ["left", "front", "right", "back", "down", "up"];

const FACE_INDEX = Object.fromEntries(FACE_ORDER.map((f, i) => [f, i]));

// Largest 6:1 strip that fits inside the window, centred. Feed stripW/stripH to
// renderer.setSize(); left/top tell you where the centred canvas starts so you
// can convert face rects into page coordinates.
export function stripLayout(winW = window.innerWidth, winH = window.innerHeight) {
  const stripW = Math.min(winW, winH * 6);
  const stripH = stripW / 6; // each face is a square of side stripH
  return {
    stripW,
    stripH,
    left: (winW - stripW) / 2,
    top: (winH - stripH) / 2,
  };
}

// Page-pixel rectangle of one cube face, for anchoring DOM overlays (e.g. the
// in-room panel) over it. `face` is one of FACE_ORDER. Returns {x, y, w, h}.
export function faceRect(face, winW = window.innerWidth, winH = window.innerHeight) {
  const { stripH, left, top } = stripLayout(winW, winH);
  const i = FACE_INDEX[face] ?? FACE_INDEX.front;
  return { x: left + i * stripH, y: top, w: stripH, h: stripH };
}
