// panel.js — in-room DOM control panel primitives.
//
// Igloo Core captures the FULL PAGE (DOM included), not just the WebGL canvas,
// and maps touch/cursor input from the warped room display back to page
// coordinates. So a plain DOM panel positioned over a face of the cubemap strip
// becomes interactive content inside the room — no render-to-texture, no
// raycasting. This module gives you a face-anchored container plus two chunky,
// touch-first controls (button, slider) suited to that.
//
// Everything is sized in `em`; layout() sets a single font-size derived from the
// face height, so the whole panel scales with the strip at any resolution.
//
// Two gotchas this encodes (see docs/gotchas.md):
//   - form controls don't inherit font-size, so em-based scaling silently fails
//     on a native <input>. We build the slider from spans we control.
//   - native <input type=range> maps clicks via the UA's own hidden thumb
//     metrics, which diverge from our scaled visuals — taps land off. So pointer
//     handling here is ours: position -> value is exactly the drawn geometry.
//
// Pair with layout.js's faceRect() to get the rect to pass to .layout().
// Import "./panel.css" once in your app for the styling.

export function createPanel({ scale = 1, panelY = 0 } = {}) {
  const el = document.createElement("div");
  el.className = "igloo-panel";
  document.body.appendChild(el);

  const grid = document.createElement("div");
  grid.className = "ip-grid";
  el.appendChild(grid);

  const sliders = [];

  // A square tile button (goes in the top grid). Returns { el, setActive }.
  function button({ label, glyph = "", onClick }) {
    const b = document.createElement("button");
    b.className = "ip-btn";
    b.innerHTML =
      `<span class="ip-glyph">${glyph}</span>` +
      `<span class="ip-label">${label}</span>`;
    b.addEventListener("click", () => onClick?.(b));
    grid.appendChild(b);
    return { el: b, setActive: (on) => b.classList.toggle("active", !!on) };
  }

  // A full-width labelled slider row. Fully custom (see header note).
  // Returns { el, set(v), dragging, valueEl }.
  function slider({ label, min = 0, max = 1, step = 0.01, value = min, format = (v) => v.toFixed(2), onInput }) {
    const row = document.createElement("div");
    row.className = "ip-row";
    row.innerHTML =
      `<span class="ip-label">${label}</span>` +
      `<span class="ip-slider"><span class="ip-track"></span><span class="ip-thumb"></span></span>` +
      `<span class="ip-value"></span>`;
    const track = row.querySelector(".ip-slider");
    const valueEl = row.querySelector(".ip-value");
    const api = { el: row, dragging: false, valueEl };

    api.set = (v) => {
      track.style.setProperty("--t", (v - min) / (max - min));
      valueEl.textContent = format(v);
    };

    function fromEvent(e) {
      const r = track.getBoundingClientRect();
      const t = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
      let v = min + t * (max - min);
      v = Math.round((v - min) / step) * step + min; // snap to step
      api.set(v);
      onInput?.(v);
    }
    track.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      track.setPointerCapture(e.pointerId);
      api.dragging = true;
      fromEvent(e);
    });
    track.addEventListener("pointermove", (e) => {
      if (api.dragging) fromEvent(e);
    });
    const end = () => (api.dragging = false);
    track.addEventListener("pointerup", end);
    track.addEventListener("pointercancel", end);

    api.set(value);
    el.appendChild(row);
    sliders.push(api);
    return api;
  }

  // Position + scale the panel over a face rect (page pixels, from faceRect()).
  // One font-size scales every em dimension; panelY shifts the centre by a
  // fraction of the face height (negative = up).
  function layout(rect) {
    el.style.left = `${rect.x + rect.w / 2}px`;
    el.style.top = `${rect.y + rect.h * (0.5 + panelY)}px`;
    el.style.fontSize = `${rect.h * 0.0225 * scale}px`;
  }

  return { el, button, slider, layout, sliders };
}
