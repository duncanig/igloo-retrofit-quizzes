// params.js — the operator config surface.
//
// In an Igloo deployment there is no settings file and often no keyboard in the
// room: the URL *is* the configuration. An operator pastes a URL with query
// params into an Igloo Core WebView session, so every knob you want them to set
// at launch should be a URL param with a sane default and a hard clamp (a
// fat-fingered ?renderScale=20 must not melt the GPU).
//
// readParams() takes a schema describing each param and returns a plain object
// of coerced, clamped values. No dependencies.
//
// Schema example:
//   const cfg = readParams({
//     igloo:       { type: "bool",   default: false },
//     panel:       { type: "enum",   values: ["left","front","right","back","down","up"], default: "front" },
//     panelY:      { type: "number", min: -0.5, max: 0.5, default: 0 },
//     renderScale: { type: "number", min: 0.25, max: 2, default: 1, alt: "scale" },
//     speed:       { type: "number", min: 0, max: 5, default: 1 },
//   });
//   // -> { igloo:false, panel:"front", panelY:0, renderScale:1, speed:1 }

function coerce(raw, def) {
  if (raw == null || raw === "") return def.default;

  switch (def.type) {
    case "bool":
      // present-and-truthy: ?igloo=1, ?igloo=true, or bare ?igloo
      return raw === "" || raw === "1" || raw.toLowerCase() === "true";

    case "number": {
      const n = Number(raw);
      if (!Number.isFinite(n)) return def.default;
      const lo = def.min ?? -Infinity;
      const hi = def.max ?? Infinity;
      return Math.min(Math.max(n, lo), hi);
    }

    case "enum":
      return def.values.includes(raw) ? raw : def.default;

    case "string":
    default:
      return raw;
  }
}

export function readParams(schema, search = window.location.search) {
  const q = new URLSearchParams(search);
  const out = {};
  for (const [key, def] of Object.entries(schema)) {
    // bare flags (?igloo) read as "" via has(); fall back to alt name if given
    let raw = q.has(key) ? q.get(key) : null;
    if (raw == null && def.alt && q.has(def.alt)) raw = q.get(def.alt);
    out[key] = coerce(raw, def);
  }
  return out;
}
