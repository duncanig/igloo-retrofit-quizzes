export const HAZARD_IDS = ["edge", "load", "excavation", "traffic", "electric", "exit", "dust", "storage"];
export const initialOutputState = () => ({ interactive: false, reviewed: [], selected: null, paused: false });

// randomUUID is secure-context-only in some CEF builds. Plain HTTP on the
// venue LAN must still connect. This id is NOT an authentication secret; the
// server issues a separate cryptographic token over the event stream.
export function createClientId(provider = globalThis.crypto) {
  if (typeof provider?.randomUUID === "function") {
    try { return provider.randomUUID(); } catch { /* Fall through for older CEF. */ }
  }
  if (typeof provider?.getRandomValues === "function") {
    const bytes = provider.getRandomValues(new Uint8Array(16));
    return `client-${Array.from(bytes, b => b.toString(16).padStart(2, "0")).join("")}`;
  }
  return `client-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
}

export function normaliseOutputState(value) {
  if (!value || typeof value.interactive !== "boolean" || typeof value.paused !== "boolean" ||
      !Array.isArray(value.reviewed) || value.reviewed.length > HAZARD_IDS.length ||
      !value.reviewed.every(id => HAZARD_IDS.includes(id)) ||
      (value.selected !== null && !HAZARD_IDS.includes(value.selected))) return null;
  return { interactive: value.interactive && !value.paused && value.selected === null,
    paused: value.paused, reviewed: [...new Set(value.reviewed)], selected: value.selected };
}

export function findPhotoHazard(x, y, details, reviewed = []) {
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || x > 1 || y < 0 || y > 1) return null;
  return Object.entries(details).find(([id, detail]) => {
    const [left, top, width, height] = detail.region;
    return !reviewed.includes(id) && x >= left && x <= left + width && y >= top && y <= top + height;
  })?.[0] ?? null;
}
