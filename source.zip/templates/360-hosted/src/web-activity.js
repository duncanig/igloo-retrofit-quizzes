import { defaultActivity,validateActivity } from "./activity-config.js";

const MAX_JSON=128*1024,MAX_LINK=24000;
export async function encodeActivity(value){
  const clean=validateActivity(value);if(!clean)throw Error("Invalid activity");
  if(clean.image?.startsWith("/api/"))throw Error("This scene belongs to a local server. Select the bundled scene before making a web link.");
  const bytes=new TextEncoder().encode(JSON.stringify(clean));if(bytes.length>MAX_JSON)throw Error("Activity too large");
  const compressed=typeof CompressionStream!=="undefined";
  const packed=compressed?new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(new CompressionStream("gzip"))).arrayBuffer()):bytes;
  let binary="";for(const b of packed)binary+=String.fromCharCode(b);
  const encoded=(compressed?"z":"p")+btoa(binary).replaceAll("+","-").replaceAll("/","_").replace(/=+$/,"");
  if(encoded.length>MAX_LINK)throw Error("Activity link too long. Shorten the quiz text before sharing.");
  return `#activity=${encoded}`;
}
export async function decodeActivity(hash){
  const encoded=new URLSearchParams(hash.replace(/^#/,"")).get("activity");
  if(!encoded||encoded.length>MAX_LINK||!/^([zp])[A-Za-z0-9_-]+$/.test(encoded))throw Error("Invalid activity link");
  const bytes=Uint8Array.from(atob(encoded.slice(1).replaceAll("-","+").replaceAll("_","/")),c=>c.charCodeAt(0));
  let stream=new Blob([bytes]).stream();
  if(encoded[0]==="z")stream=stream.pipeThrough(new DecompressionStream("gzip"));
  const reader=stream.getReader(),chunks=[];let size=0;
  for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>MAX_JSON){await reader.cancel();throw Error("Activity too large");}chunks.push(value);}
  const clean=validateActivity(JSON.parse(await new Blob(chunks).text()));
  if(!clean||clean.image?.startsWith("/api/"))throw Error("Invalid hosted activity");return clean;
}

// GitHub Pages has no write API. A share link is an immutable activity snapshot,
// not a claim that the public repository or another browser has been updated.
export function createWebActivityLink({room,role,onStatus=()=>{}}){
  const key=`igloo-web-activity-v1:${room}`;let current=null;
  const read=async()=>{
    if(current)return structuredClone(current);
    if(location.hash){current=await decodeActivity(location.hash);}
    else{
      if(role==="control"){try{current=validateActivity(JSON.parse(localStorage.getItem(key)));}catch{}}
      current||=defaultActivity(room);
    }
    return structuredClone(current);
  };
  queueMicrotask(()=>onStatus({connected:true,owner:role==="control"}));
  return {room,staticHost:true,connect(){},ready(){return Promise.resolve(true);},close(){},publish(){},inspect(){return false;},tap(){return false;},lesson:read,
    async request(path,data){
      if(path!=="lesson")return {error:"GitHub Pages cannot store scene uploads. This hosted edition uses the bundled scene."};
      const lesson=validateActivity(data.lesson);if(!lesson)return {error:"Invalid activity."};
      lesson.revision=`web-${crypto.randomUUID()}`;
      try{const fragment=await encodeActivity(lesson);current=lesson;try{localStorage.setItem(key,JSON.stringify(lesson));}catch{}return {lesson:structuredClone(lesson),fragment};}
      catch(error){return {error:error.message};}
    }};
}
