import { createClientId } from "./output-protocol.js";
import { createWebActivityLink } from "./web-activity.js";

export const STATIC_HOST=import.meta.env.VITE_STATIC_HOST==="1";

export function createOutputLink({ role, onState = () => {}, onInspect = () => {}, onStatus = () => {}, onTap = () => {}, onLesson = () => {}, defer = false, defaultRoom = "construction" }) {
  const room = new URLSearchParams(location.search).get("room") || defaultRoom;
  if(STATIC_HOST)return createWebActivityLink({room,role,onStatus});
  const client = createClientId();
  const query = new URLSearchParams({ room, client, role });
  let token = null, connected = false, presence = null, closed = false, lastState = null, ready = null;
  let sending = false, pendingState = null, started = !defer;
  let stream = null;
  const status = () => onStatus({ connected, owner: presence?.controller === client, ...presence });
  async function post(path, data) {
    if (!token || !connected) return false;
    try {
      const response = await fetch(`${import.meta.env.BASE_URL}api/${path}?${query}`, { method: "POST", headers: { "Content-Type": "application/json", "X-Client-Token": token }, body: JSON.stringify(data) });
      if (!response.ok) return false;
      return true;
    } catch { return false; }
  }
  async function flush() {
    if (sending || !token || !connected || presence?.controller !== client) return;
    sending = true;
    while (pendingState && connected && presence?.controller === client) {
      const state = pendingState;pendingState = null;
      if (!await post("state", state)) { pendingState = lastState;break; }
    }
    sending = false;
  }
  function openStream() {
    if(closed||stream||!started)return;
    const source = new EventSource(`${import.meta.env.BASE_URL}api/events?${query}`);
    stream = source;
    source.onmessage = event => {
    if(stream!==source)return;
    let message;try { message = JSON.parse(event.data); } catch { return; }
    if (message.type === "hello") { token = message.data.token;connected = true;status();if (role === "viewer" && ready) post("ready", ready); }
    if (message.type === "presence") {
      const wasOwner = presence?.controller === client;presence = message.data;status();
      if (role === "control" && presence.controller === client && !wasOwner && lastState) { pendingState = lastState;flush(); }
    }
    if (message.type === "state") onState(message.data);
    if (message.type === "inspect" && presence?.controller === client) onInspect(message.data.id);
    if (message.type === "tap") onTap(message.data);
    if (message.type === "lesson") onLesson(message.data);
    };
    source.onerror = () => {
      if(stream!==source)return;
      // HTTP errors such as a proxy's 502 can permanently CLOSE EventSource;
      // its native retry is not guaranteed after a local host restart.
      source.close();stream=null;connected=false;token=null;presence=null;status();
    };
  }
  openStream();
  const retry = setInterval(() => {
    if(!closed&&started&&!stream)openStream();
    if(pendingState&&connected)flush();
  }, 2000);
  return {
    room,
    connect(){started=true;openStream();},
    publish(state) { lastState = state;pendingState = state;flush(); },
    inspect(id) { return post("input", { id }); },
    tap(x,y) { return post("tap", { x,y }); },
    ready(value) { ready = value;return post("ready", value); },
    async lesson(){const response=await fetch(`${import.meta.env.BASE_URL}api/lesson?${query}`);if(!response.ok)throw new Error("Published lesson unavailable");return (await response.json()).lesson;},
    async request(path,data){
      if(!token||!connected)return {error:"The editor is offline. Connect to the local host before publishing."};
      try{const response=await fetch(`${import.meta.env.BASE_URL}api/${path}?${query}`,{method:"POST",headers:{"Content-Type":"application/json","X-Client-Token":token},body:JSON.stringify(data)});return await response.json();}catch{return {error:"Connection lost. Your draft has not been published."};}
    },
    close() { if (closed) return;closed = true;clearInterval(retry);stream?.close();stream=null; },
  };
}
