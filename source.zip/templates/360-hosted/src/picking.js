import * as THREE from "three";

const directions=[[-1,0,0],[0,0,-1],[1,0,0],[0,0,1],[0,-1,0],[0,1,0]];
const raycaster=new THREE.Raycaster();
const faceCamera=new THREE.PerspectiveCamera(90,1,.1,150);

// DOM coordinates, not framebuffer pixels: works with HiDPI, render scaling,
// letterboxed strips and Igloo's page-coordinate touch mapping.
export function pointerRay(x,y,rect,strip,camera) {
  if(x<rect.left||x>=rect.left+rect.width||y<rect.top||y>=rect.top+rect.height) return null;
  let active=camera, ndc;
  if(strip) {
    const size=rect.width/6,index=Math.floor((x-rect.left)/size);
    ndc=new THREE.Vector2(((x-rect.left-index*size)/size)*2-1,-((y-rect.top)/rect.height)*2+1);
    faceCamera.position.copy(camera.position);faceCamera.up.set(0,1,0);
    faceCamera.lookAt(camera.position.clone().add(new THREE.Vector3(...directions[index])));faceCamera.updateMatrixWorld();active=faceCamera;
  } else ndc=new THREE.Vector2((x-rect.left)/rect.width*2-1,-(y-rect.top)/rect.height*2+1);
  raycaster.setFromCamera(ndc,active);
  return raycaster;
}

export function pickHazard(x,y,rect,strip,camera,targets,answers) {
  return pointerRay(x,y,rect,strip,camera)?.intersectObjects(targets,false)
    .find(hit=>!answers.some(a=>a.id===hit.object.userData.hazardId))?.object.userData.hazardId;
}
