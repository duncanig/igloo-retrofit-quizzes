/* Injected inside the ORIGINAL quiz closure, immediately before boot().
   Only output geometry, calibration labels and resolution descriptions change.
   All original game, audio, artwork, editing and sharing code remains intact. */
OUTPUT_W=15124;OUTPUT_H=6134;WALL_H=2160;
var retrofitWalls=[{x:0,w:3974},{x:3974,w:3588},{x:7562,w:3974},{x:11536,w:3588}];
fit=function(){
  var vp=$('#vp'),st=$('#stage');if(!vp||!st)return;
  var width=OUTPUT_W,height=OUTPUT_H,x=0,y=0;
  if(!real&&projectionView==='walls')height=2160;
  if(!real&&projectionView==='floor'){width=3588;height=3974;x=3974;y=2160}
  vp.style.aspectRatio=width+'/'+height;
  var w=vp.clientWidth,h=vp.clientHeight;if(!w||!h)return;
  var sx=w/width,sy=h/height;
  st.style.transform='translate('+(-x*sx)+'px,'+(-y*sy)+'px) scale('+sx+','+sy+')';
};
var retrofitOriginalFloorWrap=floorWrap;
floorWrap=function(body,phase){return '<div class="retrofit-floor-scale">'+retrofitOriginalFloorWrap(body,phase)+'</div>'};
calibrationHTML=function(){
  var h='';retrofitWalls.forEach(function(w,i){h+='<div class="calibration-surface" style="left:'+w.x+'px;top:0;width:'+w.w+'px;height:2160px">WALL '+(i+1)+' · X '+w.x+' · '+w.w+' × 2160<span class="surface-cross">+</span></div>'});
  return h+'<div class="calibration-surface floor-calibration">ONE COMBINED FLOOR · X 3974 · Y 2160 · 3588 × 3974<br>Two 3588 × 1987 outputs · top edge connects to wall 2<span class="surface-cross">+</span><div class="retrofit-floor-split"></div></div>';
};
var retrofitOriginalFloorConfig=floorConfigHTML;
floorConfigHTML=function(){return retrofitOriginalFloorConfig().replace('8640 × 3240 · four 2160 × 1080 walls · 2160 × 2160 floor beneath wall 2','15124 × 6134 · walls 3974 / 3588 / 3974 / 3588 × 2160 · one 3588 × 3974 floor beneath wall 2')};
var retrofitOriginalApply=applyProjection;
applyProjection=function(){
  retrofitOriginalApply();
  var scene=$('#scene');
  if(scene)scene.querySelectorAll('.rw').forEach(function(el,i){var wall=retrofitWalls[i];if(!wall)return;el.style.left=wall.x+'px';el.style.transform='scale('+(wall.w/2000)+',2)'});
  var art=$('#art');
  if(art&&!art.dataset.retrofit){
    var source=art.querySelector('svg');
    if(source){
      var original=source.outerHTML;art.textContent='';
      retrofitWalls.forEach(function(w,i){
        // Crop the ORIGINAL artwork at its existing theme boundary, then fit
        // each crop to its actual wall width. Keep SVG/CSS animations alive.
        var holder=document.createElement('div'),suffix='-retrofit-'+i;
        var markup=original.replace(/id="([^"]+)"/g,function(_,id){return 'id="'+id+suffix+'"'}).replace(/url\(#([^)]+)\)/g,function(_,id){return 'url(#'+id+suffix+')'});
        holder.innerHTML=markup;var svg=holder.firstElementChild;
        svg.setAttribute('viewBox',(i*2000)+' 0 2000 1080');svg.setAttribute('preserveAspectRatio','none');
        svg.setAttribute('width',w.w);svg.setAttribute('height',2160);svg.style.left=w.x+'px';svg.style.width=w.w+'px';
        art.appendChild(svg);
      });
      art.dataset.retrofit='1';
    }
  }
  var fx=$('#fx');if(fx){
    var lines=fx.querySelectorAll('.guides i');lines.forEach(function(el,i){if(retrofitWalls[i+1])el.style.left=(retrofitWalls[i+1].x/(OUTPUT_W/8000))+'px'});
    var bands=fx.querySelectorAll('.guides b');bands.forEach(function(el,i){var edge=i===0?0:i===4?OUTPUT_W:retrofitWalls[i].x;el.style.left=((edge/(OUTPUT_W/8000))-(i===0?0:150))+'px'});
  }
};
var retrofitOriginalChrome=renderChrome;
renderChrome=function(){retrofitOriginalChrome();var button=$('[data-act="real"]');if(button)button.textContent=real?'Fit to screen':'Real size (15124 × 6134)'};
