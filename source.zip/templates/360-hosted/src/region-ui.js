import { answerWalls,REGION_COLOURS } from "./region-config.js";
import { wrapMeasuredText } from "./lesson-typography.js";

export function paintRegionUI({config,run,wall,now,feedbackPage=0,pending=false,notice="",calibration=false}) {
  const canvas=document.createElement("canvas");canvas.width=1100;canvas.height=1050;
  const c=canvas.getContext("2d"),actions=[],q=config.questions[Math.min(run.index,config.questions.length-1)],walls=answerWalls(q.options.length),option=walls.indexOf(wall);
  c.fillStyle="#091f2b";c.fillRect(0,0,1100,1050);c.strokeStyle=REGION_COLOURS[wall];c.lineWidth=10;c.strokeRect(5,5,1090,1040);
  function text(value,x,y,size=32,colour="#f7f8ef"){c.font=`700 ${size}px Arial,sans-serif`;c.fillStyle=colour;c.fillText(value,x,y);}
  function lines(value,width=990,size=32){c.font=`700 ${size}px Arial,sans-serif`;return wrapMeasuredText(value,width,t=>c.measureText(t).width);}
  function paragraph(value,y,size=32){const rows=lines(value,990,size);rows.forEach((line,i)=>text(line,55,y+i*size*1.3,size));return y+rows.length*size*1.3;}
  function fittedParagraph(value,y,maxHeight,size){while(size>28&&lines(value,990,size).length*size*1.3>maxHeight)size--;return paragraph(value,y,size);}
  function button(key,label,x,y,w=990){c.fillStyle="#d8edba";c.fillRect(x,y,w,76);text(label,x+22,y+49,30,"#10251c");actions.push({key,label,x,y,w,h:76});}
  const region=`${config.regions[wall]} · Wall ${wall+1}`;
  text(region,55,65,32,REGION_COLOURS[wall]);
  let pages=1;
  if(calibration){
    text(`WALL ${wall+1}`,55,210,80);paragraph("Check this panel is centred on a wall, below the ceiling and above the floor.",320,40);
    paragraph("The matching coloured floor sector should point towards this wall. The two floor projectors form ONE floor.",540,36);
    button("calibrate","Return to quiz",55,840);
  }else if(run.phase==="intro"){
    fittedParagraph(config.title,165,150,48);
    const introRows=lines(config.intro,990,34);pages=Math.ceil(introRows.length/6);
    introRows.slice(feedbackPage*6,(feedbackPage+1)*6).forEach((row,i)=>text(row,55,330+i*44,34));
    paragraph("Choose with your feet. No position tracking or automatic scoring is used. Walk safely; keep routes clear.",625,30);
    if(feedbackPage<pages-1)button("feedback",`Instructions ${feedbackPage+1}/${pages} · read next page`,55,800);
    else button("start","Start quiz",55,800);
    button("calibrate","Check room alignment",55,895);
  }else if(run.phase==="ask"||run.phase==="pause"){
    const left=run.phase==="pause"?run.remaining:Math.max(0,run.deadline-now);
    text(`${run.index+1} / ${config.questions.length}   ·   ${Math.ceil(left/1000)} seconds${run.phase==="pause"?" · PAUSED":""}`,55,125,32,"#ffe0a0");
    fittedParagraph(q.q,205,290,38);
    c.fillStyle=option<0?"#20313a":REGION_COLOURS[wall];c.fillRect(55,530,990,195);
    if(option<0)text("No answer on this wall",85,640,40);
    else{const label=String.fromCharCode(65+option),rows=lines(`${label} · ${q.options[option]}`,930,34);rows.forEach((row,i)=>text(row,85,575+i*40,34,"#081d28"));if(rows.length<=2)text("Stand in this region",85,700,28,"#081d28");}
    if(run.phase==="ask"){button("lock","Answer locked in · reveal",55,800);button("pause","Pause timer",55,895);}
    else{button("resume","Resume timer",55,800);if(!pending)button("restart","Restart quiz",55,895);}
  }else if(run.phase==="reveal"){
    const winner=walls[q.correct],correct=winner===wall;
    text(correct?"CORRECT REGION":"ANSWER REVEALED",55,135,40,correct?"#9fffba":"#ffe0a0");
    fittedParagraph(`${String.fromCharCode(65+q.correct)} · ${q.options[q.correct]}`,220,135,42);
    text(`Walk towards ${config.regions[winner]} · wall ${winner+1}`,55,380,30,REGION_COLOURS[winner]);
    const rows=lines(q.why,990,32),perPage=7;pages=Math.ceil(rows.length/perPage);
    rows.slice(feedbackPage*perPage,(feedbackPage+1)*perPage).forEach((row,i)=>text(row,55,445+i*42,32));
    if(pages>1){button("feedback",`Explanation ${feedbackPage+1}/${pages} · next page`,55,760);}
    if(feedbackPage===pages-1){button("confident","Group confident · next question",55,855);button("revisit","Needs revisiting · next question",55,945);}
  }else{
    text("QUIZ COMPLETE",55,190,56);paragraph(`${config.questions.length} questions discussed`,300,40);
    paragraph(`${run.ratings.filter(r=>r==="confident").length} confident · ${run.ratings.filter(r=>r==="revisit").length} to revisit`,430,36);
    paragraph("Tutor reflection only — these are not tracked individual scores or certification.",590,32);
    button("report","Download discussion record",55,800);button("restart","Start again",55,895);
  }
  if(pending&&run.phase==="pause")button("update","Restart with published update",55,895);
  if(pending&&run.phase==="end")button("update","Restart with published update",55,700);
  if(notice)text(notice,55,1030,20,"#ffe0a0");
  return {canvas,actions,pages};
}
