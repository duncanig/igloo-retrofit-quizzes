import { photoUrl, photoDetails, zones, imageFrame, clampOffset } from "./photo-data.js";

export function createPhotoViewer({ hazards, onInspect, onNotice }) {
  const stage=document.createElement("section");stage.id="photo-stage";stage.setAttribute("aria-label","AI-generated construction site inspection image");
  const surface=document.createElement("div");surface.className="photo-surface";
  const image=document.createElement("img");image.src=photoUrl;image.alt="Synthetic construction site: concrete building, lifting operations, trench, dumper, masonry cutting, stacked pipes, site office and electrical supply.";image.draggable=false;
  surface.append(image);stage.append(surface);
  const status=document.createElement("div");status.className="photo-load";status.setAttribute("role","status");status.textContent="Loading the inspection photograph…";stage.append(status);
  const label=document.createElement("span");label.className="photo-credit";label.textContent="AI-GENERATED TRAINING IMAGE · NOT A REAL SITE";stage.append(label);
  document.body.append(stage);
  let frame=null, currentCrop=zones[0].crop, enabled=false, ready=false, dragging=null, moved=false;
  let hintMode=false, reviewed=[];
  const buttons=[];
  for(const [index,h] of hazards.entries()) {
    const detail=photoDetails[h.id], b=document.createElement("button");b.type="button";b.className="photo-hotspot";b.dataset.photoHazard=h.id;
    b.setAttribute("aria-label",`Inspect detail ${index+1}: ${h.zone}`);
    const [x,y,w,hgt]=detail.region;b.style.cssText=`left:${x*100}%;top:${y*100}%;width:${w*100}%;height:${hgt*100}%`;
    const dot=document.createElement("span");dot.className="photo-pin";dot.textContent=String(index+1).padStart(2,"0");
    dot.style.left=`${(detail.point[0]-x)/w*100}%`;dot.style.top=`${(detail.point[1]-y)/hgt*100}%`;b.append(dot);
    b.addEventListener("click",e=>{e.stopPropagation();if(!enabled||(moved&&e.detail!==0))return;moved=false;onInspect(h.id,b);});
    surface.append(b);buttons.push(b);
  }
  function draw() {
    if(!ready)return;
    frame=imageFrame(stage.clientWidth,stage.clientHeight,image.naturalWidth,image.naturalHeight,currentCrop);
    applyFrame();
  }
  function applyFrame() {
    if(!frame)return;
    surface.style.cssText=`width:${frame.width}px;height:${frame.height}px;left:${frame.left}px;top:${frame.top}px`;
    const pinSize=Math.max(12,Math.min(25,stage.clientWidth/30));
    surface.style.setProperty("--pin-size",`${pinSize}px`);
  }
  function focus(crop, fade=true) {
    currentCrop=[...crop];draw();
    if(fade&&ready&&!matchMedia("(prefers-reduced-motion: reduce)").matches)surface.animate([{opacity:.25},{opacity:1}],{duration:240});
  }
  image.addEventListener("load",()=>{ready=true;status.hidden=true;draw();});
  image.addEventListener("error",()=>{ready=false;status.hidden=false;status.textContent="The site image could not load. Reload the page or check that the image is included in the hosted build.";stage.classList.add("photo-error");});
  stage.addEventListener("pointerdown",e=>{
    if(!enabled||!ready||e.button!==0)return;
    dragging={x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY};moved=false;
    // Don't capture a simple tap: its native target remains the hotspot button.
  });
  window.addEventListener("pointermove",e=>{
    if(!dragging||!frame)return;
    if(Math.hypot(e.clientX-dragging.startX,e.clientY-dragging.startY)>6)moved=true;
    if(moved) {
      frame.left=clampOffset(frame.left+e.clientX-dragging.x,stage.clientWidth,frame.width);
      frame.top=clampOffset(frame.top+e.clientY-dragging.y,stage.clientHeight,frame.height);
      applyFrame();
      currentCrop=[-frame.left/frame.width,-frame.top/frame.height,stage.clientWidth/frame.width,stage.clientHeight/frame.height];
    }
    dragging.x=e.clientX;dragging.y=e.clientY;
  });
  window.addEventListener("pointerup",()=>{dragging=null;});
  window.addEventListener("pointercancel",()=>{dragging=null;moved=false;});
  stage.addEventListener("click",e=>{
    if(enabled&&ready&&!moved&&!e.target.closest("button"))onNotice("Inspect the image closely, select a work zone, or turn on location hints in Tools.");
  });
  function setState(answers,hints,interactive) {
    reviewed=answers;hintMode=hints;enabled=interactive;
    stage.inert=!interactive;stage.classList.toggle("hints",hints);
    for(const b of buttons) {
      const done=reviewed.some(a=>a.id===b.dataset.photoHazard);
      b.disabled=done||!enabled||!ready;b.classList.toggle("reviewed",done);
      b.setAttribute("aria-label",`${done?"Reviewed":"Inspect"} detail ${hazards.findIndex(h=>h.id===b.dataset.photoHazard)+1}: ${hazards.find(h=>h.id===b.dataset.photoHazard).zone}`);
    }
  }
  image.addEventListener("load",()=>setState(reviewed,hintMode,enabled));
  if(image.complete&&image.naturalWidth){ready=true;status.hidden=true;}
  return {
    stage, focus, resize:draw, setState,
    inspect(id){focus(photoDetails[id].crop);},
    zoom(factor){
      const [x,y,w,h]=currentCrop;
      const nw=Math.max(.12,Math.min(1,w/factor)),nh=Math.max(.12,Math.min(1,h/factor));
      focus([Math.max(0,Math.min(1-nw,x+w/2-nw/2)),Math.max(0,Math.min(1-nh,y+h/2-nh/2)),nw,nh]);
    },
  };
}
