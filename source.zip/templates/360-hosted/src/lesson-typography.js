export function wrapMeasuredText(value,width,measure) {
  const result=[];
  for(const paragraph of String(value).split("\n")){
    let line="";
    for(const word of paragraph.split(/\s+/).filter(Boolean)){
      if(measure(word)>width){
        if(line){result.push(line);line="";}
        for(const char of word){if(line&&measure(line+char)>width){result.push(line);line="";}line+=char;}
      }else{
        const next=line?line+" "+word:word;
        if(line&&measure(next)>width){result.push(line);line=word;}else line=next;
      }
    }
    result.push(line);
  }
  return result;
}

// Keep feedback comfortably large. Long authored explanations get another
// page instead of silently shrinking to unreadably small type.
export function paginateFeedback(blocks,wrap,height) {
  const pages=[[]];let used=0;
  const fresh=()=>{pages.push([]);used=0;};
  const add=(kind,text,h)=>{pages.at(-1).push({kind,text,y:used,height:h});used+=h;};
  for(const block of blocks){
    const rows=wrap(block.text),headingHeight=block.label?34:0;
    if(used&&used+headingHeight+38>height)fresh();
    if(block.label)add("heading",block.label,34);
    for(const row of rows){
      if(used+38>height){fresh();if(block.label)add("heading",block.label+" · continued",34);}
      add("body",row,38);
    }
    if(used+12<=height)used+=12;
  }
  return pages;
}
