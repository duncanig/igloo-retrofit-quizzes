import test from "node:test";
import assert from "node:assert/strict";
import { lesson, riskLabels, assess, summarise, formatTime } from "./hazards.js";

test("the lesson has eight distinct hazards, two in each work zone",()=>{
  assert.equal(lesson.hazards.length,8);
  assert.equal(new Set(lesson.hazards.map(h=>h.id)).size,8);
  for(const zone of ["Structure","Materials","Services","Groundworks"]) assert.equal(lesson.hazards.filter(h=>h.zone===zone).length,2);
});
test("each hazard has valid content, a risk guide and exactly one correct response",()=>{
  for(const h of lesson.hazards) {
    assert.ok(Object.hasOwn(riskLabels,h.risk));
    assert.equal(h.options.length,3);
    assert.ok(Number.isInteger(h.correct)&&h.correct>=0&&h.correct<3);
    assert.ok(h.position.length===3&&h.position.every(Number.isFinite));
    assert.ok(h.title.length>3);
    for(const key of ["prompt","consequence","explanation","discussion"]) assert.ok(h[key].length>15);
  }
});
test("risk contributes 20 points; the safe response contributes 80",()=>{
  const h=lesson.hazards[0], wrong=(h.correct+1)%3;
  assert.deepEqual(assess(h,h.risk,h.correct),{riskCorrect:true,actionCorrect:true,points:100});
  assert.equal(assess(h,"low",h.correct).points,80);
  assert.equal(assess(h,h.risk,wrong).points,20);
  assert.equal(assess(h,"low",wrong).points,0);
});
test("all correct choices total 800 and no missed hazards",()=>{
  const answers=lesson.hazards.map(h=>({id:h.id,...assess(h,h.risk,h.correct)}));
  assert.deepEqual(summarise(answers),{completed:8,total:8,points:800,max:800,safeActions:8,missed:[]});
});
test("early finish explicitly includes unreviewed hazards",()=>{
  const h=lesson.hazards[0];
  const s=summarise([{id:h.id,...assess(h,h.risk,h.correct)}]);
  assert.equal(s.completed,1);assert.equal(s.points,100);assert.equal(s.missed.length,7);assert.ok(!s.missed.includes(h.id));
});
test("empty inspections report zero without dividing by zero",()=>{
  assert.equal(summarise([]).safeActions,0);assert.equal(summarise([]).missed.length,8);
});
test("time formatting clamps expired countdowns and rounds down",()=>{
  assert.equal(formatTime(-10),"00:00");assert.equal(formatTime(0),"00:00");
  assert.equal(formatTime(65.9),"01:05");assert.equal(formatTime(720),"12:00");
});
