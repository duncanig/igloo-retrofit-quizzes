// Teaching content is kept separate from rendering and scoring. A competent
// construction tutor should review this introductory UK-oriented lesson locally.
export const lesson = {
  title: "Site Survey",
  subtitle: "Construction hazard hunt",
  site: "Northbank / Plot 04",
  hazards: [
    {
      id: "edge", title: "An open edge", zone: "Structure", bearing: 0,
      position: [-5.8, 2.4, -13], risk: "critical",
      prompt: "The first-floor work area has an unprotected edge. What is the strongest immediate response?",
      options: ["Tell workers to take extra care near the edge.", "Stop access and have suitable collective edge protection installed by competent people.", "Issue hi-vis vests before allowing work to continue."],
      correct: 1, consequence: "A fall from height can cause fatal or life-changing injuries—even from a relatively low level.",
      explanation: "Prevent access until the edge is made safe. Suitable guardrails and other collective protection protect everyone; warnings and PPE alone do not prevent a fall.",
      discussion: "Where else would you check for unprotected openings or fragile surfaces?",
    },
    {
      id: "load", title: "A suspended load", zone: "Structure", bearing: 0,
      position: [4.8, 3.5, -12], risk: "critical",
      prompt: "A worker is beneath suspended materials. What should happen first?",
      options: ["Guide the load by standing directly underneath it.", "Allow the lift if the worker wears a hard hat.", "Stop the operation safely, clear the danger area and enforce an exclusion zone under the lift plan."],
      correct: 2, consequence: "A falling or swinging load can crush a person. A hard hat does not make standing beneath a load safe.",
      explanation: "People must be kept clear of the lifting danger area. A competent lifting team must manage the lift and exclusion zone; learners should not attempt to move the load themselves.",
      discussion: "Who needs to communicate before lifting resumes?",
    },
    {
      id: "excavation", title: "An unprotected excavation", zone: "Groundworks", bearing: -90,
      position: [-13, 0.1, -4], risk: "critical",
      prompt: "An open trench is beside the pedestrian route with no barrier. What is the best response?",
      options: ["Prevent access, report it, and arrange suitable barriers and competent excavation assessment.", "Put a loose plank across it for pedestrians.", "Enter the trench to check its sides yourself."],
      correct: 0, consequence: "People can fall into the excavation; unsupported sides may collapse and bury anyone entering it.",
      explanation: "Keep people away and notify the responsible supervisor. Competent people must assess stability, protection and access. Never enter an unsafe excavation or attempt an unplanned rescue.",
      discussion: "How could rain, spoil heaps or nearby vehicles change the risk?",
    },
    {
      id: "traffic", title: "People and plant", zone: "Groundworks", bearing: -90,
      position: [-13, 1.2, 5], risk: "critical",
      prompt: "A worker is close behind a dumper in an unsegregated plant area. If vehicle movements are taking place, what is the strongest control?",
      options: ["Ask pedestrians to listen for reversing alarms.", "Stop the conflict safely and establish segregated pedestrian routes and controlled crossings.", "Rely on everyone wearing reflective clothing."],
      correct: 1, consequence: "A pedestrian can be struck or crushed in a driver's blind spot.",
      explanation: "Separate people from plant wherever practicable. Plan routes, crossings and visibility with the supervisor; do not approach moving plant to attract a driver's attention.",
      discussion: "Where are the blind spots, and how would visitors know the safe route?",
    },
    {
      id: "electric", title: "Damaged electrical equipment", zone: "Services", bearing: 180,
      position: [5, 0.5, 12], risk: "critical",
      prompt: "A cable has a damaged outer sheath next to water. What should you do?",
      options: ["Wrap the cable in tape and keep working.", "Move it by hand away from the water.", "Keep clear, prevent use and have the supply safely isolated and the equipment checked by a competent person."],
      correct: 2, consequence: "Damaged electrical equipment may cause electric shock, burns or fire; water can increase the danger.",
      explanation: "Do not touch suspect live equipment, water or exposed conductors. Report and prevent use. Safe isolation, inspection and repair are tasks for appropriately competent people.",
      discussion: "How would you stop someone else using equipment you have reported?",
    },
    {
      id: "exit", title: "A blocked escape route", zone: "Services", bearing: 180,
      position: [-5, 1, 13], risk: "high",
      prompt: "Materials obstruct the signed emergency exit. What is the best action?",
      options: ["Arrange safe removal of the obstruction and keep the escape route clear.", "Leave it until the next delivery arrives.", "Cover the exit sign so people choose another way out."],
      correct: 0, consequence: "An obstruction can delay evacuation and trap people during a fire or other emergency.",
      explanation: "Maintain clear, usable escape routes at all times. Coordinate safe removal without unsafe lifting and check that doors and access remain usable.",
      discussion: "How would you check that an alternative route is actually available?",
    },
    {
      id: "dust", title: "Uncontrolled cutting dust", zone: "Materials", bearing: 90,
      position: [12, 1.1, -5], risk: "high",
      prompt: "Dry cutting masonry is producing a cloud of dust. Which response tackles the source?",
      options: ["Open a nearby door and continue cutting.", "Stop uncontrolled cutting and arrange suitable source controls, such as effective extraction or water suppression, with any required suitable RPE.", "Give the operator any loose-fitting dust mask and carry on."],
      correct: 1, consequence: "Respirable crystalline silica from masonry dust can cause serious long-term lung disease. Nearby workers can also be exposed.",
      explanation: "Eliminate or reduce dust at source with a suitable assessed method. Any required respiratory protection must be correctly selected and, for tight-fitting RPE, face-fit tested; a generic mask is not a substitute for source controls.",
      discussion: "Why can a hazard be serious even if its harm is not immediate?",
    },
    {
      id: "storage", title: "Unstable material storage", zone: "Materials", bearing: 90,
      position: [12, 1.4, 5], risk: "high",
      prompt: "Heavy pipes are stacked without restraints beside a walkway. What is the safest approach?",
      options: ["Take a pipe from the bottom of the pile.", "Ask someone to hold the stack while you walk past.", "Keep people clear and arrange stable storage with suitable racks or restraints and safe handling."],
      correct: 2, consequence: "Unrestrained pipes can roll or collapse, striking or crushing people.",
      explanation: "Isolate the unsafe area and arrange suitable storage and handling with the supervisor. Do not attempt to catch or steady a shifting stack.",
      discussion: "How should deliveries be planned so storage does not encroach on walkways?",
    },
  ],
};

export const riskLabels = { critical: "Critical · immediate danger", high: "High · serious harm", low: "Low · minor harm" };

export function assess(hazard, risk, option) {
  return { riskCorrect: risk === hazard.risk, actionCorrect: option === hazard.correct,
    points: (risk === hazard.risk ? 20 : 0) + (option === hazard.correct ? 80 : 0) };
}

export function summarise(answers, hazards = lesson.hazards) {
  return { completed: answers.length, total: hazards.length,
    points: answers.reduce((sum, a) => sum + a.points, 0), max: hazards.length * 100,
    safeActions: answers.filter(a => a.actionCorrect).length,
    missed: hazards.filter(h => !answers.some(a => a.id === h.id)).map(h => h.id) };
}

export function formatTime(seconds) {
  const s = Math.max(0, Math.floor(seconds));
  return `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;
}
