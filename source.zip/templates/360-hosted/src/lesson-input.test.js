import test from "node:test";
import assert from "node:assert/strict";
import { createLessonGesture,sourceEventPoint } from "./lesson-input.js";
import { roomPanel } from "./room-layout.js";
import { panelToSource,sourceToPanel } from "./projection.js";

const point=(x,y,type="pointerdown",extra={})=>({clientX:x,clientY:y,button:0,type,...extra});
test("room input is not cancelled by movement greater than six CSS pixels",()=>{
  const room=createLessonGesture();room.down(point(200,200));
  assert.deepEqual(room.move(point(260,240)),{drag:false,dx:60});
  assert.equal(room.release(),true);assert.equal(room.blocked(point(260,240)),false);
});
test("desktop preview still treats a dragged camera as a drag, not a click",()=>{
  let now=0;const desktop=createLessonGesture({desktop:true,clock:()=>now});desktop.down(point(200,200));
  assert.equal(desktop.move(point(260,240)).drag,true);assert.equal(desktop.release(),false);
  assert.equal(desktop.blocked(point(260,240)),true);now=351;assert.equal(desktop.blocked(point(260,240)),false);
});
test("handled pointerup/mouseup/click events activate once even if compatibility coordinates differ",()=>{
  const gate=createLessonGesture();gate.down(point(20,20));gate.release();gate.handled(point(20,20,"pointerup"));
  assert.equal(gate.duplicate(point(50,50,"mouseup")),true);assert.equal(gate.duplicate(point(50,50,"click")),true);
  // A new physical press is allowed immediately, including another button.
  gate.down(point(50,50));assert.equal(gate.duplicate(point(50,50)),false);
});
test("a source-coordinate miss never swallows a corrected click",()=>{
  const gate=createLessonGesture();gate.down(point(20,20));gate.release();
  assert.equal(gate.duplicate(point(50,50,"click")),false);
  gate.cancel();assert.equal(gate.blocked(point(50,50,"click")),false);
});
test("touch-generated compatibility mouse presses do not reset a handled touch",()=>{
  const gate=createLessonGesture();gate.down(point(20,20,"pointerdown",{pointerType:"touch"}));gate.release();gate.handled(point(20,20,"pointerup",{pointerType:"touch"}));
  assert.equal(gate.down(point(20,20,"mousedown")),false);assert.equal(gate.duplicate(point(20,20,"click")),true);
});
test("CSS coordinates do not use framebuffer/HiDPI sizes or clamp out-of-bounds host input onto a button",()=>{
  const rect={left:100,top:50,width:2000,height:1000};
  assert.deepEqual(sourceEventPoint(point(1100,550),rect),[.5,.5]);
  assert.equal(sourceEventPoint(point(4100,2050),rect),null);assert.equal(sourceEventPoint(point(NaN,100),rect),null);
  assert.equal(sourceEventPoint(point(100,100),{...rect,width:0}),null);
});
test("adding the projected diagnostic footer preserves panel button hit coordinates",()=>{
  for(const height of [430,1260]){
    const panel=roomPanel(1100,height),u=550/1100,v=(height===430?177:837)/height;
    const back=sourceToPanel(...panelToSource(u,v,panel),panel);
    assert.ok(back);assert.ok(Math.abs(back[0]-u)<1e-8);assert.ok(Math.abs(back[1]-v)<1e-8);
  }
});
