import test from "node:test";
import assert from "node:assert/strict";
import { defaultRegionQuiz,validateRegionQuiz,answerWalls,wallHeading,regionAtLongitude } from "./region-config.js";
import { newRegionRun,startQuestion,lockRegionAnswer,tickRegion,pauseRegion,resumeRegion,nextRegion } from "./region-runtime.js";
import { roomPanel } from "./room-layout.js";
import { panelToSource,sourceToPanel } from "./projection.js";
import { paintRegionUI } from "./region-ui.js";

test("original sample questions are valid, including opposite-wall true/false",()=>{
  const c=defaultRegionQuiz();assert.deepEqual(validateRegionQuiz(c),c);assert.equal(c.questions.length,8);
  assert.deepEqual(answerWalls(2),[0,2]);assert.deepEqual(answerWalls(3),[0,1,2]);
  for(let wall=0;wall<4;wall++)for(const rotation of [-Math.PI,0,.3,Math.PI])assert.equal(regionAtLongitude(wallHeading(wall,rotation),rotation),wall);
});
test("region import rejects invalid answer keys, unsafe/unbounded content and timer values",()=>{
  for(const seconds of [0,4,301,NaN,"30"]){assert.equal(validateRegionQuiz({...defaultRegionQuiz(),seconds}),null);}
  const c=defaultRegionQuiz();c.questions[0].correct=4;assert.equal(validateRegionQuiz(c),null);
  c.questions[0].correct=0;c.questions[0].options[0]="";assert.equal(validateRegionQuiz(c),null);
  assert.equal(validateRegionQuiz({...defaultRegionQuiz(),questions:[]}),null);
});
test("first of timer/manual lock wins once; late input cannot advance or duplicate reveal",()=>{
  const c=defaultRegionQuiz(),r=newRegionRun();startQuestion(r,c,1000);assert.equal(tickRegion(r,30999),false);
  assert.equal(lockRegionAnswer(r,31000),true);assert.equal(tickRegion(r,31000),false);assert.equal(lockRegionAnswer(r,31001),false);assert.equal(r.phase,"reveal");
  assert.equal(nextRegion(r,c,"confident",32000),true);assert.equal(r.index,1);assert.equal(nextRegion(r,c,"confident",32001),false);
  assert.equal(tickRegion(r,62000),true);assert.equal(lockRegionAnswer(r,62000),false);
});
test("pause freezes remaining time; resume, end and restart do not reuse a deadline",()=>{
  const c=defaultRegionQuiz(),r=newRegionRun();startQuestion(r,c,1000);pauseRegion(r,11000);assert.equal(r.remaining,20000);
  assert.equal(tickRegion(r,100000),false);resumeRegion(r,100000);assert.equal(r.deadline,120000);assert.equal(tickRegion(r,119999),false);assert.equal(tickRegion(r,120000),true);
  while(r.phase!=="end"){if(r.phase==="ask")lockRegionAnswer(r,130000);nextRegion(r,c,"revisit",130000);}
  assert.equal(r.ratings.length,c.questions.length);assert.equal(r.deadline,null);assert.equal(newRegionRun().phase,"intro");
});
test("four projected panels preserve input round trips including the source seam",()=>{
  for(let i=0;i<4;i++){const panel=roomPanel(1100,1050,{lon:wallHeading(i,.4)});for(const [u,v] of [[.1,.2],[.5,.5],[.9,.95]]){
    const p=sourceToPanel(...panelToSource(u,v,panel),panel);assert.ok(p);assert.ok(Math.abs(p[0]-u)<1e-8);assert.ok(Math.abs(p[1]-v)<1e-8);
  }}
});
test("region UI keeps controls non-overlapping for all phases and paginates long explanations",t=>{
  const old=globalThis.document;globalThis.document={createElement(){const c={font:"",fillRect(){},strokeRect(){},measureText(s){return {width:s.length*Number(/([\d.]+)px/.exec(this.font)?.[1]||32)*.6};},fillText(){}};return {getContext(){return c;}};}};t.after(()=>{globalThis.document=old;});
  const config=defaultRegionQuiz();config.questions[0].why="A long explanation for teaching discussion. ".repeat(23).slice(0,1000);
  for(const phase of ["intro","ask","pause","reveal","end"])for(const pending of [false,true])for(let wall=0;wall<4;wall++){
    const run={...newRegionRun(),phase,deadline:30000,remaining:10000};
    const first=paintRegionUI({config,run,wall,now:0,pending});if(phase==="reveal")assert.ok(first.pages>1);
    for(let feedbackPage=0;feedbackPage<first.pages;feedbackPage++){
      const ui=paintRegionUI({config,run,wall,now:0,pending,feedbackPage});
      for(const a of ui.actions)assert.ok(a.x>=0&&a.y>=0&&a.x+a.w<=1100&&a.y+a.h<=1050,a.key);
      for(let i=0;i<ui.actions.length;i++)for(const b of ui.actions.slice(i+1)){const a=ui.actions[i];assert.equal(a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y,false,`${phase}: ${a.key}/${b.key}`);}
    }
  }
});
