import * as THREE from "three";
import { panelBasis } from "./projection.js";
import { REGION_COLOURS } from "./region-config.js";

// Four wall-facing textures in a single atlas. The shader and input both use
// the same tangent-panel geometry; the floor is one continuous spherical band,
// never two independent projector tiles.
export function createRegionRenderer(canvas,{desktop=false,rotation=0}={}) {
  const renderer=new THREE.WebGLRenderer({canvas,antialias:false});
  renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));
  const atlas=document.createElement("canvas");atlas.width=2200;atlas.height=2100;
  const texture=new THREE.CanvasTexture(atlas);texture.colorSpace=THREE.SRGBColorSpace;
  const vectors=()=>Array.from({length:4},()=>new THREE.Vector3());
  const uniforms={uAtlas:{value:texture},uForward:{value:vectors()},uRight:{value:vectors()},uUp:{value:vectors()},
    uHalf:{value:Array.from({length:4},()=>new THREE.Vector2())},uOffset:{value:[0,0,0,0]},
    uColours:{value:REGION_COLOURS.map(c=>new THREE.Color(c))},uWinner:{value:-1},uDesktop:{value:desktop},
    uYaw:{value:0},uRotation:{value:rotation},uAspect:{value:innerWidth/innerHeight}};
  const scene=new THREE.Scene(),camera=new THREE.OrthographicCamera(-1,1,1,-1,0,1);
  const material=new THREE.ShaderMaterial({uniforms,depthTest:false,depthWrite:false,
    vertexShader:`varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}`,
    fragmentShader:`precision highp float;varying vec2 vUv;uniform sampler2D uAtlas;
      uniform vec3 uForward[4],uRight[4],uUp[4],uColours[4];uniform vec2 uHalf[4];uniform float uOffset[4];
      uniform bool uDesktop;uniform float uYaw,uRotation,uAspect,uWinner;const float PI=3.141592653589793;
      void main(){
        vec3 d;float lon,lat;
        if(uDesktop){d=normalize(vec3(sin(uYaw),0.,cos(uYaw))+vec3(cos(uYaw),0.,-sin(uYaw))*(vUv.x-.5)*2.*1.428148006*uAspect+vec3(0.,1.,0.)*(vUv.y-.5)*2.*1.428148006);
          lon=atan(d.x,d.z);lat=asin(clamp(d.y,-1.,1.));}
        else{lon=(vUv.x-.5)*2.*PI;lat=(vUv.y-.5)*PI;d=vec3(sin(lon)*cos(lat),sin(lat),cos(lon)*cos(lat));}
        float sector=mod(floor((lon-uRotation+PI/4.)/(PI/2.)),4.);
        vec3 colour=vec3(.025,.07,.095);
        for(int i=0;i<4;i++){
          if(abs(sector-float(i))<.1){
            float strength=lat<-.25?.22:.08;
            if(uWinner>=0.)strength=abs(uWinner-float(i))<.1?.65:.035;
            colour=mix(colour,uColours[i],strength);
            if(uWinner>=0.&&abs(uWinner-float(i))<.1)colour=mix(colour,vec3(.25,1.,.45),.25);
          }
        }
        // Corner guides and a restrained floor ring carry no reading content.
        float edge=abs(fract((lon-uRotation+PI/4.)/(PI/2.))-.5);
        if(lat<-.25&&edge>.495)colour+=vec3(.16);
        if(abs(lat+.85)<.008)colour+=vec3(.12);
        for(int i=0;i<4;i++){
          float z=dot(d,uForward[i]);
          if(z>0.){vec2 p=vec2(.5+dot(d,uRight[i])/(z*uHalf[i].x*2.),.5+(dot(d,uUp[i])/z-uOffset[i])/(uHalf[i].y*2.));
            if(p.x>=0.&&p.x<=1.&&p.y>=0.&&p.y<=1.){
              vec2 cell=vec2(mod(float(i),2.),1.-floor(float(i)/2.));
              vec4 panel=texture2D(uAtlas,(p+cell)/2.);colour=mix(colour,panel.rgb,panel.a);
            }
          }
        }
        gl_FragColor=vec4(colour,1.);
        #include <colorspace_fragment>
      }`});
  scene.add(new THREE.Mesh(new THREE.PlaneGeometry(2,2),material));
  function resize(){renderer.setSize(innerWidth,innerHeight);uniforms.uAspect.value=innerWidth/innerHeight;}
  resize();
  return {resize,update(pages,panels,winner){
    const c=atlas.getContext("2d");c.clearRect(0,0,atlas.width,atlas.height);
    pages.forEach((page,i)=>{c.drawImage(page.canvas,(i%2)*1100,Math.floor(i/2)*1050);const p=panels[i],b=panelBasis(p.lon,p.lat);
      for(const [key,value] of [["uForward",b.forward],["uRight",b.right],["uUp",b.up]])uniforms[key].value[i].fromArray(value);
      uniforms.uHalf.value[i].set(p.halfWidth,p.halfHeight);uniforms.uOffset.value[i]=p.offsetY||0;});
    uniforms.uWinner.value=winner;texture.needsUpdate=true;
  },draw(yaw){uniforms.uYaw.value=yaw;renderer.render(scene,camera);}};
}
