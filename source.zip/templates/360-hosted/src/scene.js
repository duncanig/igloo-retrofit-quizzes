import * as THREE from "three";
import { photoUrl, zones } from "./photo-data.js";

// A gallery of flat photographic inspection boards, NOT a seamless panorama.
// The interactive photograph is DOM in the front face; the other room faces
// show contextual work-zone boards, without inventing 3D camera parallax.
export function buildScene() {
  const scene=new THREE.Scene();scene.background=new THREE.Color("#132a25");
  const boards=[];
  const texture=new THREE.TextureLoader().load(photoUrl,()=>{for(const t of boards){t.image=texture.image;t.needsUpdate=true;}});
  texture.colorSpace=THREE.SRGBColorSpace;
  for(const [index,zone] of [zones[0],zones[1],zones[3],zones[4]].entries()) {
    const t=texture.clone();
    const [x,y,w,h]=zone.crop;t.repeat.set(w,h);t.offset.set(x,1-y-h);
    // Texture clones receive their image when the single underlying load ends.
    const ratio=2*w/h;
    const panel=new THREE.Mesh(new THREE.PlaneGeometry(Math.min(23,16*ratio),Math.min(16,23/ratio)),new THREE.MeshBasicMaterial({map:t,toneMapped:false}));
    const angle=[0,-Math.PI/2,Math.PI/2,Math.PI][index];
    panel.position.set(Math.sin(angle)*14,2.2,-Math.cos(angle)*14);panel.rotation.y=-angle;
    scene.add(panel);boards.push(t);
  }
  const update=()=>{if(texture.image)for(const t of boards)if(t.image!==texture.image){t.image=texture.image;t.needsUpdate=true;}};
  return {scene,update};
}
