import { defaultLesson,validateLesson } from "./lesson-config.js";
import { defaultRegionQuiz,validateRegionQuiz } from "./region-config.js";
export const validateActivity=v=>v?.kind==="region-quiz"?validateRegionQuiz(v):validateLesson(v);
export const defaultActivity=room=>room.startsWith("region-")?defaultRegionQuiz():defaultLesson();
