import "./editor.css";
import { defaultRegionQuiz,validateRegionQuiz } from "./region-config.js";
import { createOutputLink,STATIC_HOST } from "./output-link.js";

const root=document.getElementById("editor");
let draft=defaultRegionQuiz(),expectedRevision=draft.revision,message="Loading publication…",dirty=false,busy=false;
const link=createOutputLink({role:"control",defaultRoom:"region-quiz",onLesson(value){if(value.revision!==expectedRevision){message="A different revision is published. Export your draft before reloading.";status();}}});
const key=`igloo-region-draft-v1:${link.room}`;
const escape=v=>String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const url=new URL("region.html",location.href);url.searchParams.set("room",link.room);const preview=new URL(url);preview.searchParams.set("desktop","1");
url.hash=location.hash;preview.hash=location.hash;
function status(){document.getElementById("message").textContent=message;}
function save(){dirty=true;try{localStorage.setItem(key,JSON.stringify({draft,expectedRevision}));message="Draft saved in this browser. Publish to update the play page.";}catch{message="Draft cannot be saved in this browser. Export JSON before closing.";}status();}
function field(label,value,attrs,max,area=false){return `<label>${label}${area?`<textarea ${attrs} maxlength="${max}" rows="3">${escape(value)}</textarea>`:`<input ${attrs} maxlength="${max}" value="${escape(value)}">`}</label>`;}
function render(){root.innerHTML=`<header><a class="brand" href="sessions.html">REGION QUIZ <small>ACTIVITY EDITOR</small></a><div class="header-links"><a target="_blank" rel="noopener" href="${escape(preview.href)}">Test quiz ↗</a><a target="_blank" rel="noopener" href="${escape(url.href)}">Open ICE quiz ↗</a><button id="publish" class="primary" ${busy?"disabled":""}>Publish changes</button></div></header>
  <div class="editor-status"><p id="message" role="status">${escape(message)}</p></div>
  <main><aside><h2>Session settings</h2>${field("Title",draft.title,'data-field="title"',90)}${field("Instructions",draft.intro,'data-field="intro"',450,true)}
  <label>Seconds per question<input id="seconds" type="number" min="5" max="300" value="${draft.seconds}"></label>
  ${draft.regions.map((r,i)=>field(`Wall ${i+1} region name`,r,`data-region="${i}"`,30)).join("")}
  <div class="file-actions"><button id="export">Export activity JSON</button><label class="file-button">Import activity JSON<input id="import" type="file" accept=".json,application/json"></label><button id="reload">Reload published version</button><button id="add">Add question</button></div>
  <p>Closing this editor does not stop the quiz. Timer expiry or the projected “Answer locked in” control reveals the correct region. Two-choice questions use opposite walls.</p>
  <p class="fine">Adapted from your QuickFloorSessions region quiz. These are the original eight sample questions, not a construction assessment. Edit for your teaching topic. No tracking, recorded narration or individual scoring. Export JSON to back up unpublished drafts.</p></aside>
  <section class="question-editor"><h1>Questions & answers</h1>${draft.questions.map((q,i)=>`<fieldset><legend>Question ${i+1}</legend>${field("Question",q.q,`data-question="${i}" data-part="q"`,240,true)}
  <label>Number of answers<select data-count="${i}">${[2,3,4].map(n=>`<option ${n===q.options.length?"selected":""}>${n}</option>`).join("")}</select></label>
  ${q.options.map((o,j)=>`<label class="option-edit"><span><input type="radio" name="correct-${i}" data-correct="${i}" value="${j}" ${j===q.correct?"checked":""}>${String.fromCharCode(65+j)} · correct answer</span><textarea data-question="${i}" data-option="${j}" maxlength="100" rows="2">${escape(o)}</textarea></label>`).join("")}
  ${field("Explanation",q.why,`data-question="${i}" data-part="why"`,1000,true)}<button data-delete="${i}" ${draft.questions.length===1?"disabled":""}>Remove question</button></fieldset>`).join("")}</section></main>`;
  root.querySelectorAll("[data-field]").forEach(e=>e.oninput=()=>{draft[e.dataset.field]=e.value;save();});
  root.querySelectorAll("[data-region]").forEach(e=>e.oninput=()=>{draft.regions[Number(e.dataset.region)]=e.value;save();});
  document.getElementById("seconds").oninput=e=>{draft.seconds=Number(e.target.value);save();};
  root.querySelectorAll("[data-question]").forEach(e=>e.oninput=()=>{const q=draft.questions[Number(e.dataset.question)];if(e.dataset.option!==undefined)q.options[Number(e.dataset.option)]=e.value;else q[e.dataset.part]=e.value;save();});
  root.querySelectorAll("[data-correct]").forEach(e=>e.onchange=()=>{draft.questions[Number(e.dataset.correct)].correct=Number(e.value);save();});
  root.querySelectorAll("[data-count]").forEach(e=>e.onchange=()=>{const q=draft.questions[Number(e.dataset.count)],n=Number(e.value);q.options=Array.from({length:n},(_,i)=>q.options[i]||"");q.correct=Math.min(q.correct,n-1);save();render();});
  root.querySelectorAll("[data-delete]").forEach(e=>e.onclick=()=>{draft.questions.splice(Number(e.dataset.delete),1);save();render();});
  document.getElementById("add").onclick=()=>{if(draft.questions.length>=40){message="Maximum 40 questions.";status();return;}draft.questions.push({q:"New question",options:["Answer A","Answer B","Answer C","Answer D"],correct:0,why:"Explain the correct answer."});save();render();};
  document.getElementById("export").onclick=()=>{const url=URL.createObjectURL(new Blob([JSON.stringify(draft,null,2)],{type:"application/json"})),a=document.createElement("a");a.href=url;a.download="region-quiz.json";a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);};
  document.getElementById("import").onchange=async e=>{try{const file=e.target.files[0];if(!file||file.size>128*1024)throw Error();const valid=validateRegionQuiz(JSON.parse(await file.text()));if(!valid)throw Error();draft=valid;save();render();}catch{message="Invalid region activity JSON. Check question, answer and text limits.";status();}};
  document.getElementById("reload").onclick=async()=>{if(dirty&&!confirm("Discard this browser's unpublished region draft? Export it first if needed."))return;await load(false);};
  document.getElementById("publish").onclick=async()=>{const valid=validateRegionQuiz(draft);if(!valid){message="Check all fields: 5–300 seconds, 1–40 questions, 2–4 filled answers, a valid answer key and explanation.";status();return;}busy=true;render();const result=await link.request("lesson",{lesson:valid,expectedRevision});busy=false;if(result.lesson){draft=result.lesson;expectedRevision=draft.revision;dirty=false;try{localStorage.removeItem(key);}catch{}if(result.fragment){url.hash=result.fragment;preview.hash=result.fragment;message="Play link created. Copy it below to the venue PC. Older links are unchanged.";}else message="Published. Active quizzes keep their answer key until explicitly restarted with the update.";}else message=result.error||"Publication failed. Your draft is safe.";render();};
  if(STATIC_HOST){document.getElementById("publish").textContent="Create shareable play link";
    const note=document.createElement("p");note.textContent="Hosted edition: edits stay in this browser until you create and copy a shareable play link. Links contain the answer key and are not private exams. No local server or files needed.";root.querySelector("aside").prepend(note);
    if(url.hash){const label=document.createElement("label");label.textContent="Copy this play URL to ICE on the other computer";const input=document.createElement("input");input.readOnly=true;input.value=url.href;input.onclick=()=>input.select();label.append(input);root.querySelector(".editor-status").append(label);}}
}
async function load(restore=true){try{const valid=validateRegionQuiz(await link.lesson());if(!valid)throw Error("Wrong activity type for this room. Use a room starting region-.");draft=valid;expectedRevision=valid.revision;dirty=false;message="Published quiz loaded.";if(restore){try{const saved=JSON.parse(localStorage.getItem(key));if(validateRegionQuiz(saved?.draft)){draft=saved.draft;expectedRevision=saved.expectedRevision;dirty=true;message="Unpublished browser draft restored.";}}catch{}}else{try{localStorage.removeItem(key);}catch{}}}catch(error){message=`${error.message} Bundled sample shown; publication requires the local host.`;}render();}
render();load();window.addEventListener("pagehide",()=>link.close());
