import * as THREE from "three";
import { panelBasis } from "./projection.js";
import { lessonRenderSize } from "./render-size.js";

export function createLessonRenderer(canvas,{desktop=false}={}) {
  const renderer=new THREE.WebGLRenderer({canvas,antialias:false,alpha:false});
  renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.setPixelRatio(1);
  const gl=renderer.getContext(),limits={maxViewport:Array.from(gl.getParameter(gl.MAX_VIEWPORT_DIMS)),
    maxRenderbuffer:gl.getParameter(gl.MAX_RENDERBUFFER_SIZE),maxTexture:gl.getParameter(gl.MAX_TEXTURE_SIZE)};
  let renderInfo=null;
  const scene=new THREE.Scene(),camera=new THREE.OrthographicCamera(-1,1,1,-1,0,1);
  const transparent=new THREE.DataTexture(new Uint8Array([0,0,0,0]),1,1);transparent.needsUpdate=true;
  const uniforms={uPhoto:{value:transparent},uPanel:{value:transparent},uMarks:{value:transparent},
    uForward:{value:new THREE.Vector3(0,0,1)},uRight:{value:new THREE.Vector3(1,0,0)},uUp:{value:new THREE.Vector3(0,1,0)},
    uHalf:{value:new THREE.Vector2(1,1)},uOffsetY:{value:0},uDesktop:{value:desktop},uYaw:{value:0},uAspect:{value:innerWidth/innerHeight}};
  const material=new THREE.ShaderMaterial({uniforms,depthTest:false,depthWrite:false,vertexShader:`varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}`,
    fragmentShader:`precision highp float;varying vec2 vUv;uniform sampler2D uPhoto,uPanel,uMarks;
      uniform vec3 uForward,uRight,uUp;uniform vec2 uHalf;uniform bool uDesktop;uniform float uYaw,uAspect,uOffsetY;
      const float PI=3.141592653589793;
      void main(){
        vec3 d;vec2 source=vUv;
        if(uDesktop){vec3 f=vec3(sin(uYaw),0.,cos(uYaw));vec3 r=vec3(cos(uYaw),0.,-sin(uYaw));
          d=normalize(f+r*(vUv.x-.5)*2.*1.428148006*uAspect+vec3(0.,1.,0.)*(vUv.y-.5)*2.*1.428148006);
          source=vec2(atan(d.x,d.z)/(2.*PI)+.5,asin(clamp(d.y,-1.,1.))/PI+.5);
        }else{float lon=(vUv.x-.5)*2.*PI,lat=(vUv.y-.5)*PI;d=vec3(sin(lon)*cos(lat),sin(lat),cos(lon)*cos(lat));}
        vec4 color=texture2D(uPhoto,source);vec4 marks=texture2D(uMarks,source);color.rgb=mix(color.rgb,marks.rgb,marks.a);
        float z=dot(d,uForward);if(z>0.){vec2 p=vec2(.5+dot(d,uRight)/(z*uHalf.x*2.),.5+(dot(d,uUp)/z-uOffsetY)/(uHalf.y*2.));
          if(p.x>=0.&&p.x<=1.&&p.y>=0.&&p.y<=1.){vec4 panel=texture2D(uPanel,p);color.rgb=mix(color.rgb,panel.rgb,panel.a);}}
        gl_FragColor=vec4(color.rgb,1.);
        #include <colorspace_fragment>
      }`});
  scene.add(new THREE.Mesh(new THREE.PlaneGeometry(2,2),material));
  let panelTexture=null,markTexture=null,photoTexture=null;
  function resize(){
    const size=lessonRenderSize(innerWidth,innerHeight,{desktop,dpr:devicePixelRatio,...limits});
    // false preserves the full-size CSS canvas, hence the SAME normalised input
    // geometry. Do not shrink the DOM canvas to the internal texture dimensions.
    renderer.setSize(size.width,size.height,false);uniforms.uAspect.value=innerWidth/innerHeight;
    renderInfo={...size,...limits,actualWidth:gl.drawingBufferWidth,actualHeight:gl.drawingBufferHeight};
  }
  resize();
  return {
    resize,
    diagnostics(){return {...renderInfo};},
    image(image){photoTexture?.dispose();photoTexture=new THREE.Texture(image);photoTexture.colorSpace=THREE.SRGBColorSpace;photoTexture.needsUpdate=true;uniforms.uPhoto.value=photoTexture;},
    panel(canvas,p){panelTexture?.dispose();panelTexture=new THREE.CanvasTexture(canvas);panelTexture.colorSpace=THREE.SRGBColorSpace;uniforms.uPanel.value=panelTexture;
      const b=panelBasis(p.lon,p.lat);uniforms.uForward.value.fromArray(b.forward);uniforms.uRight.value.fromArray(b.right);uniforms.uUp.value.fromArray(b.up);uniforms.uHalf.value.set(p.halfWidth,p.halfHeight);uniforms.uOffsetY.value=p.offsetY||0;},
    marks(canvas){if(!markTexture){markTexture=new THREE.CanvasTexture(canvas);markTexture.colorSpace=THREE.SRGBColorSpace;uniforms.uMarks.value=markTexture;}markTexture.needsUpdate=true;},
    draw(yaw){uniforms.uYaw.value=yaw;renderer.render(scene,camera);},
  };
}
