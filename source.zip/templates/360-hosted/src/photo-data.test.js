import test from "node:test";
import assert from "node:assert/strict";
import { zones, photoDetails, imageFrame, clampOffset } from "./photo-data.js";
import { lesson } from "./hazards.js";

test("each lesson hazard has an in-bounds photo target and inspection crop",()=>{
  assert.deepEqual(Object.keys(photoDetails).sort(),lesson.hazards.map(h=>h.id).sort());
  for(const d of Object.values(photoDetails)) {
    for(const rect of [d.region,d.crop]) {
      const [x,y,w,h]=rect;
      assert.ok(x>=0&&y>=0&&w>0&&h>0&&x+w<=1.00001&&y+h<=1.00001);
    }
    const [x,y,w,h]=d.region;
    assert.ok(d.point[0]>=x&&d.point[0]<=x+w&&d.point[1]>=y&&d.point[1]<=y+h);
  }
});
test("overview fits the full source without stretching or cropping",()=>{
  const f=imageFrame(800,600,1774,887,zones[0].crop);
  assert.equal(f.width,800);assert.equal(f.height,400);assert.equal(f.left,0);assert.equal(f.top,100);
});
test("zone crops retain the source aspect ratio",()=>{
  for(const z of zones){const f=imageFrame(900,500,1774,887,z.crop);assert.ok(Math.abs(f.width/f.height-2)<.00001);}
});
test("panning cannot expose empty edges of an enlarged image",()=>{
  assert.equal(clampOffset(50,800,1600),0);assert.equal(clampOffset(-2000,800,1600),-800);
  assert.equal(clampOffset(-30,800,400),200);
});
