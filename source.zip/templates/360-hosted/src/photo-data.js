// Coordinates refer to the approved, synthetic image, not the old 3D model.
// All rectangles and points are normalised image coordinates (top-left origin).
export const photoUrl = `${import.meta.env?.BASE_URL ?? "/"}images/construction-panorama.png`;
export const zones = [
  { id: "overview", name: "Whole site", crop: [0, 0, 1, 1] },
  { id: "groundworks", name: "Groundworks", crop: [0, .29, .27, .63] },
  { id: "structure", name: "Structure", crop: [.24, .15, .31, .54] },
  { id: "materials", name: "Materials", crop: [.52, .34, .3, .44] },
  { id: "services", name: "Services", crop: [.75, .32, .25, .61] },
];
export const photoDetails = {
  edge: { point: [.318, .365], region: [.294, .286, .058, .14], crop: [.225, .2, .24, .37] },
  load: { point: [.451, .46], region: [.411, .325, .075, .28], crop: [.355, .27, .2, .39] },
  excavation: { point: [.059, .696], region: [.005, .528, .119, .33], crop: [0, .4, .23, .51] },
  traffic: { point: [.216, .551], region: [.145, .41, .097, .22], crop: [.1, .33, .19, .35] },
  electric: { point: [.865, .811], region: [.831, .773, .087, .065], crop: [.72, .64, .28, .32] },
  exit: { point: [.917, .555], region: [.862, .47, .092, .17], crop: [.81, .34, .19, .39] },
  dust: { point: [.627, .562], region: [.57, .476, .11, .18], crop: [.52, .38, .21, .36] },
  storage: { point: [.753, .55], region: [.688, .47, .125, .16], crop: [.66, .4, .18, .3] },
};

export function imageFrame(width, height, imageWidth, imageHeight, crop) {
  const [x, y, w, h] = crop;
  const scale = Math.min(width / (imageWidth * w), height / (imageHeight * h));
  const renderedWidth = imageWidth * scale, renderedHeight = imageHeight * scale;
  return {
    width: renderedWidth, height: renderedHeight,
    left: clampOffset(width / 2 - (x + w / 2) * renderedWidth, width, renderedWidth),
    top: clampOffset(height / 2 - (y + h / 2) * renderedHeight, height, renderedHeight),
  };
}
export function clampOffset(offset, viewport, size) {
  return size <= viewport ? (viewport - size) / 2 : Math.min(0, Math.max(viewport - size, offset));
}
