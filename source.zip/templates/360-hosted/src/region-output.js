import { defaultRegionQuiz,validateRegionQuiz,answerWalls,wallHeading } from "./region-config.js";
import { newRegionRun,startQuestion,lockRegionAnswer,tickRegion,pauseRegion,resumeRegion,nextRegion } from "./region-runtime.js";
import { createOutputLink,STATIC_HOST } from "./output-link.js";
import { roomPanel,roomLayoutFromParams } from "./room-layout.js";
import { sourceToPanel,desktopToSource } from "./projection.js";
import { createRegionRenderer } from "./region-renderer.js";
import { paintRegionUI } from "./region-ui.js";

const params=new URLSearchParams(location.search),desktop=params.get("desktop")==="1",layout=roomLayoutFromParams(params);
const angle=Number(params.get("roomYaw")||0),rotation=(Number.isFinite(angle)?Math.max(-180,Math.min(180,angle)):0)*Math.PI/180;
const canvas=document.getElementById("lesson"),accessible=document.getElementById("accessible"),renderer=createRegionRenderer(canvas,{desktop,rotation});
let config=defaultRegionQuiz(),run=newRegionRun(),pending=null,feedbackPage=0,yaw=rotation,pages=[],panels=[],calibration=false,notice="",ready=false,lastSignature="",drawScheduled=false;
function requestDraw(){if(drawScheduled)return;drawScheduled=true;setTimeout(()=>{drawScheduled=false;draw();},0);}
function load(value){config=value;run=newRegionRun();feedbackPage=0;pending=null;requestDraw();}
function receive(value){const valid=validateRegionQuiz(value);if(!valid||valid.revision===config.revision)return;if(run.phase==="intro")load(valid);else{pending=valid;notice="New publication available · pause to restart with it";requestDraw();}}
const link=createOutputLink({role:"viewer",defaultRoom:"region-quiz",onLesson:receive});
async function initialise(){try{const valid=validateRegionQuiz(await link.lesson());if(valid)load(valid);else throw Error("Wrong activity type");}catch{if(STATIC_HOST&&location.hash){const error=document.createElement("p");error.textContent="This region activity link is invalid. Ask the tutor for a new play link.";document.body.replaceChildren(error);return;}notice="Host unavailable · bundled sample quiz";}ready=true;requestDraw();}
initialise();
function download(){const text=[config.title,`Revision: ${config.revision}`,"Tutor group reflection, not tracked individual scores or certification.",...config.questions.map((q,i)=>`${i+1}. ${q.q}\nAnswer: ${q.options[q.correct]}\n${q.why}\nGroup: ${run.ratings[i]||"not discussed"}`)].join("\r\n\r\n");const url=URL.createObjectURL(new Blob([text],{type:"text/plain"})),a=document.createElement("a");a.href=url;a.download="region-quiz-discussion.txt";a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);}
function act(key){
  if(!ready)return;const now=Date.now();
  if(key==="start"&&run.phase==="intro"){startQuestion(run,config,now);feedbackPage=0;}
  if(key==="lock")lockRegionAnswer(run,now);
  if(key==="pause")pauseRegion(run,now);
  if(key==="resume")resumeRegion(run,now);
  if(key==="confident"||key==="revisit"){if(nextRegion(run,config,key,now))feedbackPage=0;}
  if(key==="feedback")feedbackPage=(feedbackPage+1)%(pages[0]?.pages||1);
  if(key==="restart"){run=newRegionRun();feedbackPage=0;}
  if(key==="update"&&pending&&["intro","pause","end"].includes(run.phase)){load(pending);notice="Published update loaded. Start when ready.";}
  if(key==="calibrate"&&run.phase==="intro")calibration=!calibration;
  if(key==="report"&&run.phase==="end")download();
  requestDraw();
}
function source(event){const r=canvas.getBoundingClientRect(),x=(event.clientX-r.left)/r.width,y=(event.clientY-r.top)/r.height;return desktop?desktopToSource(x,y,yaw,r.width/r.height):[x,y];}
function hit(point){for(let i=0;i<panels.length;i++){const uv=sourceToPanel(...point,panels[i]);if(!uv)continue;const x=uv[0]*1100,y=uv[1]*1050;const action=pages[i].actions.find(a=>x>=a.x&&x<=a.x+a.w&&y>=a.y&&y<=a.y+a.h);if(action)return action.key;}return null;}
let pointer=null,suppress=0;
canvas.addEventListener("pointerdown",e=>{if(e.button===0)pointer={x:e.clientX,y:e.clientY,last:e.clientX,moved:false};});
canvas.addEventListener("pointermove",e=>{if(pointer){if(Math.hypot(e.clientX-pointer.x,e.clientY-pointer.y)>6)pointer.moved=true;if(desktop&&pointer.moved){yaw-=(e.clientX-pointer.last)*.004;requestDraw();}pointer.last=e.clientX;}canvas.style.cursor=hit(source(e))?"pointer":desktop?"grab":"crosshair";});
function click(e){if(e.button!==0||performance.now()<suppress)return;suppress=performance.now()+250;const key=hit(source(e));if(key)act(key);}
canvas.addEventListener("pointerup",e=>{const p=pointer;pointer=null;if(p?.moved){suppress=performance.now()+350;return;}click(e);});
canvas.addEventListener("pointercancel",()=>{pointer=null;suppress=performance.now()+350;});canvas.addEventListener("click",click);
window.addEventListener("keydown",e=>{if(e.target.closest("button"))return;if(desktop&&["ArrowLeft","ArrowRight"].includes(e.key)){e.preventDefault();yaw+=e.key==="ArrowLeft"?Math.PI/2:-Math.PI/2;requestDraw();}if(e.key==="Escape")act(run.phase==="pause"?"resume":"pause");});
window.addEventListener("resize",()=>{renderer.resize();requestDraw();});window.addEventListener("pagehide",()=>link.close());
let previousSecond=-1;setInterval(()=>{const now=Date.now(),changed=tickRegion(run,now),sec=Math.ceil(Math.max(0,(run.deadline||now)-now)/1000);if(changed||sec!==previousSecond){previousSecond=sec;requestDraw();}},100);
function draw(){
  const now=Date.now();pages=Array.from({length:4},(_,wall)=>paintRegionUI({config,run,wall,now,feedbackPage,pending:!!pending,notice,calibration}));
  panels=pages.map((p,i)=>roomPanel(1100,1050,{lon:wallHeading(i,rotation),layout}));
  const q=config.questions[Math.min(run.index,config.questions.length-1)],winner=run.phase==="reveal"?answerWalls(q.options.length)[q.correct]:-1;
  renderer.update(pages,panels,winner);renderer.draw(yaw);
  const signature=run.phase+run.index+feedbackPage+calibration+!!pending+ready;
  if(signature!==lastSignature){const focus=document.activeElement?.dataset.actionKey;accessible.replaceChildren();const p=document.createElement("p");p.textContent=`${config.title}. ${run.phase}. ${q.q}${winner>=0?` Answer: ${q.options[q.correct]}. ${q.why}`:""}`;accessible.append(p);
    for(const a of pages[0].actions){const b=document.createElement("button");b.textContent=a.label;b.dataset.actionKey=a.key;b.disabled=!ready;b.onclick=()=>act(a.key);accessible.append(b);}accessible.querySelector(`[data-action-key="${focus||"none"}"]`)?.focus();lastSignature=signature;}
  canvas.dataset.phase=run.phase;canvas.dataset.index=String(run.index);canvas.dataset.panels=JSON.stringify(panels);
}
requestDraw();
