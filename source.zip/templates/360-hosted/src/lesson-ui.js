import { formatTime, riskLabels } from "./hazards.js";
import { wrapMeasuredText,paginateFeedback } from "./lesson-typography.js";

// All lesson controls are painted onto one world-facing panel texture. The
// renderer projects this texture into the 2:1 source; these aren't flat DOM UI.
export function paintLessonUI({config,run,image,step=0,review=null,page=0,textPage=0,hover=null,notice="",pending=false,saved=false,storageWarning=false,ready=true}) {
  const hunt=run.phase==="hunt"&&!review, canvas=document.createElement("canvas");
  canvas.width=1100;canvas.height=hunt?220:1050;
  const c=canvas.getContext("2d"), actions=[];
  if(!c.roundRect)c.roundRect=function(x,y,w,h){this.rect(x,y,w,h);};
  c.fillStyle=hunt?"rgba(16,43,34,.98)":"#133026";
  c.beginPath();c.roundRect(1,1,1098,canvas.height-2,22);c.fill();
  c.strokeStyle="#7f9471";c.lineWidth=2;c.stroke();
  c.fillStyle="#e9b966";c.fillRect(35,0,1030,5);
  const text=(str,x,y,size=29,color="#faf9ef",weight=600)=>{c.font=`${weight} ${size}px Arial,sans-serif`;c.fillStyle=color;c.fillText(str,x,y);};
  function lines(str,width,size=29,weight=600){c.font=`${weight} ${size}px Arial,sans-serif`;return wrapMeasuredText(str,width,value=>c.measureText(value).width);}
  function paragraph(str,x,y,width=1000,size=29,color="#edf2e2",lineHeight=size*1.35,weight=600){for(const line of lines(str,width,size,weight)){text(line,x,y,size,color,weight);y+=lineHeight;}return y;}
  function button(key,label,x,y,w,h=68,{active=false,disabled=false,small=false,fontSize=null}={}){
    c.fillStyle=disabled?"#344b3e":active?"#e6bc70":hover===key?"#567356":"#2f5540";
    c.beginPath();c.roundRect(x,y,w,h,10);c.fill();c.strokeStyle=active?"#f2d59d":"#849a70";c.lineWidth=active?3:1;c.stroke();
    let size=fontSize||(small?26:29),rows=lines(label,w-38,size,700);
    while(size>20&&rows.length*size*1.25>h-14){size--;rows=lines(label,w-38,size,700);}
    const lh=size*1.25;
    let ty=y+(h-rows.length*lh)/2+size;
    for(const row of rows){text(row,x+19,ty,size,disabled?"#b4c0ac":active?"#10271c":"#fffbed",700);ty+=lh;}
    if(!disabled)actions.push({key,label,x,y,w,h});
  }
  function heading(kicker,title){text(kicker.toUpperCase(),50,61,24,"#f0ce8c",700);let size=54;while(size>32&&lines(title,1000,size,700).length>2)size--;return paragraph(title,50,126,1000,size,"#fffbed",size*1.15,700)+12;}
  function footer(){const label=`${config.imageCredit.toUpperCase()} · DISCUSS WITH YOUR TUTOR · NOT CERTIFICATION`;let size=17;while(size>13&&lines(label,1000,size).length>1)size--;text(label,50,1022,size,"#dce6cf");if(storageWarning)text("Progress cannot be saved here. Keep this lesson open.",50,980,23,"#ffe0a0");}
  const team=config.teams===1?"Site team":`Team ${run.answers.length%2===0?"Amber":"Blue"}`;
  const points=run.answers.reduce((s,a)=>s+a.points,0);
  let description="",feedbackPageCount=1;
  if(hunt){
    text(`${run.answers.length} / ${config.hazards.length} reviewed  ·  ${points} points  ·  ${team}`,30,48,30,"#fffbed",700);
    const messages=lines(notice||"Select a hazard. Answer its question here in the room.",1040,26);
    messages.slice(0,2).forEach((line,i)=>text(line+(i===1&&messages.length>2?"…":""),30,87+i*30,26,"#eef3e6"));
    text(config.duration?`${formatTime(config.duration-run.elapsed)} left`:formatTime(run.elapsed),30,177,29,"#f5d38e",700);
    button("hints",run.hints?"Hints on":"Hints off",230,142,190,54,{active:run.hints,small:true});
    button("pause","Pause",435,142,165,54,{small:true});button("finish","Debrief",615,142,180,54,{small:true});
    if(pending)button("update","Load update",810,142,260,54,{small:true});
    description=notice||"Find hazards in the scene. Use lesson controls on the front wall.";
  } else if(run.phase==="intro"){
    let y=heading("SITE SURVEY / CONSTRUCTION",config.title);
    let descriptionSize=30;while(descriptionSize>20&&lines(config.description,1000,descriptionSize).length*descriptionSize*1.3>150)descriptionSize--;
    y=paragraph(config.description,50,y+15,1000,descriptionSize,"#edf2e2",descriptionSize*1.3)+20;
    for(const [number,title,body] of [["01","Look for unsafe situations","Select a hazard with the mouse, pointer or room touch."],["02","Decide together","Risk, choices and feedback appear inside this lesson."],["03","Learn from each other","Pause whenever you need to discuss. Then inspect the next hazard."]]){
      text(number,50,y+15,35,"#f4cc83",700);text(title,118,y+12,34,"#fffbed",700);paragraph(body,118,y+48,920,26,"#edf2e2",31);y+=112;
    }
    text(`${config.teams===2?"Two teams · alternating turns":"One collaborative group"}  /  ${config.duration?formatTime(config.duration)+" challenge":"Untimed inspection"}`,50,740,29,"#f4d28e");
    button("start",!ready?"Loading the lesson image…":saved?"Resume inspection →":"Start inspection →",50,795,1000,85,{active:true,disabled:!ready});
    if(saved)button("new","Start again",50,900,480,60,{small:true});
    if(pending)button("update","Use published update",550,900,500,60,{small:true});
    if(notice)paragraph(notice,50,970,1000,21,"#ffe0a0",25);
    footer();description=`${config.title}. ${config.description}. Start the lesson here; the editor is not required.`;
  } else if(run.phase==="pause"){
    let y=heading("TOOLS DOWN","Time to talk.");
    y=paragraph("The lesson clock is paused. Discuss what you noticed and which controls would protect everyone. Continue when the group is ready.",50,y+35,1000,36);
    button("resume","Resume lesson →",50,y+70,1000,90,{active:true});button("finish","Finish and debrief",50,y+190,480,72);
    if(pending)button("update","Restart with update",550,y+190,500,72);
    footer();description="Lesson paused. Resume or finish and debrief.";
  } else if(run.phase==="results"&&!review){
    let y=heading("INSPECTION COMPLETE","What will you do differently?");
    text(`${points} / ${config.hazards.length*100} points  ·  ${run.answers.length} / ${config.hazards.length} reviewed`,50,y+20,35,"#f4d28e",700);
    text(`${run.answers.filter(a=>a.actionCorrect).length} safe first responses  ·  ${formatTime(run.elapsed)}`,50,y+66,30);y+=105;
    const start=page*6;
    for(const h of config.hazards.slice(start,start+6)){
      const a=run.answers.find(a=>a.id===h.id);button(`review:${h.id}`,`${a?.actionCorrect?"✓":a?"!":"○"}  ${h.title}  /  ${a?`${a.points} points`:"Not reviewed"}`,50,y,1000,69,{small:true});y+=81;
    }
    if(config.hazards.length>6){button("prev-page","← Previous",50,850,310,60,{small:true,disabled:page===0});button("next-page","Next →",380,850,310,60,{small:true,disabled:start+6>=config.hazards.length});}
    button(pending?"update":"new",pending?"Start published update":"New inspection",50,934,480,60);button("report","Download report",550,934,500,60);footer();
    description=`Debrief. ${points} learning points. Review any hazard, including those missed.`;
  } else {
    const h=config.hazards.find(h=>h.id===(review||run.selected));
    if(!h)return {canvas,actions,description:""};
    const a=run.answers.find(a=>a.id===h.id);
    let y=heading(review?"LEARNING DEBRIEF":run.phase==="feedback"?"RECOGNISE · RESPOND · REFLECT":`${team} / ${h.zone}`,h.title);
    if(run.phase==="feedback"||review){
      text(a?`${a.actionCorrect?"✓ A safer decision":"! Revisit this response"}  /  ${a.points} points`:"Not reviewed during inspection",50,y+10,32,"#f4d28e",700);y+=60;
      const pages=paginateFeedback([{label:"WHY IT MATTERS",text:h.consequence},{label:"THE SAFER APPROACH",text:h.explanation},{text:`Risk guide: ${riskLabels[h.risk]}`},{label:"DISCUSS TOGETHER",text:h.discussion}],value=>lines(value,1000,28),Math.max(200,810-y));
      feedbackPageCount=pages.length;const index=Math.min(textPage,pages.length-1);
      for(const row of pages[index])text(row.text,50,y+row.y+(row.kind==="heading"?24:28),row.kind==="heading"?24:28,row.kind==="heading"?"#f4d28e":"#f1f5e9",row.kind==="heading"?700:600);
      if(pages.length>1){button("feedback-prev","← Previous",50,824,240,42,{small:true,disabled:index===0});text(`${index+1} / ${pages.length}`,325,855,25);button("feedback-next","More feedback →",550,824,500,42,{small:true,disabled:index===pages.length-1});}
      button(review?"back-results":"continue",review?"← Back to debrief":index<pages.length-1?"Read the next feedback page":"Continue inspection →",50,876,1000,73,{active:true,disabled:!review&&index<pages.length-1});
      if(!review)button("pause","Pause for discussion",50,960,1000,43,{small:true});
      footer();description=`${h.title}. Feedback ${index+1} of ${pages.length}. ${pages[index].map(row=>row.text).join(" ")}`;
    } else {
      // Evidence crop is included in the projected question panel itself.
      const evidence=step===0&&lines(h.prompt,715,31).length<=6;
      if(image?.naturalWidth&&evidence){const [x,py,w,height]=h.region;const sw=w*image.naturalWidth,sh=height*image.naturalHeight,scale=Math.min(250/sw,200/sh);c.drawImage(image,x*image.naturalWidth,py*image.naturalHeight,sw,sh,800,y,sw*scale,sh*scale);}
      const prompt=step===0?h.prompt:"Choose the strongest safe response. Go back if you need to review the evidence.",width=evidence?715:1000;
      let promptSize=step===0?31:29;while(promptSize>25&&lines(prompt,width,promptSize).length*promptSize*1.35>240)promptSize--;
      const end=paragraph(prompt,50,y+15,width,promptSize);
      y=evidence?Math.max(end+30,y+215):end+30;
      text(step===0?"1 / 2   Assess the potential severity":"2 / 2   Choose the strongest response",50,y,29,"#f4d28e",700);y+=48;
      if(step===0){
        for(const [risk,label] of Object.entries(riskLabels)){button(`risk:${risk}`,label,50,y,1000,76,{active:run.risk===risk});y+=92;}
        paragraph("Potential severity only — not a full site risk assessment.",50,y+20,1000,26);
        button("back-site","← Back to site",50,890,480,70);button("response","Choose response →",550,890,500,70,{active:true,disabled:!run.risk});
      }else{
        let optionSize=26;
        const optionHeights=size=>h.options.map((option,index)=>Math.max(88,lines(`${String.fromCharCode(65+index)}  ${option}`,962,size,700).length*size*1.3+30));
        while(optionSize>22&&optionHeights(optionSize).reduce((s,h)=>s+h,26)>860-y)optionSize--;
        const heights=optionHeights(optionSize);
        for(const [index,option] of h.options.entries()){
          const height=heights[index];
          button(`option:${index}`,`${String.fromCharCode(65+index)}  ${option}`,50,y,1000,height,{active:run.option===index,small:true,fontSize:optionSize});y+=height+13;
        }
        button("risk-step","← Risk assessment",50,890,480,70);button("commit","Commit decision →",550,890,500,70,{active:true,disabled:run.option===null});
      }
      button("pause","Pause for discussion",50,973,1000,35,{small:true});footer();
      description=`${h.title}. ${h.prompt} ${step===0?"Choose risk severity.":h.options.join(" ")}`;
    }
  }
  return { canvas, actions, description,feedbackPageCount };
}
