import test from "node:test";
import assert from "node:assert/strict";
import { createServer } from "node:http";
import { createSyncHub } from "./sync-server.mjs";
import { initialOutputState } from "../src/output-protocol.js";
import { defaultLesson } from "../src/lesson-config.js";
import { defaultRegionQuiz } from "../src/region-config.js";

async function fixture(t) {
  const hub=createSyncHub();
  const server=createServer((req,res)=>hub.handle(req,res).catch(error=>{res.statusCode=500;res.end(error.message);}));
  await new Promise(resolve=>server.listen(0,"127.0.0.1",resolve));
  const base=`http://127.0.0.1:${server.address().port}`;
  const controllers=[];
  t.after(async()=>{for(const c of controllers)c.abort();hub.close();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));});
  async function connect(role,id,room="construction") {
    const abort=new AbortController();controllers.push(abort);
    const query=new URLSearchParams({role,client:id,room});
    const response=await fetch(`${base}/api/events?${query}`,{signal:abort.signal});
    assert.equal(response.status,200);
    const reader=response.body.getReader();let buffer="";const decoder=new TextDecoder();
    async function next(type) {
      for(;;){
        const split=buffer.indexOf("\n\n");
        if(split>=0){const block=buffer.slice(0,split);buffer=buffer.slice(split+2);const line=block.split("\n").find(l=>l.startsWith("data: "));if(!line)continue;const msg=JSON.parse(line.slice(6));if(msg.type===type)return msg.data;continue;}
        const result=await reader.read();if(result.done)throw new Error("Stream closed before "+type);buffer+=decoder.decode(result.value,{stream:true});
      }
    }
    const {token}=await next("hello");
    return {next,abort,post:(path,value)=>fetch(`${base}/api/${path}?${query}`,{method:"POST",headers:{"Content-Type":"application/json","X-Client-Token":token},body:JSON.stringify(value)})};
  }
  return {base,connect};
}
test("separate HTTP clients share selections and late viewers receive the full state",{timeout:10000},async t=>{
  const f=await fixture(t),control=await f.connect("control","tutor"),output=await f.connect("viewer","ice");
  assert.equal((await control.post("state",{...initialOutputState(),interactive:true})).status,200);
  const late=await f.connect("viewer","late");
  assert.equal((await late.next("state")).interactive,true);
  assert.equal((await output.post("input",{id:"electric"})).status,200);
  assert.deepEqual(await control.next("inspect"),{id:"electric"});
  const status=await (await fetch(`${f.base}/api/state`)).json();
  assert.equal(status.state.selected,"electric");assert.equal(status.state.interactive,false);
  assert.equal((await output.post("input",{id:"edge"})).status,409);
});
test("region publications use the existing authenticated stream, reject stale keys and cannot overwrite hazards",{timeout:10000},async t=>{
  const f=await fixture(t),editor=await f.connect("control","region-editor","region-test"),viewer=await f.connect("viewer","region-viewer","region-test");
  assert.equal((await editor.next("lesson")).kind,"region-quiz");
  const config=defaultRegionQuiz();config.seconds=5;config.title="Venue region lesson";
  const request={lesson:config,expectedRevision:config.revision};
  const response=await editor.post("lesson",request);assert.equal(response.status,200);const published=(await response.json()).lesson;
  // Drain initial lesson, then the publication event.
  assert.equal((await viewer.next("lesson")).revision,"region-1");assert.equal((await viewer.next("lesson")).revision,published.revision);
  assert.equal((await editor.post("lesson",request)).status,409);
  assert.equal((await viewer.post("lesson",{lesson:config,expectedRevision:published.revision})).status,403);
  assert.equal((await editor.post("lesson",{lesson:defaultLesson(),expectedRevision:published.revision})).status,400);
  const hazards=(await(await fetch(`${f.base}/api/lesson`)).json()).lesson;assert.equal(hazards.title,"Construction Hazard Hunt");
});
test("output cannot modify tutor state; paused, reviewed and invalid selections are rejected",{timeout:10000},async t=>{
  const f=await fixture(t),control=await f.connect("control","tutor"),output=await f.connect("viewer","ice");
  assert.equal((await output.post("state",initialOutputState())).status,409);
  await control.post("state",{...initialOutputState(),interactive:true,reviewed:["edge"]});
  assert.equal((await output.post("input",{id:"edge"})).status,409);
  assert.equal((await output.post("input",{id:"unknown"})).status,400);
  await control.post("state",{...initialOutputState(),interactive:true,paused:true});
  assert.equal((await output.post("input",{id:"dust"})).status,409);
});
test("rooms are isolated and a second tutor cannot overwrite the active tutor",{timeout:10000},async t=>{
  const f=await fixture(t),control=await f.connect("control","tutor"),other=await f.connect("control","other");
  assert.equal((await other.post("state",{...initialOutputState(),interactive:true})).status,409);
  await control.post("state",{...initialOutputState(),interactive:true});
  const room=await(await fetch(`${f.base}/api/state?room=different`)).json();
  assert.equal(room.state.interactive,false);assert.equal(room.outputs,0);
});
test("connection tokens, origin and payload validation protect the local endpoint",{timeout:10000},async t=>{
  const f=await fixture(t),control=await f.connect("control","tutor");
  const response=await fetch(`${f.base}/api/state?client=tutor`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(initialOutputState())});
  assert.equal(response.status,403);
  assert.equal((await fetch(`${f.base}/api/state`,{headers:{Origin:"https://untrusted.example"}})).status,403);
  assert.equal((await control.post("state",{...initialOutputState(),selected:"bad"})).status,400);
});
test("disconnecting the tutor locks room input until control returns",{timeout:10000},async t=>{
  const f=await fixture(t),control=await f.connect("control","tutor"),output=await f.connect("viewer","ice");
  await control.post("state",{...initialOutputState(),interactive:true});
  control.abort.abort();
  for(;;){const p=await output.next("presence");if(p.controller===null)break;}
  const status=await(await fetch(`${f.base}/api/state`)).json();
  assert.equal(status.state.interactive,false);
  assert.equal((await output.post("input",{id:"edge"})).status,409);
});
test("raw mouse-coordinate taps report misses and locks to the tutor, then select the correct hazard",{timeout:10000},async t=>{
  const f=await fixture(t),control=await f.connect("control","tutor"),output=await f.connect("viewer","ice");
  assert.equal((await output.post("tap",{x:.865,y:.811})).status,200);
  assert.equal((await control.next("tap")).reason,"not-started");
  await control.post("state",{...initialOutputState(),interactive:true});
  await output.post("tap",{x:.5,y:.05});
  assert.equal((await control.next("tap")).reason,"no-hazard");
  await output.post("tap",{x:.865,y:.811});
  assert.deepEqual(await control.next("tap"),{x:.865,y:.811,id:"electric",reason:"selected"});
  assert.deepEqual(await control.next("inspect"),{id:"electric"});
  await output.post("tap",{x:.318,y:.365});
  assert.equal((await control.next("tap")).reason,"question-open");
  assert.equal((await output.post("tap",{x:NaN,y:.5})).status,400);
  assert.equal((await control.post("tap",{x:.5,y:.5})).status,400);
});
test("an editor publishes a validated activity and a standalone lesson receives it without a tutor",{timeout:10000},async t=>{
  const f=await fixture(t),editor=await f.connect("control","editor"),viewer=await f.connect("viewer","lesson");
  const initial=await(await fetch(`${f.base}/api/lesson`)).json();assert.equal(initial.lesson.title,defaultLesson().title);
  const config=defaultLesson();config.title="Published construction activity";
  const response=await editor.post("lesson",{lesson:config,expectedRevision:initial.lesson.revision});assert.equal(response.status,200);
  const result=await response.json();assert.notEqual(result.lesson.revision,initial.lesson.revision);
  let received;do{received=await viewer.next("lesson");}while(received.revision!==result.lesson.revision);
  assert.equal(received.title,config.title);
  editor.abort.abort();
  const saved=await(await fetch(`${f.base}/api/lesson`)).json();assert.equal(saved.lesson.title,config.title);
  assert.equal((await viewer.post("lesson",{lesson:config,expectedRevision:result.lesson.revision})).status,403);
});
test("publishing conflicts cannot silently overwrite a newer activity",{timeout:10000},async t=>{
  const f=await fixture(t),editor=await f.connect("control","editor");const config=defaultLesson();
  assert.equal((await editor.post("lesson",{lesson:config,expectedRevision:config.revision})).status,200);
  assert.equal((await editor.post("lesson",{lesson:config,expectedRevision:config.revision})).status,409);
});
