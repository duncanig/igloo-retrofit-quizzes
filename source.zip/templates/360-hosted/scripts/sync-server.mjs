import { initialOutputState, normaliseOutputState, HAZARD_IDS, findPhotoHazard } from "../src/output-protocol.js";
import { photoDetails } from "../src/photo-data.js";
import { randomUUID } from "node:crypto";
import { defaultActivity, validateActivity } from "../src/activity-config.js";
import { memoryLessonStore, imageType } from "./lesson-store.mjs";

// Shared by the Vite dev/preview plugin and the built-file host. HTTP/SSE works
// across separate browser processes (unlike BroadcastChannel/localStorage).
export function createSyncHub({store=memoryLessonStore()}={}) {
  const rooms = new Map();
  const lessons=new Map(),locks=new Set();
  async function published(name){if(!lessons.has(name))lessons.set(name,(await store.load(name))||defaultActivity(name));return lessons.get(name);}
  const roomFor = name => {
    if (!rooms.has(name)) {
      // Bound idle room accumulation without expiring an active teaching session.
      if (rooms.size >= 32) {
        const idle = [...rooms].find(([, r]) => r.clients.size === 0);
        if (!idle) return null;
        rooms.delete(idle[0]);lessons.delete(idle[0]);
      }
      rooms.set(name, { state: initialOutputState(), clients: new Map(), owner: null });
    }
    return rooms.get(name);
  };
  function send(client, type, data) {
    if (!client.response.destroyed) client.response.write(`data: ${JSON.stringify({ type, data })}\n\n`);
  }
  function broadcast(room, type, data, role) {
    for (const client of room.clients.values()) if (!role || client.role === role) send(client, type, data);
  }
  function presence(room) {
    const outputs = [...room.clients.values()].filter(c => c.role === "viewer");
    return { controller: room.owner, outputs: outputs.length, ready: outputs.filter(c => c.ready).length,
      aspectWarnings: outputs.filter(c => c.ready && Math.abs(c.aspect - 2) > .02).length };
  }
  const json = (res, code, data) => {
    res.writeHead(code, { "Content-Type": "application/json", "Cache-Control": "no-store" });res.end(JSON.stringify(data));
  };
  async function body(req,limit=16384) {
    let bytes = 0, chunks = [];
    for await (const chunk of req) {
      bytes += chunk.length;
      if (bytes > limit) throw new Error("Request too large");
      chunks.push(chunk);
    }
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  }
  async function handle(req, res, next = () => json(res, 404, { error: "Not found" })) {
    const url = new URL(req.url, "http://localhost");
    if (!url.pathname.startsWith("/api/")) return next();
    let sameOrigin=true;
    try { if(req.headers.origin)sameOrigin=new URL(req.headers.origin).host===req.headers.host; } catch { sameOrigin=false; }
    if (!sameOrigin || req.headers["sec-fetch-site"] === "cross-site") return json(res, 403, { error: "Same-origin requests only" });
    const name = url.searchParams.get("room") || "construction";
    if (!/^[a-zA-Z0-9_-]{1,40}$/.test(name)) return json(res, 400, { error: "Invalid room" });
    const room = roomFor(name);
    if (!room) return json(res, 503, { error: "Too many active rooms" });
    const id = url.searchParams.get("client");
    if(url.pathname==="/api/lesson"&&req.method==="GET")return json(res,200,{lesson:await published(name)});
    if(url.pathname.startsWith("/api/images/")&&req.method==="GET"){
      const filename=url.pathname.slice("/api/images/".length);
      if(!/^[a-f0-9-]+\.(png|jpg|webp)$/.test(filename))return json(res,404,{error:"Image not found"});
      const bytes=await store.image(filename);if(!bytes)return json(res,404,{error:"Image not found"});
      const type=imageType(bytes);if(!type)return json(res,404,{error:"Image not found"});
      res.writeHead(200,{"Content-Type":`image/${type==="jpg"?"jpeg":type}`,"Cache-Control":"public,max-age=31536000,immutable","X-Content-Type-Options":"nosniff"});res.end(bytes);return;
    }
    if (url.pathname === "/api/events" && req.method === "GET") {
      const role = url.searchParams.get("role");
      if (!["control", "viewer"].includes(role) || !/^[a-zA-Z0-9_-]{1,80}$/.test(id || "")) return json(res, 400, { error: "Invalid client" });
      if (room.clients.size >= 20) return json(res, 503, { error: "Too many clients" });
      // Reconnects replace an older stream with the same browser instance id.
      room.clients.get(id)?.response.end();
      res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-cache, no-transform", "Connection": "keep-alive", "X-Accel-Buffering": "no" });
      res.write("retry: 2000\n\n");
      const client = { role, response: res, ready: false, aspect: 0, token: randomUUID() };
      room.clients.set(id, client);
      if (role === "control" && !room.owner) room.owner = id;
      send(client, "hello", { token: client.token });
      send(client, "state", room.state);
      published(name).then(value=>send(client,"lesson",value)).catch(()=>{});
      broadcast(room, "presence", presence(room));
      const keepalive = setInterval(() => { if (!res.destroyed) res.write(": heartbeat\n\n"); }, 15000);
      res.on("close", () => {
        clearInterval(keepalive);
        if (room.clients.get(id) !== client) return;
        room.clients.delete(id);
        if (room.owner === id) {
          room.owner = [...room.clients].find(([, c]) => c.role === "control")?.[0] || null;
          // Loss of the tutor must never leave unattended interactive decisions.
          room.state = { ...room.state, interactive: false };
          broadcast(room, "state", room.state);
        }
        broadcast(room, "presence", presence(room));
      });
      return;
    }
    if (url.pathname === "/api/state" && req.method === "GET") return json(res, 200, { state: room.state, ...presence(room) });
    if (req.method !== "POST" || !["/api/state", "/api/input", "/api/ready", "/api/tap", "/api/lesson", "/api/upload"].includes(url.pathname)) return json(res, 404, { error: "Not found" });
    if (!req.headers["content-type"]?.startsWith("application/json")) return json(res, 415, { error: "JSON required" });
    const client = room.clients.get(id);
    if (!client || req.headers["x-client-token"] !== client.token) return json(res, 403, { error: "Connect the event stream first" });
    let value;
    try { value = await body(req,url.pathname==="/api/upload"?17*1024*1024:128*1024); } catch { return json(res, 400, { error: "Invalid or oversized JSON" }); }
    if(url.pathname==="/api/upload"){
      if(client.role!=="control"||typeof value.base64!=="string"||value.base64.length>16*1024*1024)return json(res,400,{error:"Invalid image upload"});
      const bytes=Buffer.from(value.base64,"base64"),type=imageType(bytes);
      if(!type||bytes.length>12*1024*1024)return json(res,400,{error:"Use PNG, JPEG or WebP, up to 12 MB"});
      try{const filename=await store.saveImage(bytes,type);return json(res,200,{image:`/api/images/${filename}`});}
      catch{return json(res,500,{error:"The host could not save the image. Check local storage permissions."});}
    }
    if(url.pathname==="/api/lesson"){
      if(client.role!=="control")return json(res,403,{error:"Only an editor can publish"});
      if(locks.has(name))return json(res,409,{error:"Another publication is in progress. Reload the published version."});
      locks.add(name);
      try{
        const previous=await published(name);
        if(value.expectedRevision!==previous.revision)return json(res,409,{error:"The published version changed. Reload it before publishing."});
        const clean=validateActivity(value.lesson);if(!clean)return json(res,400,{error:"Invalid lesson. Check text limits, answers and hotspot positions."});
        if((clean.kind||"hazard")!==(previous.kind||"hazard"))return json(res,400,{error:"Use a separate room for each quiz type."});
        clean.revision=`${Date.now()}-${randomUUID().slice(0,8)}`;
        try{await store.save(name,clean);}catch{return json(res,500,{error:"The host could not save this activity. Your draft is still unpublished."});}
        lessons.set(name,clean);broadcast(room,"lesson",clean);return json(res,200,{lesson:clean});
      }finally{locks.delete(name);}
    }
    if (url.pathname === "/api/state") {
      if (client.role !== "control" || room.owner !== id) return json(res, 409, { error: "Another tutor page controls this room" });
      const state = normaliseOutputState(value);
      if (!state) return json(res, 400, { error: "Invalid state" });
      room.state = state;broadcast(room, "state", state);return json(res, 200, { ok: true });
    }
    if (url.pathname === "/api/ready") {
      if (client.role !== "viewer" || typeof value.ready !== "boolean" || !Number.isFinite(value.aspect) || value.aspect <= 0 || value.aspect > 20) return json(res, 400, { error: "Invalid output status" });
      client.ready = value.ready;client.aspect = value.aspect;broadcast(room, "presence", presence(room));return json(res, 200, { ok: true });
    }
    if (url.pathname === "/api/tap") {
      if (client.role !== "viewer" || !Number.isFinite(value.x) || !Number.isFinite(value.y) || value.x<0 || value.x>1 || value.y<0 || value.y>1) return json(res,400,{error:"Invalid source coordinates"});
      const id=findPhotoHazard(value.x,value.y,photoDetails);
      const reason=!room.owner?"no-tutor":room.state.paused?"paused":room.state.selected?"question-open":!room.state.interactive?"not-started":!id?"no-hazard":room.state.reviewed.includes(id)?"reviewed":"selected";
      broadcast(room,"tap",{x:value.x,y:value.y,id,reason},"control");
      if(reason!=="selected") return json(res,200,{ok:true,reason});
      value={id};
    }
    if (client.role !== "viewer" || !HAZARD_IDS.includes(value.id)) return json(res, 400, { error: "Invalid inspection" });
    if (!room.owner || !room.state.interactive || room.state.reviewed.includes(value.id)) return json(res, 409, { error: "Inspection is not accepting selections" });
    room.state = { ...room.state, interactive: false, selected: value.id };
    broadcast(room, "state", room.state);
    broadcast(room, "inspect", { id: value.id }, "control");
    return json(res, 200, { ok: true });
  }
  return { handle, close() { for (const room of rooms.values()) for (const c of room.clients.values()) c.response.end();rooms.clear(); } };
}
