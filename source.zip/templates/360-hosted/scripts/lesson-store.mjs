import { mkdir, readFile, writeFile, rename } from "node:fs/promises";
import { join } from "node:path";
import { randomUUID } from "node:crypto";
import { validateActivity } from "../src/activity-config.js";

export function memoryLessonStore() {
  const lessons=new Map(),images=new Map();
  return {async load(room){return lessons.get(room)||null;},async save(room,value){lessons.set(room,structuredClone(value));},
    async saveImage(bytes,extension){const name=`${randomUUID()}.${extension}`;images.set(name,bytes);return name;},async image(name){return images.get(name)||null;}};
}
export function fileLessonStore(root) {
  return {
    async load(room){try{return validateActivity(JSON.parse(await readFile(join(root,`${room}.json`),"utf8")));}catch{return null;}},
    async save(room,value){await mkdir(root,{recursive:true});const temporary=join(root,`${room}.${randomUUID()}.tmp`);await writeFile(temporary,JSON.stringify(value,null,2));await rename(temporary,join(root,`${room}.json`));},
    async saveImage(bytes,extension){await mkdir(join(root,"images"),{recursive:true});const name=`${randomUUID()}.${extension}`;await writeFile(join(root,"images",name),bytes);return name;},
    async image(name){try{return await readFile(join(root,"images",name));}catch{return null;}},
  };
}
export function imageType(bytes) {
  if(bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return "png";
  if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255)return "jpg";
  if(bytes.subarray(0,4).toString()==="RIFF"&&bytes.subarray(8,12).toString()==="WEBP")return "webp";
  return null;
}
