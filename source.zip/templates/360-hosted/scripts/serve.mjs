import { createServer } from "node:http";
import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import { resolve, extname, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { createSyncHub } from "./sync-server.mjs";
import { fileLessonStore } from "./lesson-store.mjs";

const root=fileURLToPath(new URL("../dist/",import.meta.url));
const host=process.env.HOST || "127.0.0.1", port=Number(process.env.PORT || 8787);
const types={".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css; charset=utf-8",".json":"application/json",".png":"image/png",".ttf":"font/ttf",".txt":"text/plain; charset=utf-8"};
try { await stat(resolve(root,"index.html")); } catch { console.error("Build first: npm run build");process.exit(1); }
const hub=createSyncHub({store:fileLessonStore(fileURLToPath(new URL("../.local-data/",import.meta.url)))});
const server=createServer(async(req,res)=>{
  try {
    const path=new URL(req.url,"http://localhost").pathname;
    if(path.startsWith("/api/")) return await hub.handle(req,res);
    if(!["GET","HEAD"].includes(req.method)){res.writeHead(405);res.end();return;}
    const relative=decodeURIComponent(path).replace(/^\/+/,"") || "index.html";
    const file=resolve(root,relative);
    if(!file.startsWith(root.endsWith(sep)?root:root+sep)){res.writeHead(403);res.end();return;}
    const info=await stat(file);
    if(!info.isFile())throw new Error("Not a file");
    res.writeHead(200,{"Content-Type":types[extname(file)]||"application/octet-stream","Content-Length":info.size,"Cache-Control":"no-cache","X-Content-Type-Options":"nosniff"});
    if(req.method==="HEAD")res.end();else createReadStream(file).on("error",()=>res.destroy()).pipe(res);
  } catch { if(!res.headersSent)res.writeHead(404);res.end("Not found"); }
});
server.listen(port,host,()=>console.log(`Editor: http://${host}:${port}/\nICE lesson: http://${host}:${port}/viewer.html\nDesktop test: http://${host}:${port}/viewer.html?desktop=1\nLocal/trusted-network host only; not an authenticated public service.`));
server.on("error",error=>{console.error(error.message);process.exitCode=1;});
for(const signal of ["SIGINT","SIGTERM"])process.on(signal,()=>{hub.close();server.close();});
