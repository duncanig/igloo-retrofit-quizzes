import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp,rm,mkdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileLessonStore,imageType } from "./lesson-store.mjs";
import { defaultLesson } from "../src/lesson-config.js";
import { defaultRegionQuiz } from "../src/region-config.js";

test("published lesson data survives creation of a new local host store",async t=>{
  const base=process.env.LOCALAPPDATA?join(process.env.LOCALAPPDATA,"Temp","opencode"):tmpdir();await mkdir(base,{recursive:true});
  const root=await mkdtemp(join(base,"hazard-lesson-test-"));t.after(()=>rm(root,{recursive:true,force:true}));
  const config=defaultLesson();config.title="Persisted activity";
  await fileLessonStore(root).save("test-room",config);
  assert.equal((await fileLessonStore(root).load("test-room")).title,"Persisted activity");
  config.title="Updated activity";await fileLessonStore(root).save("test-room",config);
  assert.equal((await fileLessonStore(root).load("test-room")).title,"Updated activity");
  assert.equal(await fileLessonStore(root).load("unknown"),null);
  const region=defaultRegionQuiz();await fileLessonStore(root).save("region-quiz",region);
  assert.deepEqual(await fileLessonStore(root).load("region-quiz"),region);
  assert.equal((await fileLessonStore(root).load("test-room")).title,"Updated activity");
});
test("image storage only recognises supported non-executable file signatures",()=>{
  assert.equal(imageType(Buffer.from("<svg onload=alert(1)>")),null);
  assert.equal(imageType(Buffer.from([137,80,78,71,13,10,26,10])),"png");
  assert.equal(imageType(Buffer.from([255,216,255,0])),"jpg");
});
