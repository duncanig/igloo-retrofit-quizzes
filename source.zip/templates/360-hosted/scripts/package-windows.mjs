import { mkdir,cp,copyFile,writeFile,stat } from "node:fs/promises";
import { resolve,join } from "node:path";
import { fileURLToPath } from "node:url";

// Snapshot a built host without touching the live data, drafts or source folder.
const root=fileURLToPath(new URL("../",import.meta.url)),destination=resolve(process.argv[2]||"");
if(!process.argv[2])throw Error("Usage: node scripts/package-windows.mjs <new-output-folder>");
if(process.platform!=="win32")throw Error("Build this portable Windows package using Windows Node.js.");
await stat(join(root,"dist","region.html"));await stat(join(root,"dist","sessions.html"));
const nodeLicense=join(root,"scripts","licenses",`node-${process.version}-LICENSE.txt`);
try{await stat(nodeLicense);}catch{throw Error(`Add the Node ${process.version} distribution LICENSE at ${nodeLicense} before packaging this runtime.`);}
await mkdir(destination); // Fail rather than overwrite an existing delivery.
for(const folder of ["dist","scripts","src"])await cp(join(root,folder),join(destination,folder),{recursive:true,filter:path=>!path.endsWith(".test.js")&&!path.endsWith(".test.mjs")});
try{await stat(join(root,".local-data"));await cp(join(root,".local-data"),join(destination,".local-data"),{recursive:true});}catch(error){if(error.code!=="ENOENT")throw error;}
await mkdir(join(destination,"runtime"));await copyFile(process.execPath,join(destination,"runtime","node.exe"));
await copyFile(nodeLicense,join(destination,"runtime","LICENSE.txt"));
await copyFile(join(root,"node_modules","three","LICENSE"),join(destination,"THREE-LICENSE.txt"));
await copyFile(join(root,"..","..","LICENSE"),join(destination,"LICENSE"));
await copyFile(join(root,"WINDOWS-QUICKSTART.md"),join(destination,"README.md"));
await writeFile(join(destination,"package.json"),JSON.stringify({private:true,type:"module"},null,2));
await writeFile(join(destination,"Start-Igloo.cmd"),`@echo off\r\ncd /d "%~dp0"\r\nset HOST=127.0.0.1\r\nset PORT=8787\r\necho Open http://127.0.0.1:8787/sessions.html after the host starts.\r\necho Keep this window open while teaching. Ctrl+C stops the host.\r\n"%~dp0runtime\\node.exe" scripts\\serve.mjs\r\npause\r\n`);
console.log(`Windows package: ${destination}\nIncludes portable Node ${process.version}, built pages and a snapshot of published activities/images. Browser-only drafts are not included.`);
