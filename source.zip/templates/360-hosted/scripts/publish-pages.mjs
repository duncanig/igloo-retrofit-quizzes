import { execFileSync } from "node:child_process";
import { readFile } from "node:fs/promises";
import { createHash } from "node:crypto";

// Uses `gh`'s OS-keyring authentication. Never reads, writes or prints a token.
// Deliberately scoped to this repository and the reviewed delivery allowlists.
const gh=process.env.GH_BIN||"gh",repo="duncanig/igloo-retrofit-quizzes";
const root=new URL("../web-release/",import.meta.url);
const hazard=process.argv.includes("--hazard");
const files=hazard?["viewer.html","HAZARD-INPUT.md","source.zip"]:["region.html","region-editor.html","index.html","sessions.html","README.md","REGION-RETROFIT.md","PAGES-REBUILD.md","source.zip"];
const publishing=process.argv.includes("--publish");
function api(endpoint,data,method){
  const args=["api",`repos/${repo}/${endpoint}`];
  if(data){args.push("--method",method||"POST","--input","-");}
  return JSON.parse(execFileSync(gh,args,{input:data?JSON.stringify(data):undefined,encoding:"utf8",maxBuffer:16*1024*1024}));
}
const reference=api("git/ref/heads/main"),parent=reference.object.sha;
const commit=api(`git/commits/${parent}`),tree=api(`git/trees/${commit.tree.sha}?recursive=1`);
if(tree.truncated)throw Error("Refusing to publish against a truncated repository tree");
const existing=new Map(tree.tree.map(entry=>[entry.path,entry]));
const changes=[];
for(const path of files){
  const bytes=await readFile(new URL(path,root));
  const sha=createHash("sha1").update(`blob ${bytes.length}\0`).update(bytes).digest("hex");
  if(existing.get(path)?.sha!==sha)changes.push({path,bytes,sha});
}
console.log(JSON.stringify({repository:repo,parent,mode:publishing?"publish":"dry-run",files:changes.map(({path,bytes})=>({path,bytes:bytes.length}))},null,2));
if(!publishing||!changes.length)process.exit(0);
const updates=[];
for(const change of changes){
  const blob=api("git/blobs",{content:change.bytes.toString("base64"),encoding:"base64"});
  if(blob.sha!==change.sha)throw Error(`Blob verification failed for ${change.path}`);
  updates.push({path:change.path,mode:"100644",type:"blob",sha:blob.sha});
}
const newTree=api("git/trees",{base_tree:commit.tree.sha,tree:updates});
const check=api(`git/trees/${newTree.sha}?recursive=1`);
const after=new Map(check.tree.map(entry=>[entry.path,entry]));
const protectedFiles=hazard?["region.html","region-editor.html","index.html","sessions.html","hazard-editor.html","images/construction-panorama.png"]:["viewer.html","hazard-editor.html","images/construction-panorama.png"];
for(const path of protectedFiles){
  if(!existing.has(path)||after.get(path)?.sha!==existing.get(path).sha)throw Error(`Refusing to change protected asset: ${path}`);
}
const result=api("git/commits",{message:hazard?"Harden hazard room input and add projected ICE input diagnostics":"Restore whole original region quiz; adapt only retrofit output dimensions",tree:newTree.sha,parents:[parent]});
if(api("git/ref/heads/main").object.sha!==parent)throw Error("Repository changed during preparation. Nothing pushed; review the new head before retrying.");
api("git/refs/heads/main",{sha:result.sha,force:false},"PATCH");
console.log(JSON.stringify({commit:result.sha,url:`https://github.com/${repo}/commit/${result.sha}`,[hazard?"regionUnchanged":"hazardUnchanged"]:true},null,2));
