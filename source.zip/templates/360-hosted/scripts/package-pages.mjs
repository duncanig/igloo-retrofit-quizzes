import { mkdir,readFile,writeFile,copyFile } from "node:fs/promises";
import { resolve,dirname,join } from "node:path";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";

// Postprocess the Pages-mode Vite build into independently uploadable HTML.
// No local publications, draft data, runtime executables or credentials copied.
const root=fileURLToPath(new URL("../",import.meta.url)),dist=join(root,"dist");
const output=resolve(process.argv[2]||join(root,"web-release"));await mkdir(output,{recursive:true});
for(const [input,name] of [["index.html","hazard-editor.html"],["viewer.html","viewer.html"],["region.html","region.html"],["region-editor.html","region-editor.html"],["sessions.html","index.html"],["sessions.html","sessions.html"]]){
  let html=await readFile(join(dist,input),"utf8");
  const scripts=[...html.matchAll(/<script\b[^>]*src="([^"]+)"[^>]*><\/script>/g)];
  for(const match of scripts){
    const bundled=await build({entryPoints:[resolve(dist,match[1])],bundle:true,write:false,minify:true,format:"esm",target:"es2020",legalComments:"inline"});
    html=html.replace(match[0],()=>`<script type="module">${bundled.outputFiles[0].text.replace(/<\/script/gi,"<\\/script")}</script>`);
  }
  html=html.replace(/<link\b[^>]*rel="modulepreload"[^>]*>/g,"");
  for(const match of [...html.matchAll(/<link\b[^>]*rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/g)]){
    const path=resolve(dist,match[1]);let css=await readFile(path,"utf8");
    for(const font of [...css.matchAll(/url\(([^)]+\.ttf)\)/g)]){const bytes=await readFile(resolve(dirname(path),font[1].replace(/["']/g,"")));css=css.replace(font[0],`url(data:font/ttf;base64,${bytes.toString("base64")})`);}
    html=html.replace(match[0],()=>`<style>${css}</style>`);
  }
  html=html.replaceAll('href="index.html"','href="hazard-editor.html"');
  html=html.replaceAll("Igloo teaching sessions","Igloo Retrofit Quizzes");
  html=html.replace("then **Publish changes**","then create a shareable play link");
  if(name==="index.html"||name==="sessions.html")html=html.replace("The editor is for preparation, not required during play.","The editor is for preparation, not required during play. After editing, create a shareable play link and copy it to ICE on the venue PC. No installation or local server is needed.");
  await writeFile(join(output,name),html);
}
await mkdir(join(output,"images"),{recursive:true});await copyFile(join(root,"public","images","construction-panorama.png"),join(output,"images","construction-panorama.png"));
await copyFile(join(root,"public","font-licenses.txt"),join(output,"font-licenses.txt"));
await copyFile(join(root,"node_modules","three","LICENSE"),join(output,"THREE-LICENSE.txt"));
await copyFile(join(root,"..","..","LICENSE"),join(output,"LICENSE"));
await writeFile(join(output,".nojekyll"),"");
await writeFile(join(output,"README.md"),`# Igloo Retrofit Quizzes\n\nOnline teaching activities for four walls and one combined floor.\n\n**Website:** https://duncanig.github.io/igloo-retrofit-quizzes/\n\n- Region quiz: [Play](region.html) · [Editor](region-editor.html) · [Desktop test](region.html?desktop=1)\n- Spot the Hazard: [Play](viewer.html) · [Editor](hazard-editor.html) · [Desktop test](viewer.html?desktop=1)\n\n## No local installation\n\nOpen the website on an internet-connected venue PC. In ICE use a play URL, a 2:1 equirectangular WebView source (e.g. 4096×2048), and keep True Perspective applied. Do not use desktop-test mode or the old flat wall/floor atlas in ICE. The two lower projector outputs are one floor; ICE owns their calibration/blending. Use the region quiz's alignment screen and measured roomYaw/UI-band calibration before teaching. Input, floor/wall orientation, seams and readability need a real room check.\n\n## Editing without a server\n\nEdit in your browser, click **Create shareable play link**, and copy the generated URL to ICE on the other PC. The fragment contains a compressed, validated snapshot of the questions, answers and settings; no files or local server needed. Existing links are immutable and do not change when you edit again. Browser drafts stay in that browser; saving a share link transfers the activity. These links include the answer key, so they are not suitable for private exams. GitHub Pages does not provide cloud publishing, live updates, accounts or image uploads; this edition uses the bundled construction image. Scene replacement needs a storage-backed host. Do not put personal learner information into activity links.\n\n## Teaching notes\n\nRegion quiz: original eight sample questions, editable names/timer/content. Learners move physically; timer expiry or **Answer locked in** immediately highlights the correct wall and floor sector. Pause freezes time. Tutor group-confidence records are not automatic or individual scores. No tracking hardware required.\n\nHazard quiz: eight editable construction hazards, risk/response questions, feedback, scores and debrief. Supplied scene is AI-generated, not a verified seamless 360 photograph. Review safety content with a competent tutor; not certification.\n\nRegion adaptation: https://github.com/duncanig/QuickFloorSessions/blob/main/region-quiz-floor.html . Simplified projected graphics; original embedded recorded narration/animations are not included. Three.js and font licence notices are included.\n\n## Repository layout\n\nRoot HTML files are standalone production bundles (no npm needed to run). The image is under images/. Unbundled source and rebuild instructions are in source.zip. GitHub Pages serves main at the repository root. No local publications, browser progress, Windows executable or credentials are included.\n`);
console.log(`GitHub Pages files: ${output}`);
