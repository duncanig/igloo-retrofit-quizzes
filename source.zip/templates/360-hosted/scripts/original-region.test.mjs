import test from "node:test";
import assert from "node:assert/strict";
import vm from "node:vm";
import { originalRegionHTML } from "./original-region.mjs";

test("the whole original quiz is preserved with a separate retrofit layout adapter",async()=>{
  const html=await originalRegionHTML();
  assert.ok(html.includes('15124 × 6134'));
  for(const original of ['function artSVG()','function biomeFx()','function quizEdit()','function lockIn()','function reveal()','drumT=setTimeout(reveal,2300)','async function pack()','function downloadFloorHTML()'])assert.ok(html.includes(original),original);
  assert.ok(html.includes('retrofitOriginalApply'));
  for(const script of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g))new vm.Script(script[1]);
});
test("native wall and combined-floor bounds match the supplied six-output diagram",()=>{
  const widths=[3974,3588,3974,3588],xs=[0,3974,7562,11536];
  assert.equal(widths.reduce((a,b)=>a+b),15124);
  for(let i=1;i<4;i++)assert.equal(xs[i],xs[i-1]+widths[i-1]);
  assert.equal(2160+1987*2,6134);assert.equal(2160+1987,4147);
});
