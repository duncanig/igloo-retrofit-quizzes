import { readFile,writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { join } from "node:path";

export const ORIGINAL_REGION_SHA256="74ff702813d8dd0dbf99febb9d13140d7bce37795337fc317ed5b73779b6b15e";
export async function originalRegionHTML(){
  const root=new URL("../",import.meta.url);
  let html=await readFile(new URL("region-original.html",root),"utf8");
  if(createHash("sha256").update(html).digest("hex")!==ORIGINAL_REGION_SHA256)throw Error("Original region source changed. Review it before updating the layout adapter.");
  const css=await readFile(new URL("src/region-retrofit.css",root),"utf8"),js=await readFile(new URL("src/region-retrofit.js",root),"utf8");
  const marker="if(new URLSearchParams(location.search).get('projection')==='1')";
  if(!html.includes(marker))throw Error("Original projection boot marker missing");
  html=html.replace("</head>",()=>`<style id="retrofit-layout">${css}</style></head>`);
  html=html.replace(marker,()=>js+"\n"+marker);
  html=html.replace('an 8000 x 1080 Igloo session template.','the original quiz adapted to a 15124 x 6134 retrofit output.');
  html=html.replace('Floor projection edition · 8640 × 3240 · four walls + floor','Retrofit edition · 15124 × 6134 · four walls + one combined floor');
  html=html.replace('Floor edition: 8640 × 3240 output. Four 2160 × 1080 walls occupy the top row; a 2160 × 2160 floor occupies x=2160, y=1080 directly below wall 2.',
    'Retrofit edition: 15124 × 6134 native projector-layout output. Walls 1–4 are 3974, 3588, 3974 and 3588 pixels wide, all 2160 pixels high. One combined 3588 × 3974 floor occupies x=3974, y=2160 below wall 2 (two stacked 3588 × 1987 outputs).');
  return html;
}

// Separate alias retains older editor bookmarks without replacing the original UI.
export const originalRegionEditorAlias='<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Original Region Quiz — Editor</title></head><body><p>Opening the original quiz. Select Edit in its toolbar.</p><script>var url=new URL("region.html",location.href);url.hash=location.hash;location.replace(url.href);</script><a href="region.html">Open original quiz and select Edit</a></body></html>';

export async function refreshOriginalRegion(output){
  await writeFile(join(output,"region.html"),await originalRegionHTML());
  await writeFile(join(output,"region-editor.html"),originalRegionEditorAlias);
  for(const name of ["index.html","sessions.html"]){
    let html=await readFile(join(output,name),"utf8");
    html=html.replace('<a href="region.html">ICE play</a>','<a href="region.html?projection=1">ICE play</a>');
    html=html.replace('href="region-editor.html"','href="region.html"').replace('href="region.html?desktop=1"','href="region.html"');
    html=html.replace('Keep True Perspective applied.','Region: original native room-layout output. Hazard Hunt: 2:1 equirectangular with True Perspective.');
    html=html.replace('Timer or manual lock reveals the correct wall and matching floor sector. No tracking required.','The complete original Glacier / Forest / Desert / Reef quiz, including its editor, animations and audio. Native output: 15124 × 6134.');
    html=html.replace('ICE source: 2:1 equirectangular. Do not place this menu or desktop-test mode in the room output. Final alignment, input and text size must be checked on site.',
      'Region ICE source: 15124 × 6134 native layout (not equirectangular). Hazard ICE source: 2:1 equirectangular / True Perspective. Use each activity’s matching ICE mapping; do not apply the hazard conversion to the region atlas. Check alignment and input in the room.');
    await writeFile(join(output,name),html);
  }
}
